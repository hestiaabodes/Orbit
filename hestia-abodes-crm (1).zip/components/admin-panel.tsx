"use client"

import { useState, useEffect, useCallback } from "react"
import { useCRM } from "@/lib/crm-context"
import { type User, type UserRole, roleLabels, formatDate, formatDateTime, leadSources } from "@/lib/data"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Switch } from "@/components/ui/switch"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Search,
  Plus,
  MoreVertical,
  Edit,
  Trash2,
  UserCog,
  Shield,
  Users,
  Settings,
  Activity,
  Lock,
  Unlock,
  Eye,
  EyeOff,
  Webhook,
  Copy,
  Check,
  Key,
  ToggleLeft,
  ToggleRight,
} from "lucide-react"
import { Separator } from "@/components/ui/separator"

const roles: { value: UserRole; label: string; description: string }[] = [
  { value: "admin", label: roleLabels.admin, description: "Full system access" },
  { value: "manager", label: roleLabels.manager, description: "Manage leads, projects, and team" },
  { value: "sales_executive", label: roleLabels.sales_executive, description: "Handle assigned leads and tasks" },
  { value: "presales_executive", label: roleLabels.presales_executive, description: "Pre-sales inquiries and lead qualification" },
  { value: "viewer", label: roleLabels.viewer, description: "Read-only access" },
]

const departments = ["Management", "Sales", "Pre-Sales", "Marketing", "Operations", "Finance", "HR"]

export function AdminPanel() {
  const {
    users,
    addUser,
    updateUser,
    deleteUser,
    leads,
    tasks,
    projects,
    currentUser,
    allRolePermissions,
    updateRolePermissions,
  } = useCRM()

  const [activeTab, setActiveTab] = useState("users")
  const [search, setSearch] = useState("")
  const [roleFilter, setRoleFilter] = useState<string>("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showDeleteDialog, setShowDeleteDialog] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [showPassword, setShowPassword] = useState(false)

  // API Key state
  interface ApiKey { id: string; keyValue: string; label: string; source: string; projectId: string | null; assignTo: string | null; isActive: boolean; createdAt: string; lastUsedAt: string | null; leadCount: number }
  const [apiKeys, setApiKeys] = useState<ApiKey[]>([])
  const [showAddKeyDialog, setShowAddKeyDialog] = useState(false)
  const [copiedKeyId, setCopiedKeyId] = useState<string | null>(null)
  const [keyForm, setKeyForm] = useState({ label: "", source: "99acres", projectId: "", assignTo: "" })

  const fetchApiKeys = useCallback(async () => {
    try {
      const res = await fetch("/api/api-keys")
      if (res.ok) { const data = await res.json(); setApiKeys(data.keys || []) }
    } catch { /* ignore - no DB */ }
  }, [])

  useEffect(() => { if (activeTab === "apikeys") fetchApiKeys() }, [activeTab, fetchApiKeys])

  const handleCreateApiKey = async () => {
    try {
      const payload = {
        ...keyForm,
        projectId: keyForm.projectId === "none" || !keyForm.projectId ? null : keyForm.projectId,
        assignTo: keyForm.assignTo === "none" || !keyForm.assignTo ? null : keyForm.assignTo,
      }
      const res = await fetch("/api/api-keys", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      })
      if (res.ok) { setShowAddKeyDialog(false); setKeyForm({ label: "", source: "99acres", projectId: "", assignTo: "" }); fetchApiKeys() }
    } catch { /* ignore */ }
  }

  const toggleApiKey = async (key: ApiKey) => {
    try {
      await fetch(`/api/api-keys/${key.id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ isActive: !key.isActive }),
      })
      fetchApiKeys()
    } catch { /* ignore */ }
  }

  const deleteApiKey = async (id: string) => {
    try {
      await fetch(`/api/api-keys/${id}`, { method: "DELETE" })
      fetchApiKeys()
    } catch { /* ignore */ }
  }

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text)
    setCopiedKeyId(id)
    setTimeout(() => setCopiedKeyId(null), 2000)
  }

  const [formData, setFormData] = useState({
    name: "",
    email: "",
    password: "",
    role: "sales_executive" as UserRole,
    phone: "",
    department: "Sales",
    isActive: true,
    managerId: "" as string | undefined,
    weekOffs: ["sunday"] as string[],
  })

  const resetForm = () => {
    setFormData({
      name: "",
      email: "",
      password: "",
      role: "sales_executive",
      phone: "",
      department: "Sales",
      isActive: true,
      managerId: "",
      weekOffs: ["sunday"],
    })
    setShowPassword(false)
  }

  const filteredUsers = users.filter((u) => {
    if (search) {
      const q = search.toLowerCase()
      if (!u.name.toLowerCase().includes(q) && !u.email.toLowerCase().includes(q)) return false
    }
    if (roleFilter !== "all" && u.role !== roleFilter) return false
    return true
  })

  const handleAddUser = () => {
    addUser({
      ...formData,
      managerId: formData.managerId === "none" || !formData.managerId ? undefined : formData.managerId,
    })
    setShowAddDialog(false)
    resetForm()
  }

  const handleEditUser = () => {
    if (!selectedUser) return
    const updateData: Partial<User> = {
      ...formData,
      managerId: formData.managerId === "none" || !formData.managerId ? undefined : formData.managerId,
    }
    if (!formData.password) {
      delete updateData.password
    }
    updateUser(selectedUser.id, updateData)
    setShowEditDialog(false)
    setSelectedUser(null)
    resetForm()
  }

  const handleDeleteUser = () => {
    if (!selectedUser) return
    deleteUser(selectedUser.id)
    setShowDeleteDialog(false)
    setSelectedUser(null)
  }

  const openEdit = (user: User) => {
    setSelectedUser(user)
    setFormData({
      name: user.name,
      email: user.email,
      password: "",
      role: user.role,
      phone: user.phone,
      department: user.department,
      isActive: user.isActive,
      managerId: user.managerId || "",
      weekOffs: user.weekOffs || ["sunday"],
    })
    setShowEditDialog(true)
  }

  const toggleUserActive = (user: User) => {
    updateUser(user.id, { isActive: !user.isActive })
  }

  // Stats
  const totalUsers = users.length
  const activeUsers = users.filter((u) => u.isActive).length
  const adminCount = users.filter((u) => u.role === "admin").length
  const managerCount = users.filter((u) => u.role === "manager").length

  // Permission categories for the role editor
  const permissionCategories = [
    {
      key: "dashboard",
      label: "Dashboard",
      actions: [{ key: "view", label: "View Dashboard" }],
    },
    {
      key: "leads",
      label: "Leads",
      actions: [
        { key: "view", label: "View Leads" },
        { key: "create", label: "Create Leads" },
        { key: "edit", label: "Edit Leads" },
        { key: "delete", label: "Delete Leads" },
        { key: "assign", label: "Assign Leads" },
        { key: "export", label: "Export Leads" },
      ],
    },
    {
      key: "projects",
      label: "Projects",
      actions: [
        { key: "view", label: "View Projects" },
        { key: "create", label: "Create Projects" },
        { key: "edit", label: "Edit Projects" },
        { key: "delete", label: "Delete Projects" },
      ],
    },
    {
      key: "tasks",
      label: "Tasks",
      actions: [
        { key: "view", label: "View Tasks" },
        { key: "create", label: "Create Tasks" },
        { key: "edit", label: "Edit Tasks" },
        { key: "delete", label: "Delete Tasks" },
        { key: "assign", label: "Assign Tasks" },
      ],
    },
    {
      key: "team",
      label: "Team",
      actions: [
        { key: "view", label: "View Team" },
        { key: "manage", label: "Manage Team" },
      ],
    },
    {
      key: "reports",
      label: "Reports",
      actions: [
        { key: "view", label: "View Reports" },
        { key: "export", label: "Export Reports" },
      ],
    },
    {
      key: "admin",
      label: "Admin",
      actions: [
        { key: "access", label: "Access Admin Panel" },
        { key: "manageUsers", label: "Manage Users" },
        { key: "manageRoles", label: "Manage Roles" },
        { key: "manageSettings", label: "Manage Settings" },
      ],
    },
    {
      key: "hrms",
      label: "HRMS",
      actions: [
        { key: "view", label: "View HRMS" },
        { key: "manage", label: "Manage HRMS" },
        { key: "approve", label: "Approve Requests" },
      ],
    },
  ]

  const handlePermissionChange = (role: UserRole, category: string, action: string, value: boolean) => {
    const rolePerm = allRolePermissions.find((rp) => rp.role === role)
    if (!rolePerm) return
    const updatedPerms = { ...rolePerm.permissions }
    const cat = { ...(updatedPerms as Record<string, Record<string, boolean>>)[category] }
    cat[action] = value
    ;(updatedPerms as Record<string, Record<string, boolean>>)[category] = cat
    updateRolePermissions(role, updatedPerms as typeof rolePerm.permissions)
  }

  const UserForm = ({ onSubmit, submitLabel, isEdit }: { onSubmit: () => void; submitLabel: string; isEdit?: boolean }) => (
    <div className="grid gap-4 py-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Full Name *</Label>
          <Input
            value={formData.name}
            onChange={(e) => setFormData({ ...formData, name: e.target.value })}
            placeholder="John Doe"
            className="border-border bg-background text-foreground"
          />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Email *</Label>
          <Input
            type="email"
            value={formData.email}
            onChange={(e) => setFormData({ ...formData, email: e.target.value })}
            placeholder="john@hestiaabodes.com"
            className="border-border bg-background text-foreground"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">{isEdit ? "New Password (leave blank to keep)" : "Password *"}</Label>
          <div className="relative">
            <Input
              type={showPassword ? "text" : "password"}
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              placeholder={isEdit ? "Leave blank to keep current" : "Set password"}
              className="border-border bg-background pr-10 text-foreground"
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground"
              aria-label={showPassword ? "Hide password" : "Show password"}
            >
              {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
            </button>
          </div>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Phone</Label>
          <Input
            value={formData.phone}
            onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
            placeholder="+91 99999 99999"
            className="border-border bg-background text-foreground"
          />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Role</Label>
          <Select value={formData.role} onValueChange={(v) => setFormData({ ...formData, role: v as UserRole })}>
            <SelectTrigger className="border-border bg-background text-foreground">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {roles.map((r) => (
                <SelectItem key={r.value} value={r.value}>
                  <span className="flex flex-col">
                    <span>{r.label}</span>
                  </span>
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <p className="text-[11px] text-muted-foreground">
            {roles.find((r) => r.value === formData.role)?.description}
          </p>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Department</Label>
          <Select value={formData.department} onValueChange={(v) => setFormData({ ...formData, department: v })}>
            <SelectTrigger className="border-border bg-background text-foreground">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              {departments.map((d) => (
                <SelectItem key={d} value={d}>{d}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Reports To (Manager)</Label>
          <Select value={formData.managerId || ""} onValueChange={(v) => setFormData({ ...formData, managerId: v || undefined })}>
            <SelectTrigger className="border-border bg-background text-foreground">
              <SelectValue placeholder="Select manager" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="none">No Manager</SelectItem>
              {users.filter((u) => ["admin", "manager"].includes(u.role) && u.isActive).map((u) => (
                <SelectItem key={u.id} value={u.id}>{u.name} ({u.role})</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Week-offs</Label>
          <div className="flex flex-wrap gap-2">
            {["sunday", "saturday", "monday", "tuesday", "wednesday", "thursday", "friday"].map((day) => (
              <button
                key={day}
                type="button"
                onClick={() => {
                  const current = formData.weekOffs
                  if (current.includes(day)) {
                    setFormData({ ...formData, weekOffs: current.filter((d) => d !== day) })
                  } else {
                    setFormData({ ...formData, weekOffs: [...current, day] })
                  }
                }}
                className={cn(
                  "rounded-md border px-2 py-1 text-xs capitalize transition-colors",
                  formData.weekOffs.includes(day)
                    ? "border-primary bg-primary/10 text-primary"
                    : "border-border text-muted-foreground hover:border-primary/50"
                )}
              >
                {day.slice(0, 3)}
              </button>
            ))}
          </div>
        </div>
      </div>
      <div className="flex items-center gap-3">
        <Switch
          checked={formData.isActive}
          onCheckedChange={(v) => setFormData({ ...formData, isActive: v })}
        />
        <Label className="text-foreground">Active Account</Label>
      </div>
      <DialogFooter>
        <Button
          onClick={onSubmit}
          disabled={!formData.name || !formData.email || (!isEdit && !formData.password)}
          className="bg-primary text-primary-foreground hover:bg-primary/90"
        >
          {submitLabel}
        </Button>
      </DialogFooter>
    </div>
  )

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Admin Panel</h1>
        <p className="text-sm text-muted-foreground">
          Manage users, roles, and system permissions
        </p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <Users className="h-8 w-8 text-primary" />
            <div>
              <p className="text-2xl font-bold text-foreground">{totalUsers}</p>
              <p className="text-xs text-muted-foreground">Total Users</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <Activity className="h-8 w-8 text-[hsl(160,45%,40%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{activeUsers}</p>
              <p className="text-xs text-muted-foreground">Active Users</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <Shield className="h-8 w-8 text-[hsl(210,50%,50%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{adminCount}</p>
              <p className="text-xs text-muted-foreground">Admins</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <UserCog className="h-8 w-8 text-[hsl(37,50%,70%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{managerCount}</p>
              <p className="text-xs text-muted-foreground">Managers</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-muted">
          <TabsTrigger value="users" className="text-foreground data-[state=active]:bg-background">
            <Users className="mr-2 h-4 w-4" /> User Management
          </TabsTrigger>
          <TabsTrigger value="roles" className="text-foreground data-[state=active]:bg-background">
            <Shield className="mr-2 h-4 w-4" /> Role Permissions
          </TabsTrigger>
          <TabsTrigger value="activity" className="text-foreground data-[state=active]:bg-background">
            <Activity className="mr-2 h-4 w-4" /> System Overview
          </TabsTrigger>
          <TabsTrigger value="apikeys" className="text-foreground data-[state=active]:bg-background">
            <Webhook className="mr-2 h-4 w-4" /> API Keys
          </TabsTrigger>
        </TabsList>

        {/* User Management Tab */}
        <TabsContent value="users" className="flex flex-col gap-4">
          <Card className="border-border/60">
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input
                    placeholder="Search users..."
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    className="border-border bg-background pl-9 text-foreground"
                  />
                </div>
                <Select value={roleFilter} onValueChange={setRoleFilter}>
                  <SelectTrigger className="w-[150px] border-border bg-background text-foreground">
                    <SelectValue placeholder="Role" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Roles</SelectItem>
                    {roles.map((r) => (
                      <SelectItem key={r.value} value={r.value}>{r.label}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Button
                  size="sm"
                  className="bg-primary text-primary-foreground hover:bg-primary/90"
                  onClick={() => { resetForm(); setShowAddDialog(true) }}
                >
                  <Plus className="mr-2 h-4 w-4" /> Add User
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground">User</TableHead>
                    <TableHead className="text-foreground">Role</TableHead>
                    <TableHead className="text-foreground">Department</TableHead>
                    <TableHead className="text-foreground">Status</TableHead>
                    <TableHead className="text-foreground">Reports To</TableHead>
                    <TableHead className="text-foreground">Leads</TableHead>
                    <TableHead className="text-foreground">Tasks</TableHead>
                    <TableHead className="text-foreground">Last Login</TableHead>
                    <TableHead className="text-right text-foreground">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredUsers.map((user) => {
                    const userLeads = leads.filter((l) => l.assignedTo === user.id).length
                    const userTasks = tasks.filter((t) => t.assignedTo === user.id).length
                    const roleInfo = roles.find((r) => r.value === user.role)
                    const isSelf = currentUser?.id === user.id

                    return (
                      <TableRow key={user.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <div className="flex h-9 w-9 shrink-0 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                              {user.name.split(" ").map((n) => n[0]).join("")}
                            </div>
                            <div className="flex flex-col">
                              <span className="text-sm font-medium text-foreground">
                                {user.name}
                                {isSelf && <span className="ml-1 text-[10px] text-muted-foreground">(You)</span>}
                              </span>
                              <span className="text-xs text-muted-foreground">{user.email}</span>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <Badge variant="secondary" className="capitalize bg-primary/10 text-primary">
                            {roleInfo?.label}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-foreground">{user.department}</TableCell>
                        <TableCell>
                          <button
                            onClick={() => !isSelf && toggleUserActive(user)}
                            className="flex items-center gap-1.5 text-sm"
                            disabled={isSelf}
                          >
                            {user.isActive ? (
                              <>
                                <span className="h-2 w-2 rounded-full bg-green-500" />
                                <span className="text-green-700">Active</span>
                              </>
                            ) : (
                              <>
                                <span className="h-2 w-2 rounded-full bg-red-500" />
                                <span className="text-red-700">Inactive</span>
                              </>
                            )}
                          </button>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">
                          {user.managerId ? (users.find(u => u.id === user.managerId)?.name || "-") : "-"}
                        </TableCell>
                        <TableCell className="text-sm text-foreground">{userLeads}</TableCell>
                        <TableCell className="text-sm text-foreground">{userTasks}</TableCell>
                        <TableCell className="text-sm text-muted-foreground">{user.lastLogin ? formatDate(user.lastLogin) : "-"}</TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={() => openEdit(user)}>
                                <Edit className="mr-2 h-4 w-4" /> Edit User
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => toggleUserActive(user)} disabled={isSelf}>
                                {user.isActive ? (
                                  <><Lock className="mr-2 h-4 w-4" /> Deactivate</>
                                ) : (
                                  <><Unlock className="mr-2 h-4 w-4" /> Activate</>
                                )}
                              </DropdownMenuItem>
                              {!isSelf && (
                                <DropdownMenuItem
                                  onClick={() => { setSelectedUser(user); setShowDeleteDialog(true) }}
                                  className="text-destructive"
                                >
                                  <Trash2 className="mr-2 h-4 w-4" /> Delete User
                                </DropdownMenuItem>
                              )}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Role Permissions Tab */}
        <TabsContent value="roles" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Role-Based Access Control</CardTitle>
              <CardDescription className="text-muted-foreground">
                Configure what each role can access and manage. Changes take effect immediately.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="overflow-x-auto">
                <table className="w-full text-sm">
                  <thead>
                    <tr className="border-b border-border">
                      <th className="px-4 py-3 text-left font-semibold text-foreground">Permission</th>
                      {roles.map((r) => (
                        <th key={r.value} className="px-4 py-3 text-center font-semibold text-foreground">
                          <div className="flex flex-col items-center gap-1">
                            <span>{r.label}</span>
                            <span className="text-[10px] font-normal text-muted-foreground">{r.description}</span>
                          </div>
                        </th>
                      ))}
                    </tr>
                  </thead>
                  <tbody>
                    {permissionCategories.map((cat) => (
                      <>
                        <tr key={`${cat.key}-header`} className="bg-muted/50">
                          <td colSpan={roles.length + 1} className="px-4 py-2 text-xs font-bold uppercase tracking-wider text-muted-foreground">
                            {cat.label}
                          </td>
                        </tr>
                        {cat.actions.map((action) => (
                          <tr key={`${cat.key}-${action.key}`} className="border-b border-border/50">
                            <td className="px-4 py-2.5 text-foreground">{action.label}</td>
                            {roles.map((r) => {
                              const rolePerm = allRolePermissions.find((rp) => rp.role === r.value)
                              const catPerms = rolePerm?.permissions[cat.key as keyof typeof rolePerm.permissions]
                              const isChecked = catPerms ? (catPerms as Record<string, boolean>)[action.key] : false

                              return (
                                <td key={r.value} className="px-4 py-2.5 text-center">
                                  <Checkbox
                                    checked={isChecked}
                                    onCheckedChange={(v) =>
                                      handlePermissionChange(r.value, cat.key, action.key, !!v)
                                    }
                                    disabled={r.value === "admin"}
                                    className="border-border"
                                  />
                                </td>
                              )
                            })}
                          </tr>
                        ))}
                      </>
                    ))}
                  </tbody>
                </table>
              </div>
              <p className="mt-4 text-xs text-muted-foreground">
                Admin permissions cannot be modified. To change admin access, assign a different role to the user.
              </p>
            </CardContent>
          </Card>
        </TabsContent>

        {/* System Overview Tab */}
        <TabsContent value="activity" className="flex flex-col gap-6">
          <div className="grid gap-6 md:grid-cols-2">
            <Card className="border-border/60">
              <CardHeader>
                <CardTitle className="text-base text-foreground">System Summary</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                <div className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                  <span className="text-sm text-muted-foreground">Total Users</span>
                  <span className="font-bold text-foreground">{totalUsers}</span>
                </div>
                <div className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                  <span className="text-sm text-muted-foreground">Total Leads</span>
                  <span className="font-bold text-foreground">{leads.length}</span>
                </div>
                <div className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                  <span className="text-sm text-muted-foreground">Total Tasks</span>
                  <span className="font-bold text-foreground">{tasks.length}</span>
                </div>
                <div className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                  <span className="text-sm text-muted-foreground">Active Leads</span>
                  <span className="font-bold text-foreground">
                    {leads.filter((l) => !["won", "lost"].includes(l.status)).length}
                  </span>
                </div>
                <div className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                  <span className="text-sm text-muted-foreground">Conversion Rate</span>
                  <span className="font-bold text-foreground">
                    {leads.length > 0
                      ? ((leads.filter((l) => l.status === "won").length / leads.length) * 100).toFixed(1)
                      : "0"}
                    %
                  </span>
                </div>
              </CardContent>
            </Card>

            <Card className="border-border/60">
              <CardHeader>
                <CardTitle className="text-base text-foreground">Users by Role</CardTitle>
              </CardHeader>
              <CardContent className="flex flex-col gap-3">
                {roles.map((role) => {
                  const count = users.filter((u) => u.role === role.value).length
                  const activeCount = users.filter((u) => u.role === role.value && u.isActive).length
                  return (
                    <div key={role.value} className="flex items-center justify-between rounded-lg bg-muted px-4 py-3">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium text-foreground">{role.label}</span>
                        <span className="text-[11px] text-muted-foreground">{role.description}</span>
                      </div>
                      <div className="flex items-center gap-2">
                        <Badge variant="secondary" className="bg-primary/10 text-primary">
                          {activeCount} active
                        </Badge>
                        <span className="text-xs text-muted-foreground">{count} total</span>
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>

            <Card className="border-border/60 md:col-span-2">
              <CardHeader>
                <CardTitle className="text-base text-foreground">User Workload Distribution</CardTitle>
                <CardDescription className="text-muted-foreground">Leads and tasks assigned to each user</CardDescription>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-foreground">User</TableHead>
                      <TableHead className="text-foreground">Role</TableHead>
                      <TableHead className="text-foreground">Total Leads</TableHead>
                      <TableHead className="text-foreground">Active Leads</TableHead>
                      <TableHead className="text-foreground">Won</TableHead>
                      <TableHead className="text-foreground">Pending Tasks</TableHead>
                      <TableHead className="text-foreground">Completed Tasks</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users
                      .filter((u) => u.isActive)
                      .map((user) => {
                        const userLeads = leads.filter((l) => l.assignedTo === user.id)
                        const userTasks = tasks.filter((t) => t.assignedTo === user.id)
                        return (
                          <TableRow key={user.id}>
                            <TableCell className="font-medium text-foreground">{user.name}</TableCell>
                            <TableCell>
                              <Badge variant="secondary" className="bg-primary/10 text-primary text-[10px]">
                                {roleLabels[user.role]}
                              </Badge>
                            </TableCell>
                            <TableCell className="text-foreground">{userLeads.length}</TableCell>
                            <TableCell className="text-foreground">
                              {userLeads.filter((l) => !["won", "lost"].includes(l.status)).length}
                            </TableCell>
                            <TableCell className="font-medium text-green-700">
                              {userLeads.filter((l) => l.status === "won").length}
                            </TableCell>
                            <TableCell className="text-foreground">
                              {userTasks.filter((t) => t.status !== "completed").length}
                            </TableCell>
                            <TableCell className="text-foreground">
                              {userTasks.filter((t) => t.status === "completed").length}
                            </TableCell>
                          </TableRow>
                        )
                      })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* API Keys Tab */}
        <TabsContent value="apikeys" className="flex flex-col gap-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <div>
                  <CardTitle className="text-lg text-foreground">Lead Capture API Keys</CardTitle>
                  <CardDescription className="text-muted-foreground">
                    Create API keys for property portals (99acres, MagicBricks, Housing.com, etc.) to automatically push leads into your CRM.
                  </CardDescription>
                </div>
                <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setShowAddKeyDialog(true)}>
                  <Plus className="mr-2 h-4 w-4" /> Create API Key
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {apiKeys.length === 0 ? (
                <div className="flex flex-col items-center gap-3 py-12 text-center">
                  <Key className="h-10 w-10 text-muted-foreground/40" />
                  <p className="text-sm text-muted-foreground">No API keys yet. Create one to start receiving leads automatically from property portals.</p>
                  <p className="text-xs text-muted-foreground">Note: API keys only work when the CRM is connected to a database (on your VPS).</p>
                </div>
              ) : (
                <div className="flex flex-col gap-3">
                  {apiKeys.map((key) => (
                    <div key={key.id} className={cn("rounded-lg border p-4 transition-colors", key.isActive ? "border-border bg-card" : "border-border/40 bg-muted/30 opacity-60")}>
                      <div className="flex items-start justify-between gap-4">
                        <div className="flex-1 min-w-0">
                          <div className="flex items-center gap-2 mb-1">
                            <p className="font-medium text-foreground">{key.label}</p>
                            <Badge variant="secondary" className={key.isActive ? "bg-green-100 text-green-700" : "bg-gray-100 text-gray-500"}>
                              {key.isActive ? "Active" : "Inactive"}
                            </Badge>
                            <Badge variant="outline" className="text-[10px]">{key.source}</Badge>
                          </div>
                          <div className="flex items-center gap-2 mt-2">
                            <code className="rounded bg-muted px-2 py-1 text-xs text-foreground font-mono truncate max-w-[400px]">{key.keyValue}</code>
                            <button
                              onClick={() => copyToClipboard(key.keyValue, key.id)}
                              className="shrink-0 rounded p-1 text-muted-foreground hover:text-foreground hover:bg-muted"
                              aria-label="Copy API key"
                            >
                              {copiedKeyId === key.id ? <Check className="h-3.5 w-3.5 text-green-600" /> : <Copy className="h-3.5 w-3.5" />}
                            </button>
                          </div>
                          <div className="flex flex-wrap items-center gap-4 mt-2 text-[11px] text-muted-foreground">
                            <span>Leads received: <strong className="text-foreground">{key.leadCount}</strong></span>
                            {key.lastUsedAt && <span>Last used: {formatDateTime(key.lastUsedAt)}</span>}
                            {key.projectId && <span>Project: {projects.find(p => p.id === key.projectId)?.name || key.projectId}</span>}
                            {key.assignTo && <span>Assign to: {users.find(u => u.id === key.assignTo)?.name || key.assignTo}</span>}
                            {!key.assignTo && <span>Assignment: Round-robin (auto)</span>}
                          </div>
                        </div>
                        <div className="flex items-center gap-1 shrink-0">
                          <button onClick={() => toggleApiKey(key)} className="rounded p-1.5 text-muted-foreground hover:text-foreground hover:bg-muted" aria-label={key.isActive ? "Deactivate" : "Activate"}>
                            {key.isActive ? <ToggleRight className="h-5 w-5 text-green-600" /> : <ToggleLeft className="h-5 w-5" />}
                          </button>
                          <button onClick={() => deleteApiKey(key.id)} className="rounded p-1.5 text-muted-foreground hover:text-destructive hover:bg-destructive/10" aria-label="Delete">
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </CardContent>
          </Card>

          {/* Webhook URL Info */}
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <CardTitle className="text-sm text-foreground">Webhook URL for Property Portals</CardTitle>
              <CardDescription className="text-muted-foreground">
                Share this URL and your API key with the property portal to start receiving leads.
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-lg bg-muted p-4">
                <p className="mb-2 text-xs font-medium text-muted-foreground">POST Endpoint:</p>
                <div className="flex items-center gap-2">
                  <code className="flex-1 rounded bg-background px-3 py-2 text-sm text-foreground font-mono">
                    https://orbit.hestiaabodes.in/api/webhook/lead-capture?key=YOUR_API_KEY
                  </code>
                  <button
                    onClick={() => copyToClipboard("https://orbit.hestiaabodes.in/api/webhook/lead-capture?key=YOUR_API_KEY", "webhook-url")}
                    className="shrink-0 rounded p-2 text-muted-foreground hover:text-foreground hover:bg-background"
                    aria-label="Copy webhook URL"
                  >
                    {copiedKeyId === "webhook-url" ? <Check className="h-4 w-4 text-green-600" /> : <Copy className="h-4 w-4" />}
                  </button>
                </div>
                <Separator className="my-3" />
                <p className="mb-2 text-xs font-medium text-muted-foreground">Accepted Fields (JSON body):</p>
                <pre className="overflow-x-auto rounded bg-background px-3 py-2 text-xs text-muted-foreground font-mono">
{`{
  "name": "Customer Name",
  "phone": "+91 99999 99999",
  "email": "customer@email.com",
  "project": "Project Name",
  "budget": "50L - 1Cr",
  "notes": "Any remarks or comments",
  "source": "99acres"
}`}
                </pre>
                <p className="mt-2 text-[11px] text-muted-foreground">
                  Supports JSON, form-urlencoded, and multipart form data. Field names from all major portals (MagicBricks, 99acres, Housing.com, Facebook Ads, Google Ads) are auto-detected.
                </p>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Create API Key Dialog */}
      <Dialog open={showAddKeyDialog} onOpenChange={setShowAddKeyDialog}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Create API Key</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Generate an API key for a property portal or ad platform to push leads into your CRM automatically.
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Label *</Label>
              <Input
                value={keyForm.label}
                onChange={(e) => setKeyForm({ ...keyForm, label: e.target.value })}
                placeholder="e.g., 99acres - Hestia Grand"
                className="border-border bg-background text-foreground"
              />
              <p className="text-[11px] text-muted-foreground">A name to identify this key (e.g., portal name + project).</p>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Source *</Label>
              <Select value={keyForm.source} onValueChange={(v) => setKeyForm({ ...keyForm, source: v })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {leadSources.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">Leads from this key will be tagged with this source.</p>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Default Project (optional)</Label>
              <Select value={keyForm.projectId} onValueChange={(v) => setKeyForm({ ...keyForm, projectId: v })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Auto-detect from lead" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Auto-detect from lead</SelectItem>
                  {projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Assign Leads To (optional)</Label>
              <Select value={keyForm.assignTo} onValueChange={(v) => setKeyForm({ ...keyForm, assignTo: v })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Round-robin (automatic)" /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">Round-robin (automatic)</SelectItem>
                  {users.filter(u => u.isActive && u.role !== "viewer").map((u) => <SelectItem key={u.id} value={u.id}>{u.name} ({roleLabels[u.role]})</SelectItem>)}
                </SelectContent>
              </Select>
              <p className="text-[11px] text-muted-foreground">If not set, leads are distributed equally among active sales executives.</p>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={handleCreateApiKey} disabled={!keyForm.label || !keyForm.source} className="bg-primary text-primary-foreground hover:bg-primary/90">
              Generate API Key
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* Add User Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add New User</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Create a new user account for the CRM system
            </DialogDescription>
          </DialogHeader>
          <UserForm onSubmit={handleAddUser} submitLabel="Create User" />
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Edit User</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Update user account details
            </DialogDescription>
          </DialogHeader>
          <UserForm onSubmit={handleEditUser} submitLabel="Update User" isEdit />
        </DialogContent>
      </Dialog>

      {/* Delete Confirmation */}
      <AlertDialog open={showDeleteDialog} onOpenChange={setShowDeleteDialog}>
        <AlertDialogContent className="bg-card text-card-foreground">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">Delete User</AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              Are you sure you want to delete <strong>{selectedUser?.name}</strong>? This action cannot
              be undone. All leads and tasks assigned to this user will need to be reassigned.
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border text-foreground">Cancel</AlertDialogCancel>
            <AlertDialogAction onClick={handleDeleteUser} className="bg-destructive text-destructive-foreground hover:bg-destructive/90">
              Delete User
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
