"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { type Task, formatDate } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Checkbox } from "@/components/ui/checkbox"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Plus,
  MoreVertical,
  Edit,
  Trash2,
  Clock,
  CheckCircle2,
  AlertCircle,
  Circle,
  Filter,
  Calendar,
} from "lucide-react"

const taskPriorities = [
  { value: "low", label: "Low", color: "bg-muted text-muted-foreground" },
  { value: "medium", label: "Medium", color: "bg-blue-100 text-blue-700" },
  { value: "high", label: "High", color: "bg-orange-100 text-orange-700" },
  { value: "urgent", label: "Urgent", color: "bg-red-100 text-red-700" },
]

const taskStatuses = [
  { value: "pending", label: "Pending", icon: Circle, color: "text-muted-foreground" },
  { value: "in_progress", label: "In Progress", icon: Clock, color: "text-blue-600" },
  { value: "completed", label: "Completed", icon: CheckCircle2, color: "text-green-600" },
  { value: "overdue", label: "Overdue", icon: AlertCircle, color: "text-red-600" },
]

export function TasksManagement() {
  const { addTask, updateTask, deleteTask, leads, users, getUserById, hasPermission, currentUser, getScopedTasks, getScopedLeads, getAssignableUsers } = useCRM()
  const tasks = getScopedTasks()
  const scopedLeads = getScopedLeads()
  const assignableUsers = getAssignableUsers()

  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [priorityFilter, setPriorityFilter] = useState<string>("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [selectedTask, setSelectedTask] = useState<Task | null>(null)

  const [formData, setFormData] = useState({
    title: "",
    description: "",
    assignedTo: "",
    assignedBy: currentUser?.id || "",
    priority: "medium" as Task["priority"],
    status: "pending" as Task["status"],
    dueDate: "",
    leadId: "",
  })

  const resetForm = () => {
    setFormData({
      title: "",
      description: "",
      assignedTo: "",
      assignedBy: currentUser?.id || "",
      priority: "medium",
      status: "pending",
      dueDate: "",
      leadId: "",
    })
  }

  const filteredTasks = tasks
    .filter((t) => {
      if (search && !t.title.toLowerCase().includes(search.toLowerCase())) return false
      if (statusFilter !== "all" && t.status !== statusFilter) return false
      if (priorityFilter !== "all" && t.priority !== priorityFilter) return false
      return true
    })
    .sort((a, b) => {
      const priorityOrder = { urgent: 0, high: 1, medium: 2, low: 3 }
      return priorityOrder[a.priority] - priorityOrder[b.priority]
    })

  const handleAddTask = () => {
    addTask(formData)
    setShowAddDialog(false)
    resetForm()
  }

  const handleEditTask = () => {
    if (!selectedTask) return
    updateTask(selectedTask.id, formData)
    setShowEditDialog(false)
    resetForm()
  }

  const openEdit = (task: Task) => {
    setSelectedTask(task)
    setFormData({
      title: task.title,
      description: task.description,
      assignedTo: task.assignedTo,
      assignedBy: task.assignedBy,
      priority: task.priority,
      status: task.status,
      dueDate: task.dueDate,
      leadId: task.leadId || "",
    })
    setShowEditDialog(true)
  }

  const toggleComplete = (task: Task) => {
    updateTask(task.id, {
      status: task.status === "completed" ? "pending" : "completed",
    })
  }

  // Use hierarchy-based assignable users instead of all active users

  // Stats
  const pendingCount = tasks.filter((t) => t.status === "pending").length
  const inProgressCount = tasks.filter((t) => t.status === "in_progress").length
  const completedCount = tasks.filter((t) => t.status === "completed").length
  const overdueCount = tasks.filter((t) => t.status !== "completed" && new Date(t.dueDate) < new Date()).length

  const TaskForm = ({ onSubmit, submitLabel }: { onSubmit: () => void; submitLabel: string }) => (
    <div className="grid gap-4 py-4">
      <div className="flex flex-col gap-2">
        <Label className="text-foreground">Title *</Label>
        <Input value={formData.title} onChange={(e) => setFormData({ ...formData, title: e.target.value })} placeholder="Task title" className="border-border bg-background text-foreground" />
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-foreground">Description</Label>
        <Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} rows={3} className="border-border bg-background text-foreground" />
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Assign To</Label>
          <Select value={formData.assignedTo} onValueChange={(v) => setFormData({ ...formData, assignedTo: v })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select" /></SelectTrigger>
            <SelectContent>
              {assignableUsers.map((u) => (
                <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Due Date</Label>
          <Input type="date" value={formData.dueDate} onChange={(e) => setFormData({ ...formData, dueDate: e.target.value })} className="border-border bg-background text-foreground" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Priority</Label>
          <Select value={formData.priority} onValueChange={(v) => setFormData({ ...formData, priority: v as Task["priority"] })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
            <SelectContent>
              {taskPriorities.map((p) => (
                <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Related Lead</Label>
          <Select value={formData.leadId} onValueChange={(v) => setFormData({ ...formData, leadId: v })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Optional" /></SelectTrigger>
            <SelectContent>
              <SelectItem value="none">None</SelectItem>
              {scopedLeads.map((l) => (
                <SelectItem key={l.id} value={l.id}>{l.name}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      {showEditDialog && (
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Status</Label>
          <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v as Task["status"] })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
            <SelectContent>
              {taskStatuses.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      )}
      <DialogFooter>
        <Button onClick={onSubmit} disabled={!formData.title} className="bg-primary text-primary-foreground hover:bg-primary/90">
          {submitLabel}
        </Button>
      </DialogFooter>
    </div>
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Task Management</h1>
          <p className="text-sm text-muted-foreground">Manage and track team tasks and follow-ups</p>
        </div>
        {hasPermission("tasks", "create") && (
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => { resetForm(); setShowAddDialog(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Add Task
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <Circle className="h-5 w-5 text-muted-foreground" />
            <div>
              <p className="text-lg font-bold text-foreground">{pendingCount}</p>
              <p className="text-xs text-muted-foreground">Pending</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <Clock className="h-5 w-5 text-blue-600" />
            <div>
              <p className="text-lg font-bold text-foreground">{inProgressCount}</p>
              <p className="text-xs text-muted-foreground">In Progress</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <div>
              <p className="text-lg font-bold text-foreground">{completedCount}</p>
              <p className="text-xs text-muted-foreground">Completed</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <AlertCircle className="h-5 w-5 text-red-600" />
            <div>
              <p className="text-lg font-bold text-foreground">{overdueCount}</p>
              <p className="text-xs text-muted-foreground">Overdue</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Filters */}
      <Card className="border-border/60">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search tasks..." value={search} onChange={(e) => setSearch(e.target.value)} className="border-border bg-background pl-9 text-foreground" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {taskStatuses.map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={priorityFilter} onValueChange={setPriorityFilter}>
              <SelectTrigger className="w-[130px] border-border bg-background text-foreground"><SelectValue placeholder="Priority" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Priority</SelectItem>
                {taskPriorities.map((p) => (
                  <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Task Table */}
      <Card className="border-border/60">
        <CardContent className="p-0">
          <Table>
            <TableHeader>
              <TableRow className="hover:bg-transparent">
                <TableHead className="w-[40px] text-foreground" />
                <TableHead className="text-foreground">Task</TableHead>
                <TableHead className="text-foreground">Assigned To</TableHead>
                <TableHead className="text-foreground">Priority</TableHead>
                <TableHead className="text-foreground">Status</TableHead>
                <TableHead className="text-foreground">Due Date</TableHead>
                <TableHead className="text-foreground">Related Lead</TableHead>
                <TableHead className="text-right text-foreground">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredTasks.map((task) => {
                const priorityInfo = taskPriorities.find((p) => p.value === task.priority)
                const statusInfo = taskStatuses.find((s) => s.value === task.status)
                const assignee = getUserById(task.assignedTo)
                const relatedLead = task.leadId ? scopedLeads.find((l) => l.id === task.leadId) : null
                const isOverdue = task.status !== "completed" && new Date(task.dueDate) < new Date()
                const StatusIcon = statusInfo?.icon || Circle

                return (
                  <TableRow key={task.id} className={task.status === "completed" ? "opacity-60" : ""}>
                    <TableCell>
                      <Checkbox
                        checked={task.status === "completed"}
                        onCheckedChange={() => toggleComplete(task)}
                        className="border-border"
                      />
                    </TableCell>
                    <TableCell>
                      <div className="flex flex-col">
                        <span className={`font-medium text-foreground ${task.status === "completed" ? "line-through" : ""}`}>
                          {task.title}
                        </span>
                        <span className="text-xs text-muted-foreground line-clamp-1">{task.description}</span>
                      </div>
                    </TableCell>
                    <TableCell className="text-sm text-foreground">{assignee?.name || "-"}</TableCell>
                    <TableCell>
                      <Badge variant="secondary" className={priorityInfo?.color}>{priorityInfo?.label}</Badge>
                    </TableCell>
                    <TableCell>
                      <span className={`flex items-center gap-1 text-sm ${statusInfo?.color}`}>
                        <StatusIcon className="h-4 w-4" />
                        {statusInfo?.label}
                      </span>
                    </TableCell>
                    <TableCell>
                      <span className={`flex items-center gap-1 text-sm ${isOverdue ? "font-medium text-destructive" : "text-foreground"}`}>
                        <Calendar className="h-3 w-3" />
                        {formatDate(task.dueDate)}
                      </span>
                    </TableCell>
                    <TableCell className="text-sm text-foreground">{relatedLead?.name || "-"}</TableCell>
                    <TableCell className="text-right">
                      <DropdownMenu>
                        <DropdownMenuTrigger asChild>
                          <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground">
                            <MoreVertical className="h-4 w-4" />
                          </Button>
                        </DropdownMenuTrigger>
                        <DropdownMenuContent align="end">
                          {hasPermission("tasks", "edit") && (
                            <DropdownMenuItem onClick={() => openEdit(task)}>
                              <Edit className="mr-2 h-4 w-4" /> Edit
                            </DropdownMenuItem>
                          )}
                          {hasPermission("tasks", "delete") && (
                            <DropdownMenuItem onClick={() => deleteTask(task.id)} className="text-destructive">
                              <Trash2 className="mr-2 h-4 w-4" /> Delete
                            </DropdownMenuItem>
                          )}
                        </DropdownMenuContent>
                      </DropdownMenu>
                    </TableCell>
                  </TableRow>
                )
              })}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add New Task</DialogTitle>
            <DialogDescription className="text-muted-foreground">Create a new task for your team</DialogDescription>
          </DialogHeader>
          <TaskForm onSubmit={handleAddTask} submitLabel="Add Task" />
        </DialogContent>
      </Dialog>

      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Edit Task</DialogTitle>
            <DialogDescription className="text-muted-foreground">Update the task details</DialogDescription>
          </DialogHeader>
          <TaskForm onSubmit={handleEditTask} submitLabel="Update Task" />
        </DialogContent>
      </Dialog>
    </div>
  )
}
