"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { leadStatuses, leadSubStatuses, leadSources, formatDate, formatDateTime, roleLabels, type Lead, type LeadStatus, type LeadSubStatus } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from "@/components/ui/dropdown-menu"
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Search, Plus, MoreVertical, Eye, Edit, Trash2, Phone, Mail, Calendar, Download, MessageSquare, Clock, MapPin, FileText, ArrowUpDown, X, Lock, ArrowLeft, Hash } from "lucide-react"
import { Separator } from "@/components/ui/separator"

type ViewState = "list" | "detail" | "edit"
type Activity = { type: string }

export function LeadsManagement() {
  const { addLead, updateLead, deleteLead, addLeadActivity, projects, users, getUserById, hasPermission, currentUser, getScopedLeads, getFieldPermissions, leads: allLeads } = useCRM()

  const scopedLeads = getScopedLeads()
  const scopedLeadIds = new Set(scopedLeads.map((l) => l.id))
  const fieldPerms = getFieldPermissions()

  // Default list shows only scoped (assigned) leads; searching expands to all leads for view-only access
  const isAdmin = currentUser?.role === "admin"

  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [subStatusFilter, setSubStatusFilter] = useState<string>("all")
  const [sourceFilter, setSourceFilter] = useState<string>("all")
  const [assigneeFilter, setAssigneeFilter] = useState<string>("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null)
  const [viewState, setViewState] = useState<ViewState>("list")
  const [listMode, setListMode] = useState<"table" | "pipeline">("table")
  const [sortField, setSortField] = useState<string>("createdAt")
  const [sortDir, setSortDir] = useState<"asc" | "desc">("desc")
  const [activityType, setActivityType] = useState<string>("note")
  const [activityDesc, setActivityDesc] = useState("")

  const [showImportDialog, setShowImportDialog] = useState(false)
  const [importFile, setImportFile] = useState<File | null>(null)
  const [importResult, setImportResult] = useState<{ imported: number; skipped: number } | null>(null)
  const [importing, setImporting] = useState(false)

  const handleExportCSV = async () => {
    try {
      const res = await fetch("/api/leads/export")
      if (res.ok) {
        const blob = await res.blob()
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `leads-export-${new Date().toISOString().split("T")[0]}.csv`
        a.click()
        URL.revokeObjectURL(url)
      } else {
        // Fallback: client-side export from in-memory data
        const headers = ["Lead ID", "Name", "Email", "Phone", "Source", "Status", "Sub-Status", "Assigned To", "Budget", "Notes", "Created At"]
        const rows = filteredLeads.map(l => [
          l.leadId, l.name, l.email, l.phone, l.source, l.status, l.subStatus,
          getUserById(l.assignedTo)?.name || "", l.budget,
          `"${(l.notes || "").replace(/"/g, '""')}"`, l.createdAt
        ].join(","))
        const csv = [headers.join(","), ...rows].join("\n")
        const blob = new Blob([csv], { type: "text/csv" })
        const url = URL.createObjectURL(blob)
        const a = document.createElement("a")
        a.href = url
        a.download = `leads-export-${new Date().toISOString().split("T")[0]}.csv`
        a.click()
        URL.revokeObjectURL(url)
      }
    } catch {
      // Fallback CSV with client data
      const headers = ["Lead ID", "Name", "Email", "Phone", "Source", "Status", "Budget"]
      const rows = filteredLeads.map(l => [l.leadId, l.name, l.email, l.phone, l.source, l.status, l.budget].join(","))
      const csv = [headers.join(","), ...rows].join("\n")
      const blob = new Blob([csv], { type: "text/csv" })
      const url = URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.href = url
      a.download = `leads-export.csv`
      a.click()
      URL.revokeObjectURL(url)
    }
  }

  const handleImportCSV = async () => {
    if (!importFile) return
    setImporting(true)
    try {
      const formData = new FormData()
      formData.append("file", importFile)
      const res = await fetch("/api/leads/import", { method: "POST", body: formData })
      const data = await res.json()
      if (res.ok) {
        setImportResult({ imported: data.imported, skipped: data.skipped })
      } else {
        setImportResult({ imported: 0, skipped: 0 })
      }
    } catch {
      setImportResult({ imported: 0, skipped: 0 })
    } finally {
      setImporting(false)
    }
  }

  const [formData, setFormData] = useState({
    name: "", email: "", phone: "", alternatePhone: "", source: "", status: "new" as LeadStatus,
    subStatus: "warm" as LeadSubStatus, assignedTo: "", projectInterest: "",
    budget: "", notes: "", nextFollowUp: "",
  })

  const resetForm = () => {
    setFormData({ name: "", email: "", phone: "", alternatePhone: "", source: "", status: "new", subStatus: "warm", assignedTo: currentUser?.id || "", projectInterest: "", budget: "", notes: "", nextFollowUp: "" })
  }

  // Admins always see all leads; executives/managers see scoped leads by default,
  // but when a search query is typed, search across all leads (view-only for unassigned)
  const baseLeads = isAdmin ? allLeads : (search.trim() ? allLeads : scopedLeads)

  const filteredLeads = baseLeads
    .filter((l) => {
      if (search) {
        const q = search.toLowerCase()
        if (!l.name.toLowerCase().includes(q) && !l.email.toLowerCase().includes(q) && !l.phone.includes(q) && !l.leadId.toLowerCase().includes(q)) return false
      }
      if (statusFilter !== "all" && l.status !== statusFilter) return false
      if (subStatusFilter !== "all" && l.subStatus !== subStatusFilter) return false
      if (sourceFilter !== "all" && l.source !== sourceFilter) return false
      if (assigneeFilter !== "all" && l.assignedTo !== assigneeFilter) return false
      return true
    })
    .sort((a, b) => {
      const aVal = a[sortField as keyof Lead] || ""
      const bVal = b[sortField as keyof Lead] || ""
      if (sortDir === "asc") return String(aVal).localeCompare(String(bVal))
      return String(bVal).localeCompare(String(aVal))
    })

  const handleAddLead = () => { addLead(formData); setShowAddDialog(false); resetForm() }

  const handleEditLead = () => {
    if (!selectedLead) return
    const update: Partial<Lead> = {}
    if (fieldPerms.name) update.name = formData.name
    if (fieldPerms.email) update.email = formData.email
    if (fieldPerms.phone) update.phone = formData.phone
    if (fieldPerms.alternatePhone) update.alternatePhone = formData.alternatePhone
    if (fieldPerms.source) update.source = formData.source
    if (fieldPerms.status) update.status = formData.status
    if (fieldPerms.subStatus) update.subStatus = formData.subStatus
    if (fieldPerms.assignedTo) update.assignedTo = formData.assignedTo
    if (fieldPerms.projectInterest) update.projectInterest = formData.projectInterest
    if (fieldPerms.budget) update.budget = formData.budget
    if (fieldPerms.notes) update.notes = formData.notes
    if (fieldPerms.nextFollowUp) update.nextFollowUp = formData.nextFollowUp
    updateLead(selectedLead.id, update)
    setViewState("detail")
  }

  const openEdit = (lead: Lead) => {
    setSelectedLead(lead)
    setFormData({ name: lead.name, email: lead.email, phone: lead.phone, alternatePhone: lead.alternatePhone || "", source: lead.source, status: lead.status, subStatus: lead.subStatus, assignedTo: lead.assignedTo, projectInterest: lead.projectInterest, budget: lead.budget, notes: lead.notes, nextFollowUp: lead.nextFollowUp || "" })
    setViewState("edit")
  }

  const openDetail = (lead: Lead) => { setSelectedLead(lead); setViewState("detail") }

  const handleAddActivity = () => {
    if (!selectedLead || !activityDesc.trim()) return
    addLeadActivity(selectedLead.id, { type: activityType as Activity["type"], description: activityDesc, createdBy: currentUser?.id || "" })
    setActivityDesc("")
  }

  const salesUsers = users.filter((u) => ["sales_executive", "presales_executive", "manager"].includes(u.role) && u.isActive)
  const toggleSort = (field: string) => { if (sortField === field) { setSortDir(sortDir === "asc" ? "desc" : "asc") } else { setSortField(field); setSortDir("desc") } }
  const clearFilters = () => { setSearch(""); setStatusFilter("all"); setSubStatusFilter("all"); setSourceFilter("all"); setAssigneeFilter("all") }
  const hasActiveFilters = search || statusFilter !== "all" || subStatusFilter !== "all" || sourceFilter !== "all" || assigneeFilter !== "all"

  const LockedField = ({ label, value }: { label: string; value: string }) => (
    <div className="flex flex-col gap-2">
      <Label className="flex items-center gap-1.5 text-muted-foreground"><Lock className="h-3 w-3" /> {label}</Label>
      <div className="rounded-md border border-border bg-muted/50 px-3 py-2 text-sm text-muted-foreground">{value || "-"}</div>
    </div>
  )

  // ---- FULL SCREEN DETAIL VIEW ----
  if (viewState === "detail" && selectedLead) {
    const lead = allLeads.find((l) => l.id === selectedLead.id) || selectedLead
    const statusInfo = leadStatuses.find((s) => s.value === lead.status)
    const subStatusInfo = leadSubStatuses.find((p) => p.value === lead.subStatus)
    const assignee = getUserById(lead.assignedTo)
    const project = projects.find((p) => p.id === lead.projectInterest)
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => { setViewState("list"); setSelectedLead(null) }} className="text-foreground"><ArrowLeft className="h-5 w-5" /></Button>
          <div className="flex-1">
            <div className="flex items-center gap-3">
              <Badge variant="outline" className="border-primary/30 bg-primary/5 font-mono text-xs text-primary">{lead.leadId}</Badge>
              <h1 className="text-2xl font-bold text-foreground">{lead.name}</h1>
              <Badge variant="secondary" className={statusInfo?.color}>{statusInfo?.label}</Badge>
              <Badge variant="secondary" className={subStatusInfo?.color}>{subStatusInfo?.label}</Badge>
            </div>
            <p className="mt-1 text-sm text-muted-foreground">Created: {formatDateTime(lead.createdAt)} | Updated: {formatDateTime(lead.updatedAt)}</p>
          </div>
          <div className="flex items-center gap-2">
            {hasPermission("leads", "edit") && scopedLeadIds.has(lead.id) && <Button size="sm" variant="outline" className="border-border text-foreground" onClick={() => openEdit(lead)}><Edit className="mr-2 h-4 w-4" /> Edit</Button>}
            {!scopedLeadIds.has(lead.id) && <Badge variant="secondary" className="bg-muted text-muted-foreground text-xs">View Only</Badge>}
          </div>
        </div>
        <div className="grid gap-6 lg:grid-cols-3">
          <div className="lg:col-span-2 flex flex-col gap-4">
            <Card className="border-border/60">
              <CardContent className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-foreground">Contact Information</h3>
                <div className="grid grid-cols-2 gap-4">
                  <div className="flex items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-sm"><Phone className="h-4 w-4 text-primary" /><div className="flex flex-col"><span className="text-foreground">{lead.phone}</span><span className="text-[10px] text-muted-foreground">Primary</span></div></div>
                  <div className="flex items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-sm"><Mail className="h-4 w-4 text-primary" /><span className="text-foreground">{lead.email}</span></div>
                  {lead.alternatePhone && <div className="flex items-center gap-2 rounded-lg bg-muted/50 px-3 py-2 text-sm"><Phone className="h-4 w-4 text-muted-foreground" /><div className="flex flex-col"><span className="text-foreground">{lead.alternatePhone}</span><span className="text-[10px] text-muted-foreground">Alternate</span></div></div>}
                </div>
              </CardContent>
            </Card>
            <Card className="border-border/60">
              <CardContent className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-foreground">Lead Details</h3>
                <div className="grid grid-cols-3 gap-3 text-sm">
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Source</span><span className="font-medium text-foreground">{lead.source}</span></div>
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Budget</span><span className="font-medium text-foreground">{lead.budget}</span></div>
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Assigned To</span><span className="font-medium text-foreground">{assignee?.name || "-"}</span></div>
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Project Interest</span><span className="font-medium text-foreground">{project?.name || "-"}</span></div>
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Next Follow-up</span><span className="font-medium text-foreground">{formatDate(lead.nextFollowUp)}</span></div>
                  <div className="flex flex-col gap-0.5 rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Last Contacted</span><span className="font-medium text-foreground">{formatDateTime(lead.lastContactedAt)}</span></div>
                </div>
                {lead.notes && <div className="mt-3 rounded-lg bg-muted/50 px-3 py-2 text-sm"><span className="text-xs text-muted-foreground">Notes</span><p className="mt-1 text-foreground">{lead.notes}</p></div>}
              </CardContent>
            </Card>
            <Card className="border-border/60">
              <CardContent className="p-5">
                <h3 className="mb-4 text-sm font-semibold text-foreground">Activity Log</h3>
                {hasPermission("leads", "edit") && scopedLeadIds.has(lead.id) && (
                  <div className="mb-4 flex flex-col gap-2 rounded-lg border border-border p-3">
                    <div className="flex items-center gap-2">
                      <Select value={activityType} onValueChange={setActivityType}>
                        <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                        <SelectContent>
                          <SelectItem value="call"><span className="flex items-center gap-1"><Phone className="h-3 w-3" /> Call</span></SelectItem>
                          <SelectItem value="email"><span className="flex items-center gap-1"><Mail className="h-3 w-3" /> Email</span></SelectItem>
                          <SelectItem value="sms"><span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" /> SMS</span></SelectItem>
                          <SelectItem value="whatsapp"><span className="flex items-center gap-1"><MessageSquare className="h-3 w-3" /> WhatsApp</span></SelectItem>
                          <SelectItem value="meeting"><span className="flex items-center gap-1"><Clock className="h-3 w-3" /> Meeting</span></SelectItem>
                          <SelectItem value="site_visit"><span className="flex items-center gap-1"><MapPin className="h-3 w-3" /> Site Visit</span></SelectItem>
                          <SelectItem value="note"><span className="flex items-center gap-1"><FileText className="h-3 w-3" /> Note</span></SelectItem>
                        </SelectContent>
                      </Select>
                      <Input value={activityDesc} onChange={(e) => setActivityDesc(e.target.value)} placeholder="Describe the activity..." className="flex-1 border-border bg-background text-foreground" />
                      <Button size="sm" onClick={handleAddActivity} className="bg-primary text-primary-foreground hover:bg-primary/90" disabled={!activityDesc.trim()}>Add</Button>
                    </div>
                  </div>
                )}
                <div className="flex flex-col gap-2 max-h-[400px] overflow-y-auto">
                  {lead.activities.map((activity) => {
                    const creator = getUserById(activity.createdBy)
                    const icons: Record<string, typeof Phone> = { call: Phone, email: Mail, sms: MessageSquare, whatsapp: MessageSquare, meeting: Clock, site_visit: MapPin, note: FileText, status_change: FileText }
                    const ActivityIcon = icons[activity.type] || FileText
                    return (
                      <div key={activity.id} className="flex items-start gap-3 rounded-lg bg-muted/30 px-3 py-2">
                        <ActivityIcon className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
                        <div className="flex flex-col gap-0.5">
                          <p className="text-sm text-foreground">{activity.description}</p>
                          <p className="text-[10px] text-muted-foreground">{creator?.name || "-"} -- {formatDateTime(activity.createdAt)} -- {activity.type.replace("_", " ")}</p>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          </div>
          <div className="flex flex-col gap-4">
            <Card className="border-border/60">
              <CardContent className="flex flex-col gap-3 p-5">
                <h3 className="text-sm font-semibold text-foreground">Quick Info</h3>
                <div className="flex flex-col gap-2 text-sm">
                  <div className="flex justify-between"><span className="text-muted-foreground">Lead ID</span><span className="font-mono font-medium text-primary">{lead.leadId}</span></div>
                  <Separator />
                  <div className="flex justify-between"><span className="text-muted-foreground">Status</span><Badge variant="secondary" className={`text-[10px] ${statusInfo?.color}`}>{statusInfo?.label}</Badge></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Sub-Status</span><Badge variant="secondary" className={`text-[10px] ${subStatusInfo?.color}`}>{subStatusInfo?.label}</Badge></div>
                  <Separator />
                  <div className="flex justify-between"><span className="text-muted-foreground">Assigned To</span><span className="text-foreground">{assignee?.name || "-"}</span></div>
                  <div className="flex justify-between"><span className="text-muted-foreground">Created</span><span className="text-foreground">{formatDateTime(lead.createdAt)}</span></div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    )
  }

  // ---- FULL SCREEN EDIT VIEW ----
  if (viewState === "edit" && selectedLead) {
    const roleDisplay = currentUser?.role ? roleLabels[currentUser.role] : ""
    return (
      <div className="flex flex-col gap-6">
        <div className="flex items-center gap-4">
          <Button variant="ghost" size="icon" onClick={() => setViewState("detail")} className="text-foreground"><ArrowLeft className="h-5 w-5" /></Button>
          <div>
            <div className="flex items-center gap-2">
              <Badge variant="outline" className="border-primary/30 bg-primary/5 font-mono text-xs text-primary">{selectedLead.leadId}</Badge>
              <h1 className="text-2xl font-bold text-foreground">Edit Lead: {selectedLead.name}</h1>
            </div>
          </div>
        </div>
        <Card className="border-border/60">
          <CardContent className="p-6">
            <div className="mb-4 rounded-lg border border-amber-200 bg-amber-50 px-3 py-2 text-xs text-amber-800">
              Fields marked with a lock icon are read-only for your role ({roleDisplay}).
            </div>
            <div className="grid gap-4">
              <div className="grid grid-cols-2 gap-4">
                {fieldPerms.name ? <div className="flex flex-col gap-2"><Label className="text-foreground">Name</Label><Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="border-border bg-background text-foreground" /></div> : <LockedField label="Name" value={formData.name} />}
                {fieldPerms.email ? <div className="flex flex-col gap-2"><Label className="text-foreground">Email</Label><Input value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} className="border-border bg-background text-foreground" /></div> : <LockedField label="Email" value={formData.email} />}
              </div>
              <div className="grid grid-cols-2 gap-4">
                {fieldPerms.phone ? <div className="flex flex-col gap-2"><Label className="text-foreground">Phone</Label><Input value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} className="border-border bg-background text-foreground" /></div> : <LockedField label="Phone" value={formData.phone} />}
                {fieldPerms.alternatePhone ? <div className="flex flex-col gap-2"><Label className="text-foreground">Alternate Phone</Label><Input value={formData.alternatePhone} onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })} placeholder="Optional" className="border-border bg-background text-foreground" /></div> : <LockedField label="Alternate Phone" value={formData.alternatePhone || "-"} />}
              </div>
              <div className="grid grid-cols-2 gap-4">
                {fieldPerms.source ? <div className="flex flex-col gap-2"><Label className="text-foreground">Source</Label><Select value={formData.source} onValueChange={(v) => setFormData({ ...formData, source: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger><SelectContent>{leadSources.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div> : <LockedField label="Source" value={formData.source} />}
              </div>
              <div className="grid grid-cols-3 gap-4">
                {fieldPerms.status ? <div className="flex flex-col gap-2"><Label className="text-foreground">Status</Label><Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v as LeadStatus })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger><SelectContent>{leadStatuses.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></div> : <LockedField label="Status" value={leadStatuses.find((s) => s.value === formData.status)?.label || formData.status} />}
                {fieldPerms.subStatus ? <div className="flex flex-col gap-2"><Label className="text-foreground">Sub-Status</Label><Select value={formData.subStatus} onValueChange={(v) => setFormData({ ...formData, subStatus: v as LeadSubStatus })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger><SelectContent>{leadSubStatuses.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent></Select></div> : <LockedField label="Sub-Status" value={leadSubStatuses.find((p) => p.value === formData.subStatus)?.label || formData.subStatus} />}
                {fieldPerms.assignedTo ? <div className="flex flex-col gap-2"><Label className="text-foreground">Assign To</Label><Select value={formData.assignedTo} onValueChange={(v) => setFormData({ ...formData, assignedTo: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select" /></SelectTrigger><SelectContent>{salesUsers.map((u) => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}</SelectContent></Select></div> : <LockedField label="Assign To" value={getUserById(formData.assignedTo)?.name || "-"} />}
              </div>
              <div className="grid grid-cols-2 gap-4">
                {fieldPerms.projectInterest ? <div className="flex flex-col gap-2"><Label className="text-foreground">Project Interest</Label><Select value={formData.projectInterest} onValueChange={(v) => setFormData({ ...formData, projectInterest: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select project" /></SelectTrigger><SelectContent>{projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent></Select></div> : <LockedField label="Project Interest" value={projects.find((p) => p.id === formData.projectInterest)?.name || "-"} />}
                {fieldPerms.budget ? <div className="flex flex-col gap-2"><Label className="text-foreground">Budget</Label><Input value={formData.budget} onChange={(e) => setFormData({ ...formData, budget: e.target.value })} className="border-border bg-background text-foreground" /></div> : <LockedField label="Budget" value={formData.budget} />}
              </div>
              {fieldPerms.nextFollowUp ? <div className="flex flex-col gap-2"><Label className="text-foreground">Next Follow-up</Label><Input type="date" value={formData.nextFollowUp} onChange={(e) => setFormData({ ...formData, nextFollowUp: e.target.value })} className="border-border bg-background text-foreground" /></div> : <LockedField label="Next Follow-up" value={formData.nextFollowUp ? formatDate(formData.nextFollowUp) : "-"} />}
              {fieldPerms.notes ? <div className="flex flex-col gap-2"><Label className="text-foreground">Notes</Label><Textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} rows={3} className="border-border bg-background text-foreground" /></div> : <LockedField label="Notes" value={formData.notes} />}
              <div className="flex justify-end gap-3 pt-4">
                <Button variant="outline" className="border-border text-foreground" onClick={() => setViewState("detail")}>Cancel</Button>
                <Button onClick={handleEditLead} className="bg-primary text-primary-foreground hover:bg-primary/90">Update Lead</Button>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  // ---- LIST VIEW ----
  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Lead Management</h1>
            <p className="text-sm text-muted-foreground">Manage, track, and convert your leads ({filteredLeads.length} of {baseLeads.length})</p>
        </div>
        <div className="flex items-center gap-2">
          {hasPermission("leads", "export") && <Button variant="outline" size="sm" className="border-border text-foreground" onClick={handleExportCSV}><Download className="mr-2 h-4 w-4" /> Export CSV</Button>}
          {(currentUser?.role === "admin" || currentUser?.role === "manager") && <Button variant="outline" size="sm" className="border-border text-foreground" onClick={() => { setShowImportDialog(true); setImportResult(null); setImportFile(null) }}>Import CSV</Button>}
          {hasPermission("leads", "create") && <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => { resetForm(); setShowAddDialog(true) }}><Plus className="mr-2 h-4 w-4" /> Add Lead</Button>}
        </div>
      </div>

      <Card className="border-border/60">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search by name, email, phone, Lead ID..." value={search} onChange={(e) => setSearch(e.target.value)} className="border-border bg-background pl-9 text-foreground" />
            </div>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[160px] border-border bg-background text-foreground"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent><SelectItem value="all">All Status</SelectItem>{leadStatuses.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={subStatusFilter} onValueChange={setSubStatusFilter}>
              <SelectTrigger className="w-[160px] border-border bg-background text-foreground"><SelectValue placeholder="Sub-Status" /></SelectTrigger>
              <SelectContent><SelectItem value="all">All Sub-Status</SelectItem>{leadSubStatuses.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent>
            </Select>
            <Select value={sourceFilter} onValueChange={setSourceFilter}>
              <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue placeholder="Source" /></SelectTrigger>
              <SelectContent><SelectItem value="all">All Sources</SelectItem>{leadSources.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent>
            </Select>
            {hasPermission("leads", "assign") && (
              <Select value={assigneeFilter} onValueChange={setAssigneeFilter}>
                <SelectTrigger className="w-[150px] border-border bg-background text-foreground"><SelectValue placeholder="Assignee" /></SelectTrigger>
                <SelectContent><SelectItem value="all">All Assignees</SelectItem>{salesUsers.map((u) => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}</SelectContent>
              </Select>
            )}
            {hasActiveFilters && <Button variant="ghost" size="sm" onClick={clearFilters} className="text-muted-foreground hover:text-foreground"><X className="mr-1 h-3 w-3" /> Clear</Button>}
          </div>
        </CardContent>
      </Card>

      <div className="flex items-center gap-2">
        <Tabs value={listMode} onValueChange={(v) => setListMode(v as "table" | "pipeline")}>
          <TabsList className="bg-muted">
            <TabsTrigger value="table" className="text-foreground data-[state=active]:bg-background">Table View</TabsTrigger>
            <TabsTrigger value="pipeline" className="text-foreground data-[state=active]:bg-background">Pipeline View</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {listMode === "table" && (
        <Card className="border-border/60">
          <CardContent className="p-0">
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground w-[90px]">Lead ID</TableHead>
                    <TableHead className="cursor-pointer text-foreground" onClick={() => toggleSort("name")}><span className="flex items-center gap-1">Name <ArrowUpDown className="h-3 w-3" /></span></TableHead>
                    <TableHead className="hidden text-foreground sm:table-cell">Contact</TableHead>
                    <TableHead className="text-foreground">Source</TableHead>
                    <TableHead className="hidden text-foreground lg:table-cell">Project</TableHead>
                    <TableHead className="cursor-pointer text-foreground" onClick={() => toggleSort("status")}><span className="flex items-center gap-1">Status <ArrowUpDown className="h-3 w-3" /></span></TableHead>
                    <TableHead className="hidden text-foreground md:table-cell">Sub-Status</TableHead>
                    <TableHead className="hidden text-foreground md:table-cell">Assigned To</TableHead>
                    <TableHead className="hidden text-foreground lg:table-cell">Follow-up</TableHead>
                    <TableHead className="text-right text-foreground">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLeads.map((lead) => {
                    const statusInfo = leadStatuses.find((s) => s.value === lead.status)
                    const subStatusInfo = leadSubStatuses.find((p) => p.value === lead.subStatus)
                    const assignee = getUserById(lead.assignedTo)
                    const isOverdue = lead.nextFollowUp && new Date(lead.nextFollowUp) <= new Date()
                    return (
                      <TableRow key={lead.id} className="cursor-pointer hover:bg-muted/50" onClick={() => openDetail(lead)}>
                        <TableCell><span className="font-mono text-xs text-primary">{lead.leadId}</span></TableCell>
                        <TableCell>
                          <div className="flex flex-col">
                            <span className="font-medium text-foreground">{lead.name}</span>
                            <span className="text-xs text-muted-foreground">{lead.budget}</span>
                          </div>
                        </TableCell>
                        <TableCell className="hidden sm:table-cell">
                          <span className="flex items-center gap-1 text-xs text-muted-foreground"><Phone className="h-3 w-3" />{lead.phone}</span>
                        </TableCell>
                        <TableCell className="text-sm text-foreground">{lead.source}</TableCell>
                        <TableCell className="hidden text-sm text-foreground lg:table-cell">{projects.find((p) => p.id === lead.projectInterest)?.name || "-"}</TableCell>
                        <TableCell><Badge variant="secondary" className={statusInfo?.color}>{statusInfo?.label}</Badge></TableCell>
                        <TableCell className="hidden md:table-cell"><Badge variant="secondary" className={subStatusInfo?.color}>{subStatusInfo?.label}</Badge></TableCell>
                        <TableCell className="hidden text-sm text-foreground md:table-cell">{assignee?.name || "-"}</TableCell>
                        <TableCell className="hidden lg:table-cell">
                          {lead.nextFollowUp ? (
                            <span className={`flex items-center gap-1 text-xs ${isOverdue ? "font-medium text-destructive" : "text-muted-foreground"}`}><Calendar className="h-3 w-3" />{formatDate(lead.nextFollowUp)}</span>
                          ) : <span className="text-xs text-muted-foreground">-</span>}
                        </TableCell>
                        <TableCell className="text-right">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild onClick={(e) => e.stopPropagation()}>
                              <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground hover:text-foreground"><MoreVertical className="h-4 w-4" /></Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem onClick={(e) => { e.stopPropagation(); openDetail(lead) }}><Eye className="mr-2 h-4 w-4" /> View Details</DropdownMenuItem>
                              {hasPermission("leads", "edit") && scopedLeadIds.has(lead.id) && <DropdownMenuItem onClick={(e) => { e.stopPropagation(); openEdit(lead) }}><Edit className="mr-2 h-4 w-4" /> Edit Lead</DropdownMenuItem>}
                              {hasPermission("leads", "delete") && scopedLeadIds.has(lead.id) && <DropdownMenuItem onClick={(e) => { e.stopPropagation(); deleteLead(lead.id) }} className="text-destructive"><Trash2 className="mr-2 h-4 w-4" /> Delete</DropdownMenuItem>}
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </TableCell>
                      </TableRow>
                    )
                  })}
                  {filteredLeads.length === 0 && <TableRow><TableCell colSpan={10} className="py-8 text-center text-muted-foreground">No leads found matching your criteria</TableCell></TableRow>}
                </TableBody>
              </Table>
            </div>
          </CardContent>
        </Card>
      )}

      {listMode === "pipeline" && (
        <div className="flex gap-4 overflow-x-auto pb-4">
          {leadStatuses.map((status) => {
            const statusLeads = filteredLeads.filter((l) => l.status === status.value)
            return (
              <div key={status.value} className="flex min-w-[260px] flex-col gap-3">
                <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2">
                  <span className="text-sm font-semibold text-foreground">{status.label}</span>
                  <Badge variant="secondary" className="text-xs">{statusLeads.length}</Badge>
                </div>
                <div className="flex flex-col gap-2">
                  {statusLeads.map((lead) => {
                    const subInfo = leadSubStatuses.find((p) => p.value === lead.subStatus)
                    const assignee = getUserById(lead.assignedTo)
                    return (
                      <Card key={lead.id} className="cursor-pointer border-border/60 hover:border-primary/30" onClick={() => openDetail(lead)}>
                        <CardContent className="flex flex-col gap-2 p-3">
                          <div className="flex items-center justify-between">
                            <span className="font-mono text-[10px] text-primary">{lead.leadId}</span>
                            <Badge variant="secondary" className={`text-[10px] ${subInfo?.color}`}>{subInfo?.label}</Badge>
                          </div>
                          <span className="text-sm font-medium text-foreground">{lead.name}</span>
                          <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                            <span>{lead.source} -- {lead.budget}</span>
                            <span>{assignee?.name || "Unassigned"}</span>
                          </div>
                        </CardContent>
                      </Card>
                    )
                  })}
                  {statusLeads.length === 0 && <div className="rounded-lg border border-dashed border-border p-4 text-center text-xs text-muted-foreground">No leads</div>}
                </div>
              </div>
            )
          })}
        </div>
      )}

      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground max-h-[85vh] overflow-y-auto">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add New Lead</DialogTitle>
            <DialogDescription className="text-muted-foreground">Enter all lead details. All fields are available when creating a new lead.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2"><Label className="text-foreground">Name *</Label><Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Lead name" className="border-border bg-background text-foreground" /></div>
              <div className="flex flex-col gap-2"><Label className="text-foreground">Email</Label><Input value={formData.email} onChange={(e) => setFormData({ ...formData, email: e.target.value })} placeholder="email@example.com" className="border-border bg-background text-foreground" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2"><Label className="text-foreground">Phone *</Label><Input value={formData.phone} onChange={(e) => setFormData({ ...formData, phone: e.target.value })} placeholder="+91 99999 99999" className="border-border bg-background text-foreground" /></div>
              <div className="flex flex-col gap-2"><Label className="text-foreground">Alternate Phone</Label><Input value={formData.alternatePhone} onChange={(e) => setFormData({ ...formData, alternatePhone: e.target.value })} placeholder="Optional" className="border-border bg-background text-foreground" /></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2"><Label className="text-foreground">Source</Label><Select value={formData.source} onValueChange={(v) => setFormData({ ...formData, source: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select source" /></SelectTrigger><SelectContent>{leadSources.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}</SelectContent></Select></div>
            </div>
            <div className="grid grid-cols-3 gap-4">
              <div className="flex flex-col gap-2"><Label className="text-foreground">Status</Label><Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v as LeadStatus })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger><SelectContent>{leadStatuses.map((s) => <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>)}</SelectContent></Select></div>
              <div className="flex flex-col gap-2"><Label className="text-foreground">Sub-Status</Label><Select value={formData.subStatus} onValueChange={(v) => setFormData({ ...formData, subStatus: v as LeadSubStatus })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger><SelectContent>{leadSubStatuses.map((p) => <SelectItem key={p.value} value={p.value}>{p.label}</SelectItem>)}</SelectContent></Select></div>
              <div className="flex flex-col gap-2"><Label className="text-foreground">Assign To</Label><Select value={formData.assignedTo} onValueChange={(v) => setFormData({ ...formData, assignedTo: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select" /></SelectTrigger><SelectContent>{salesUsers.map((u) => <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>)}</SelectContent></Select></div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2"><Label className="text-foreground">Project Interest</Label><Select value={formData.projectInterest} onValueChange={(v) => setFormData({ ...formData, projectInterest: v })}><SelectTrigger className="border-border bg-background text-foreground"><SelectValue placeholder="Select project" /></SelectTrigger><SelectContent>{projects.map((p) => <SelectItem key={p.id} value={p.id}>{p.name}</SelectItem>)}</SelectContent></Select></div>
              <div className="flex flex-col gap-2"><Label className="text-foreground">Budget</Label><Input value={formData.budget} onChange={(e) => setFormData({ ...formData, budget: e.target.value })} placeholder="e.g. 50L - 80L" className="border-border bg-background text-foreground" /></div>
            </div>
            <div className="flex flex-col gap-2"><Label className="text-foreground">Next Follow-up</Label><Input type="date" value={formData.nextFollowUp} onChange={(e) => setFormData({ ...formData, nextFollowUp: e.target.value })} className="border-border bg-background text-foreground" /></div>
            <div className="flex flex-col gap-2"><Label className="text-foreground">Notes</Label><Textarea value={formData.notes} onChange={(e) => setFormData({ ...formData, notes: e.target.value })} placeholder="Additional notes..." rows={3} className="border-border bg-background text-foreground" /></div>
            <DialogFooter><Button onClick={handleAddLead} className="bg-primary text-primary-foreground hover:bg-primary/90" disabled={!formData.name || !formData.phone}>Add Lead</Button></DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Import CSV Dialog */}
      <Dialog open={showImportDialog} onOpenChange={setShowImportDialog}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Import Leads from CSV</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Upload a CSV file with columns: Name, Phone, Email, Source, Budget, Notes. Only works when connected to the database (on your VPS).
            </DialogDescription>
          </DialogHeader>
          <div className="flex flex-col gap-4 py-4">
            <Input
              type="file"
              accept=".csv"
              onChange={(e) => setImportFile(e.target.files?.[0] || null)}
              className="border-border bg-background text-foreground"
            />
            {importResult && (
              <div className="rounded-lg bg-muted px-3 py-2 text-sm text-foreground">
                Imported: <strong>{importResult.imported}</strong> leads | Skipped: <strong>{importResult.skipped}</strong> rows
              </div>
            )}
          </div>
          <DialogFooter>
            <Button
              onClick={handleImportCSV}
              disabled={!importFile || importing}
              className="bg-primary text-primary-foreground hover:bg-primary/90"
            >
              {importing ? "Importing..." : "Import"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
