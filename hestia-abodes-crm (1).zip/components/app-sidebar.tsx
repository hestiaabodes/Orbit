"use client"

import { useCRM } from "@/lib/crm-context"
import { roleLabels } from "@/lib/data"
import { cn } from "@/lib/utils"
import {
  LayoutDashboard,
  Users,
  Building2,
  ClipboardList,
  BarChart3,
  UserCog,
  Settings,
  LogOut,
  ChevronLeft,
  ChevronRight,
  Target,
  Briefcase,
  LifeBuoy,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import { Tooltip, TooltipContent, TooltipProvider, TooltipTrigger } from "@/components/ui/tooltip"
import { Separator } from "@/components/ui/separator"

interface AppSidebarProps {
  activeView: string
  onNavigate: (view: string) => void
  collapsed: boolean
  onToggleCollapse: () => void
}

const navItems = [
  { id: "dashboard", label: "Dashboard", icon: LayoutDashboard, permCategory: "dashboard", permAction: "view" },
  { id: "leads", label: "Leads", icon: Target, permCategory: "leads", permAction: "view" },
  { id: "projects", label: "Projects", icon: Building2, permCategory: "projects", permAction: "view" },
  { id: "tasks", label: "Tasks", icon: ClipboardList, permCategory: "tasks", permAction: "view" },
  { id: "team", label: "Team", icon: Users, permCategory: "team", permAction: "view" },
  { id: "reports", label: "Reports", icon: BarChart3, permCategory: "reports", permAction: "view" },
  { id: "hrms", label: "HRMS", icon: Briefcase, permCategory: "hrms", permAction: "view" },
  { id: "helpdesk", label: "Help Desk", icon: LifeBuoy, permCategory: "helpdesk", permAction: "view" },
]

const adminItems = [
  { id: "admin", label: "Admin Panel", icon: UserCog, permCategory: "admin", permAction: "access" },
  { id: "settings", label: "Settings", icon: Settings, permCategory: "admin", permAction: "access" },
]

export function AppSidebar({ activeView, onNavigate, collapsed, onToggleCollapse }: AppSidebarProps) {
  const { currentUser, logout, hasPermission } = useCRM()

  const renderNavItem = (item: (typeof navItems)[0]) => {
    if (!hasPermission(item.permCategory, item.permAction)) return null
    // Hide team for sales and presales executives
    if (item.id === "team" && currentUser && ["sales_executive", "presales_executive"].includes(currentUser.role)) return null

    const isActive = activeView === item.id
    const Icon = item.icon

    const button = (
      <button
        key={item.id}
        onClick={() => onNavigate(item.id)}
        className={cn(
          "flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-all",
          isActive
            ? "bg-sidebar-primary text-sidebar-primary-foreground"
            : "text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
        )}
      >
        <Icon className="h-5 w-5 shrink-0" />
        {!collapsed && <span>{item.label}</span>}
      </button>
    )

    if (collapsed) {
      return (
        <Tooltip key={item.id}>
          <TooltipTrigger asChild>{button}</TooltipTrigger>
          <TooltipContent side="right" className="bg-foreground text-background">
            {item.label}
          </TooltipContent>
        </Tooltip>
      )
    }

    return button
  }

  return (
    <TooltipProvider delayDuration={0}>
      <aside
        className={cn(
          "flex h-screen flex-col border-r border-sidebar-border bg-sidebar transition-all duration-300",
          collapsed ? "w-[68px]" : "w-[250px]"
        )}
      >
        {/* Logo header */}
        <div className="flex items-center gap-3 px-4 py-5">
          <img
            src="/images/logo-icon.png"
            alt="Hestia Abodes"
            className="h-9 w-auto shrink-0"
          />
          {!collapsed && (
            <div className="flex flex-col">
              <span className="text-sm font-bold text-sidebar-foreground">ORBIT</span>
              <span className="text-[10px] tracking-wider text-sidebar-foreground/50">HESTIA ABODES</span>
            </div>
          )}
        </div>

        <Separator className="bg-sidebar-border" />

        {/* Navigation */}
        <nav className="flex-1 overflow-y-auto px-3 py-4">
          <div className="flex flex-col gap-1">
            {navItems.map(renderNavItem)}
          </div>

          {adminItems.some((item) => hasPermission(item.permCategory, item.permAction)) && (
            <>
              <Separator className="my-4 bg-sidebar-border" />
              {!collapsed && (
                <p className="mb-2 px-3 text-[10px] font-semibold uppercase tracking-wider text-sidebar-foreground/40">
                  Administration
                </p>
              )}
              <div className="flex flex-col gap-1">
                {adminItems.map(renderNavItem)}
              </div>
            </>
          )}
        </nav>

        <Separator className="bg-sidebar-border" />

        {/* User section */}
        <div className="flex flex-col gap-2 px-3 py-4">
          {!collapsed && currentUser && (
            <div className="flex items-center gap-3 rounded-lg bg-sidebar-accent px-3 py-2">
              <div className="flex h-8 w-8 shrink-0 items-center justify-center rounded-full bg-sidebar-primary text-xs font-bold text-sidebar-primary-foreground">
                {currentUser.name.split(" ").map((n) => n[0]).join("")}
              </div>
              <div className="flex flex-col overflow-hidden">
                <span className="truncate text-sm font-medium text-sidebar-foreground">{currentUser.name}</span>
                <span className="truncate text-[10px] text-sidebar-foreground/50">
                  {roleLabels[currentUser.role]}
                </span>
              </div>
            </div>
          )}
          <div className="flex items-center gap-2">
            {collapsed ? (
              <Tooltip>
                <TooltipTrigger asChild>
                  <Button
                    variant="ghost"
                    size="icon"
                    onClick={logout}
                    className="w-full text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
                  >
                    <LogOut className="h-5 w-5" />
                  </Button>
                </TooltipTrigger>
                <TooltipContent side="right" className="bg-foreground text-background">Sign Out</TooltipContent>
              </Tooltip>
            ) : (
              <Button
                variant="ghost"
                onClick={logout}
                className="w-full justify-start gap-3 text-sidebar-foreground/70 hover:bg-sidebar-accent hover:text-sidebar-foreground"
              >
                <LogOut className="h-5 w-5" />
                Sign Out
              </Button>
            )}
          </div>
        </div>

        {/* Collapse toggle */}
        <button
          onClick={onToggleCollapse}
          className="flex items-center justify-center border-t border-sidebar-border py-3 text-sidebar-foreground/50 hover:text-sidebar-foreground"
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="h-4 w-4" /> : <ChevronLeft className="h-4 w-4" />}
        </button>
      </aside>
    </TooltipProvider>
  )
}
