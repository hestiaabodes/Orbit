"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Switch } from "@/components/ui/switch"
import { Badge } from "@/components/ui/badge"
import { Separator } from "@/components/ui/separator"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  Building2,
  Globe,
  Bell,
  Shield,
  Database,
  Mail,
  Phone,
  MapPin,
  Save,
  RefreshCw,
  KeyRound,
  CheckCircle2,
  AlertCircle,
} from "lucide-react"

export function SettingsPage() {
  const { currentUser, users, leads, projects, tasks } = useCRM()

  const [companySettings, setCompanySettings] = useState({
    name: "Hestia Abodes",
    tagline: "Your Space. Your Story.",
    email: "info@hestiaabodes.com",
    phone: "+91 80 4567 8900",
    website: "www.hestiaabodes.com",
    address: "42 Brigade Road, Bangalore, Karnataka 560001",
    gst: "29AABCH1234F1ZK",
    rera: "PRM/KA/RERA/1234/5678",
  })

  const [notifications, setNotifications] = useState({
    emailNewLead: true,
    emailLeadAssigned: true,
    emailTaskAssigned: true,
    emailFollowUpReminder: true,
    emailDailyReport: false,
    emailWeeklyReport: true,
    smsNewLead: false,
    smsFollowUpReminder: true,
  })

  const [passwordForm, setPasswordForm] = useState({ current: "", newPass: "", confirm: "" })
  const [passwordMsg, setPasswordMsg] = useState<{ type: "success" | "error"; text: string } | null>(null)
  const [changingPassword, setChangingPassword] = useState(false)

  const handleChangePassword = async () => {
    setPasswordMsg(null)
    if (passwordForm.newPass !== passwordForm.confirm) {
      setPasswordMsg({ type: "error", text: "New passwords do not match" }); return
    }
    if (passwordForm.newPass.length < 6) {
      setPasswordMsg({ type: "error", text: "Password must be at least 6 characters" }); return
    }
    setChangingPassword(true)
    try {
      const res = await fetch("/api/auth/change-password", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ currentPassword: passwordForm.current, newPassword: passwordForm.newPass }),
      })
      const data = await res.json()
      if (res.ok) {
        setPasswordMsg({ type: "success", text: "Password changed successfully!" })
        setPasswordForm({ current: "", newPass: "", confirm: "" })
      } else {
        setPasswordMsg({ type: "error", text: data.error || "Failed to change password" })
      }
    } catch {
      setPasswordMsg({ type: "error", text: "Could not connect to server" })
    } finally {
      setChangingPassword(false)
    }
  }

  const [leadSettings, setLeadSettings] = useState({
    autoAssign: true,
    duplicateCheck: true,
    followUpReminder: 24,
    autoCloseInactive: 90,
    defaultSource: "Website",
    requirePhone: true,
    requireEmail: false,
  })

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Settings</h1>
        <p className="text-sm text-muted-foreground">Configure your CRM system preferences</p>
      </div>

      <Tabs defaultValue="company">
        <TabsList className="bg-muted">
          <TabsTrigger value="company" className="text-foreground data-[state=active]:bg-background">
            <Building2 className="mr-2 h-4 w-4" /> Company
          </TabsTrigger>
          <TabsTrigger value="notifications" className="text-foreground data-[state=active]:bg-background">
            <Bell className="mr-2 h-4 w-4" /> Notifications
          </TabsTrigger>
          <TabsTrigger value="leads" className="text-foreground data-[state=active]:bg-background">
            <Shield className="mr-2 h-4 w-4" /> Lead Rules
          </TabsTrigger>
          <TabsTrigger value="password" className="text-foreground data-[state=active]:bg-background">
            <KeyRound className="mr-2 h-4 w-4" /> Password
          </TabsTrigger>
          <TabsTrigger value="system" className="text-foreground data-[state=active]:bg-background">
            <Database className="mr-2 h-4 w-4" /> System
          </TabsTrigger>
        </TabsList>

        {/* Company Settings */}
        <TabsContent value="company" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Company Information</CardTitle>
              <CardDescription className="text-muted-foreground">
                Update your company details displayed across the CRM
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="flex items-center gap-6">
                <div className="flex h-20 w-20 shrink-0 items-center justify-center rounded-xl bg-[hsl(30,10%,12%)]">
                  <img src="/images/logo-icon.png" alt="Company logo" className="h-14 w-auto" />
                </div>
                <div className="flex flex-col gap-1">
                  <p className="text-lg font-bold text-foreground">{companySettings.name}</p>
                  <p className="text-sm italic text-muted-foreground">{companySettings.tagline}</p>
                </div>
              </div>

              <Separator />

              <div className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Company Name</Label>
                  <Input
                    value={companySettings.name}
                    onChange={(e) => setCompanySettings({ ...companySettings, name: e.target.value })}
                    className="border-border bg-background text-foreground"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Tagline</Label>
                  <Input
                    value={companySettings.tagline}
                    onChange={(e) => setCompanySettings({ ...companySettings, tagline: e.target.value })}
                    className="border-border bg-background text-foreground"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Email</Label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={companySettings.email}
                      onChange={(e) => setCompanySettings({ ...companySettings, email: e.target.value })}
                      className="border-border bg-background pl-10 text-foreground"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Phone</Label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={companySettings.phone}
                      onChange={(e) => setCompanySettings({ ...companySettings, phone: e.target.value })}
                      className="border-border bg-background pl-10 text-foreground"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Website</Label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                    <Input
                      value={companySettings.website}
                      onChange={(e) => setCompanySettings({ ...companySettings, website: e.target.value })}
                      className="border-border bg-background pl-10 text-foreground"
                    />
                  </div>
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">RERA Number</Label>
                  <Input
                    value={companySettings.rera}
                    onChange={(e) => setCompanySettings({ ...companySettings, rera: e.target.value })}
                    className="border-border bg-background text-foreground"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Address</Label>
                <div className="relative">
                  <MapPin className="absolute left-3 top-3 h-4 w-4 text-muted-foreground" />
                  <Input
                    value={companySettings.address}
                    onChange={(e) => setCompanySettings({ ...companySettings, address: e.target.value })}
                    className="border-border bg-background pl-10 text-foreground"
                  />
                </div>
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">GST Number</Label>
                <Input
                  value={companySettings.gst}
                  onChange={(e) => setCompanySettings({ ...companySettings, gst: e.target.value })}
                  className="border-border bg-background text-foreground"
                />
              </div>
              <Button className="w-fit bg-primary text-primary-foreground hover:bg-primary/90">
                <Save className="mr-2 h-4 w-4" /> Save Changes
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Notifications */}
        <TabsContent value="notifications" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Email Notifications</CardTitle>
              <CardDescription className="text-muted-foreground">
                Configure email notification preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {[
                { key: "emailNewLead", label: "New Lead Created", desc: "Get notified when a new lead is added" },
                { key: "emailLeadAssigned", label: "Lead Assigned", desc: "Notify when a lead is assigned to you" },
                { key: "emailTaskAssigned", label: "Task Assigned", desc: "Notify when a task is assigned to you" },
                { key: "emailFollowUpReminder", label: "Follow-up Reminder", desc: "Remind before scheduled follow-ups" },
                { key: "emailDailyReport", label: "Daily Report", desc: "Receive a daily summary email" },
                { key: "emailWeeklyReport", label: "Weekly Report", desc: "Receive a weekly performance report" },
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-foreground">{item.label}</span>
                    <span className="text-xs text-muted-foreground">{item.desc}</span>
                  </div>
                  <Switch
                    checked={notifications[item.key as keyof typeof notifications]}
                    onCheckedChange={(v) => setNotifications({ ...notifications, [item.key]: v })}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">SMS Notifications</CardTitle>
              <CardDescription className="text-muted-foreground">
                Configure SMS alert preferences
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {[
                { key: "smsNewLead", label: "New Lead Alert", desc: "SMS alert for new hot leads" },
                { key: "smsFollowUpReminder", label: "Follow-up Reminder", desc: "SMS reminder before follow-ups" },
              ].map((item) => (
                <div key={item.key} className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                  <div className="flex flex-col">
                    <span className="text-sm font-medium text-foreground">{item.label}</span>
                    <span className="text-xs text-muted-foreground">{item.desc}</span>
                  </div>
                  <Switch
                    checked={notifications[item.key as keyof typeof notifications]}
                    onCheckedChange={(v) => setNotifications({ ...notifications, [item.key]: v })}
                  />
                </div>
              ))}
            </CardContent>
          </Card>

          <Button className="w-fit bg-primary text-primary-foreground hover:bg-primary/90">
            <Save className="mr-2 h-4 w-4" /> Save Notification Preferences
          </Button>
        </TabsContent>

        {/* Password Change */}
        <TabsContent value="password" className="flex flex-col gap-6">
          <Card className="border-border/60 max-w-lg">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Change Password</CardTitle>
              <CardDescription className="text-muted-foreground">
                Update your account password. This only works when the CRM is connected to the database (on your VPS).
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              {passwordMsg && (
                <div className={`flex items-center gap-2 rounded-lg px-3 py-2 text-sm ${passwordMsg.type === "success" ? "bg-green-50 text-green-700" : "bg-red-50 text-red-700"}`}>
                  {passwordMsg.type === "success" ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
                  {passwordMsg.text}
                </div>
              )}
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Current Password</Label>
                <Input
                  type="password"
                  value={passwordForm.current}
                  onChange={(e) => setPasswordForm({ ...passwordForm, current: e.target.value })}
                  className="border-border bg-background text-foreground"
                  placeholder="Enter current password"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">New Password</Label>
                <Input
                  type="password"
                  value={passwordForm.newPass}
                  onChange={(e) => setPasswordForm({ ...passwordForm, newPass: e.target.value })}
                  className="border-border bg-background text-foreground"
                  placeholder="Enter new password (min 6 characters)"
                />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Confirm New Password</Label>
                <Input
                  type="password"
                  value={passwordForm.confirm}
                  onChange={(e) => setPasswordForm({ ...passwordForm, confirm: e.target.value })}
                  className="border-border bg-background text-foreground"
                  placeholder="Confirm new password"
                />
              </div>
              <Button
                onClick={handleChangePassword}
                disabled={changingPassword || !passwordForm.current || !passwordForm.newPass || !passwordForm.confirm}
                className="w-fit bg-primary text-primary-foreground hover:bg-primary/90"
              >
                <Save className="mr-2 h-4 w-4" /> {changingPassword ? "Changing..." : "Change Password"}
              </Button>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Lead Rules */}
        <TabsContent value="leads" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Lead Assignment Rules</CardTitle>
              <CardDescription className="text-muted-foreground">
                Configure how leads are assigned and managed
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">Auto-Assign Leads</span>
                  <span className="text-xs text-muted-foreground">Automatically distribute new leads to sales executives using round-robin</span>
                </div>
                <Switch
                  checked={leadSettings.autoAssign}
                  onCheckedChange={(v) => setLeadSettings({ ...leadSettings, autoAssign: v })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">Duplicate Detection</span>
                  <span className="text-xs text-muted-foreground">Check for duplicate leads by phone and email</span>
                </div>
                <Switch
                  checked={leadSettings.duplicateCheck}
                  onCheckedChange={(v) => setLeadSettings({ ...leadSettings, duplicateCheck: v })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">Require Phone Number</span>
                  <span className="text-xs text-muted-foreground">Phone number is mandatory when adding leads</span>
                </div>
                <Switch
                  checked={leadSettings.requirePhone}
                  onCheckedChange={(v) => setLeadSettings({ ...leadSettings, requirePhone: v })}
                />
              </div>
              <div className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">Require Email</span>
                  <span className="text-xs text-muted-foreground">Email is mandatory when adding leads</span>
                </div>
                <Switch
                  checked={leadSettings.requireEmail}
                  onCheckedChange={(v) => setLeadSettings({ ...leadSettings, requireEmail: v })}
                />
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Follow-up & Lifecycle</CardTitle>
              <CardDescription className="text-muted-foreground">
                Manage lead follow-up and lifecycle rules
              </CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-4">
              <div className="grid gap-4 md:grid-cols-2">
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Follow-up Reminder (hours before)</Label>
                  <Input
                    type="number"
                    value={leadSettings.followUpReminder}
                    onChange={(e) => setLeadSettings({ ...leadSettings, followUpReminder: parseInt(e.target.value) || 0 })}
                    className="border-border bg-background text-foreground"
                  />
                </div>
                <div className="flex flex-col gap-2">
                  <Label className="text-foreground">Auto-close Inactive Leads (days)</Label>
                  <Input
                    type="number"
                    value={leadSettings.autoCloseInactive}
                    onChange={(e) => setLeadSettings({ ...leadSettings, autoCloseInactive: parseInt(e.target.value) || 0 })}
                    className="border-border bg-background text-foreground"
                  />
                </div>
              </div>
            </CardContent>
          </Card>

          <Button className="w-fit bg-primary text-primary-foreground hover:bg-primary/90">
            <Save className="mr-2 h-4 w-4" /> Save Lead Rules
          </Button>
        </TabsContent>

        {/* System */}
        <TabsContent value="system" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">System Information</CardTitle>
              <CardDescription className="text-muted-foreground">Current system status and details</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              {[
                { label: "CRM Version", value: "1.0.0" },
                { label: "Platform", value: "Hestia Abodes CRM" },
                { label: "Total Users", value: String(users.length) },
                { label: "Total Leads", value: String(leads.length) },
                { label: "Total Projects", value: String(projects.length) },
                { label: "Total Tasks", value: String(tasks.length) },
                { label: "Environment", value: "Production" },
                { label: "Last Updated", value: "Feb 13, 2026" },
              ].map((item) => (
                <div key={item.label} className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                  <span className="text-sm text-muted-foreground">{item.label}</span>
                  <span className="text-sm font-medium text-foreground">{item.value}</span>
                </div>
              ))}
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardHeader>
              <CardTitle className="text-base text-foreground">Data Management</CardTitle>
              <CardDescription className="text-muted-foreground">Export and manage your CRM data</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex flex-wrap gap-3">
                <Button variant="outline" className="border-border text-foreground">
                  Export All Leads (CSV)
                </Button>
                <Button variant="outline" className="border-border text-foreground">
                  Export All Contacts (CSV)
                </Button>
                <Button variant="outline" className="border-border text-foreground">
                  Export Reports (PDF)
                </Button>
                <Button variant="outline" className="border-border text-foreground">
                  <RefreshCw className="mr-2 h-4 w-4" /> Sync Data
                </Button>
              </div>
            </CardContent>
          </Card>

          <Card className="border-border/60 border-destructive/30">
            <CardHeader>
              <CardTitle className="text-base text-destructive">Danger Zone</CardTitle>
              <CardDescription className="text-muted-foreground">Irreversible system actions</CardDescription>
            </CardHeader>
            <CardContent className="flex flex-col gap-3">
              <div className="flex items-center justify-between rounded-lg bg-destructive/5 px-4 py-3">
                <div className="flex flex-col">
                  <span className="text-sm font-medium text-foreground">Reset All Data</span>
                  <span className="text-xs text-muted-foreground">Clear all leads, tasks, and projects. Users will be preserved.</span>
                </div>
                <Button variant="destructive" size="sm">Reset Data</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
