"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Eye, EyeOff, LogIn } from "lucide-react"

export function LoginPage() {
  const { login } = useCRM()
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const [showPassword, setShowPassword] = useState(false)
  const [error, setError] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setError("")
    setIsLoading(true)
    try {
      const success = await login(email, password)
      if (!success) { setError("Invalid email or password. Please try again.") }
    } catch {
      setError("Login failed. Please try again.")
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center bg-[hsl(30,15%,97%)]">
      <div className="flex w-full max-w-5xl items-center gap-12 px-6">
        {/* Left branding section */}
        <div className="hidden flex-1 flex-col items-center justify-center lg:flex">
          <img src="/images/logo-dark.png" alt="Hestia Abodes logo" className="mb-6 h-44 w-auto" />
          <p className="text-center text-lg font-medium text-foreground">
            Hestia Abodes - Founded on the principles of Integrity, Insight, and Impact
          </p>

          {/* ORBIT Branding */}
          <div className="mt-8 rounded-xl border border-primary/20 bg-primary/5 px-6 py-5">
            <div className="mb-3 text-center">
              <h3 className="text-2xl font-bold tracking-wider text-primary">ORBIT</h3>
              <p className="text-xs italic text-muted-foreground">Consistency revolves into success.</p>
            </div>
            <div className="flex flex-col gap-1.5 text-sm">
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">O</span>
                <span className="text-foreground">Opportunities</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">R</span>
                <span className="text-foreground">Relationships</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">B</span>
                <span className="text-foreground">Business</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">I</span>
                <span className="text-foreground">Insights</span>
              </div>
              <div className="flex items-center gap-2">
                <span className="flex h-6 w-6 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">T</span>
                <span className="text-foreground">Team</span>
              </div>
            </div>
          </div>
        </div>

        {/* Login card */}
        <Card className="w-full max-w-md border-border/60 shadow-xl">
          <CardHeader className="text-center">
            <div className="mx-auto mb-2 lg:hidden">
              <img src="/images/logo-dark.png" alt="Hestia Abodes logo" className="h-20 w-auto" />
            </div>
            <div className="mb-1">
              <span className="text-xl font-bold tracking-wider text-primary">ORBIT</span>
              <span className="ml-2 text-xs text-muted-foreground">by Hestia Abodes</span>
            </div>
            <CardTitle className="text-2xl font-bold text-foreground">Welcome Back</CardTitle>
            <CardDescription className="text-muted-foreground">
              Sign in to your ORBIT CRM account
            </CardDescription>
          </CardHeader>
          <CardContent>
            <form onSubmit={handleSubmit} className="flex flex-col gap-4">
              <div className="flex flex-col gap-2">
                <Label htmlFor="email" className="text-foreground">Email</Label>
                <Input id="email" type="email" placeholder="admin@hestiaabodes.in" value={email} onChange={(e) => setEmail(e.target.value)} required className="border-border bg-background text-foreground" />
              </div>
              <div className="flex flex-col gap-2">
                <Label htmlFor="password" className="text-foreground">Password</Label>
                <div className="relative">
                  <Input id="password" type={showPassword ? "text" : "password"} placeholder="Enter your password" value={password} onChange={(e) => setPassword(e.target.value)} required className="border-border bg-background pr-10 text-foreground" />
                  <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground hover:text-foreground" aria-label={showPassword ? "Hide password" : "Show password"}>
                    {showPassword ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                  </button>
                </div>
              </div>
              {error && <p className="rounded-md bg-destructive/10 px-3 py-2 text-sm text-destructive">{error}</p>}
              <Button type="submit" className="mt-2 w-full bg-primary text-primary-foreground hover:bg-primary/90" disabled={isLoading}>
                {isLoading ? (
                  <span className="flex items-center gap-2"><span className="h-4 w-4 animate-spin rounded-full border-2 border-primary-foreground border-t-transparent" />Signing in...</span>
                ) : (
                  <span className="flex items-center gap-2"><LogIn className="h-4 w-4" />Sign In</span>
                )}
              </Button>
              <div className="mt-4 rounded-md bg-muted p-3">
                <p className="mb-2 text-xs font-semibold text-muted-foreground">Demo Credentials:</p>
                <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                  <span><strong>Admin:</strong> admin@hestiaabodes.in / admin123</span>
                  <span><strong>Manager:</strong> priya@hestiaabodes.in / priya123</span>
                  <span><strong>Sales Exec:</strong> amit@hestiaabodes.in / amit123</span>
                  <span><strong>Presales:</strong> vikram@hestiaabodes.in / vikram123</span>
                </div>
              </div>
            </form>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
