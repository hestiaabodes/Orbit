"use client"

import { useState, useMemo } from "react"
import { useCRM } from "@/lib/crm-context"
import { roleLabels, formatDate, documentTypeLabels, type DocumentType, type LeaveType, type ReimbursementCategory, type BankDetails } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog"
import {
  Clock,
  LogIn,
  LogOut,
  CalendarDays,
  Wallet,
  Plus,
  CheckCircle2,
  XCircle,
  Calendar,
  Timer,
  FileText,
  Sun,
  TrendingUp,
  FolderOpen,
  CreditCard,
  ChevronLeft,
  ChevronRight,
  Upload,
  Trash2,
  Building2,
  User,
} from "lucide-react"
import { Separator } from "@/components/ui/separator"

const leaveTypes: { value: LeaveType; label: string }[] = [
  { value: "casual", label: "Casual Leave" },
  { value: "sick", label: "Sick Leave" },
  { value: "earned", label: "Earned Leave" },
  { value: "unpaid", label: "Unpaid Leave" },
  { value: "comp_off", label: "Comp Off" },
]

const reimbursementCategories: { value: ReimbursementCategory; label: string }[] = [
  { value: "travel", label: "Travel" },
  { value: "food", label: "Food & Beverages" },
  { value: "accommodation", label: "Accommodation" },
  { value: "office_supplies", label: "Office Supplies" },
  { value: "client_meeting", label: "Client Meeting" },
  { value: "other", label: "Other" },
]

const statusColors: Record<string, string> = {
  pending: "bg-amber-100 text-amber-800",
  approved: "bg-green-100 text-green-800",
  rejected: "bg-red-100 text-red-800",
  present: "bg-green-100 text-green-800",
  absent: "bg-red-100 text-red-800",
  half_day: "bg-amber-100 text-amber-800",
  week_off: "bg-blue-100 text-blue-800",
  on_leave: "bg-purple-100 text-purple-800",
  leave_requested: "bg-indigo-100 text-indigo-800",
  leave_approved: "bg-teal-100 text-teal-800",
}

const DAYS_OF_WEEK = ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"]
const MONTHS = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

const allDocumentTypes: DocumentType[] = [
  "aadhaar_card", "pan_card", "passport_photo",
  "education_10th", "education_12th", "education_graduation", "education_post_graduation", "education_other",
  "work_experience", "pay_slips", "bank_details",
]

export function HRMSModule() {
  const {
    currentUser,
    getUserById,
    users,
    hasPermission,
    attendance,
    markLogin,
    markLogout,
    leaveRequests,
    addLeaveRequest,
    updateLeaveRequest,
    leaveBalances,
    reimbursements,
    addReimbursement,
    updateReimbursement,
    getScopedAttendance,
    getScopedLeaveRequests,
    getScopedReimbursements,
    getApprovableLeaveRequests,
    getApprovableReimbursements,
    documents,
    addDocument,
    deleteDocument,
    bankDetails,
    updateBankDetails,
  } = useCRM()

  const [activeTab, setActiveTab] = useState("attendance")
  const [showLeaveDialog, setShowLeaveDialog] = useState(false)
  const [showReimbDialog, setShowReimbDialog] = useState(false)
  const [showApprovalDialog, setShowApprovalDialog] = useState(false)
  const [approvalItem, setApprovalItem] = useState<{ type: "leave" | "reimbursement"; id: string; action: "approved" | "rejected" } | null>(null)
  const [approvalRemark, setApprovalRemark] = useState("")
  const [showDocUpload, setShowDocUpload] = useState(false)
  const [showBankDialog, setShowBankDialog] = useState(false)
  const [selectedDocUser, setSelectedDocUser] = useState<string>("")

  // Calendar state
  const [calendarDate, setCalendarDate] = useState(new Date())

  const [leaveForm, setLeaveForm] = useState({
    type: "casual" as LeaveType,
    startDate: "",
    endDate: "",
    reason: "",
  })

  const [reimbForm, setReimbForm] = useState({
    category: "travel" as ReimbursementCategory,
    amount: "",
    description: "",
    date: "",
  })

  const [docForm, setDocForm] = useState({
    type: "aadhaar_card" as DocumentType,
    fileName: "",
  })

  const [bankForm, setBankForm] = useState<BankDetails>({
    userId: "",
    accountHolderName: "",
    bankName: "",
    accountNumber: "",
    ifscCode: "",
    branch: "",
    documentFileName: "",
  })

  // Scoped data
  const scopedAttendance = getScopedAttendance()
  const scopedLeaveRequests = getScopedLeaveRequests()
  const scopedReimbursements = getScopedReimbursements()
  const approvableLeaves = getApprovableLeaveRequests()
  const approvableReimbs = getApprovableReimbursements()

  const today = new Date().toISOString().split("T")[0]
  const todayAttendance = attendance.find((a) => a.userId === currentUser?.id && a.date === today)
  const isLoggedIn = todayAttendance && todayAttendance.loginTime && !todayAttendance.logoutTime
  const isLoggedOut = todayAttendance && todayAttendance.logoutTime

  // Leave balance for current user
  const myBalance = leaveBalances.find((lb) => lb.userId === currentUser?.id)

  // Determine which user's docs to show
  const docUserId = selectedDocUser || currentUser?.id || ""
  const userDocs = documents.filter((d) => d.userId === docUserId)
  const userBank = bankDetails.find((b) => b.userId === docUserId)

  // Users the current user can view docs for (scoped)
  const viewableDocUsers = useMemo(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return users.filter((u) => u.isActive)
    if (currentUser.role === "manager") {
      return users.filter((u) => u.isActive && (u.id === currentUser.id || u.managerId === currentUser.id))
    }
    return [currentUser]
  }, [currentUser, users])

  // Calendar data for the current month
  const calendarData = useMemo(() => {
    const year = calendarDate.getFullYear()
    const month = calendarDate.getMonth()
    const firstDay = new Date(year, month, 1)
    const lastDay = new Date(year, month + 1, 0)
    const startPadding = firstDay.getDay()
    const totalDays = lastDay.getDate()

    const days: Array<{
      date: string
      day: number
      isCurrentMonth: boolean
      status?: string
      isToday: boolean
      isWeekOff: boolean
    }> = []

    // Padding days from previous month
    for (let i = startPadding - 1; i >= 0; i--) {
      const d = new Date(year, month, -i)
      days.push({
        date: d.toISOString().split("T")[0],
        day: d.getDate(),
        isCurrentMonth: false,
        isToday: false,
        isWeekOff: false,
      })
    }

    // Current month days
    for (let d = 1; d <= totalDays; d++) {
      const dateObj = new Date(year, month, d)
      const dateStr = dateObj.toISOString().split("T")[0]
      const dayName = ["sunday", "monday", "tuesday", "wednesday", "thursday", "friday", "saturday"][dateObj.getDay()]
      const isWeekOff = currentUser?.weekOffs?.includes(dayName) || false

      // Find attendance record
      const attRecord = attendance.find((a) => a.userId === currentUser?.id && a.date === dateStr)
      // Find leave request
      const leaveReq = leaveRequests.find((lr) =>
        lr.userId === currentUser?.id &&
        lr.status === "approved" &&
        dateStr >= lr.startDate && dateStr <= lr.endDate
      )

      let status: string | undefined
      if (attRecord) {
        status = attRecord.status
      } else if (leaveReq) {
        status = "leave_approved"
      } else if (isWeekOff && dateObj <= new Date()) {
        status = "week_off"
      }

      days.push({
        date: dateStr,
        day: d,
        isCurrentMonth: true,
        status,
        isToday: dateStr === today,
        isWeekOff,
      })
    }

    // Padding days for next month to fill 6 rows
    const remaining = 42 - days.length
    for (let i = 1; i <= remaining; i++) {
      const d = new Date(year, month + 1, i)
      days.push({
        date: d.toISOString().split("T")[0],
        day: d.getDate(),
        isCurrentMonth: false,
        isToday: false,
        isWeekOff: false,
      })
    }

    return days
  }, [calendarDate, attendance, leaveRequests, currentUser, today])

  // Calculate leave days
  const calcDays = (start: string, end: string) => {
    if (!start || !end) return 0
    const s = new Date(start)
    const e = new Date(end)
    const diff = Math.ceil((e.getTime() - s.getTime()) / (1000 * 60 * 60 * 24)) + 1
    return Math.max(diff, 0)
  }

  const handleAddLeave = () => {
    if (!currentUser) return
    const days = calcDays(leaveForm.startDate, leaveForm.endDate)
    addLeaveRequest({
      userId: currentUser.id,
      type: leaveForm.type,
      startDate: leaveForm.startDate,
      endDate: leaveForm.endDate,
      days,
      reason: leaveForm.reason,
    })
    setShowLeaveDialog(false)
    setLeaveForm({ type: "casual", startDate: "", endDate: "", reason: "" })
  }

  const handleAddReimb = () => {
    if (!currentUser) return
    addReimbursement({
      userId: currentUser.id,
      category: reimbForm.category,
      amount: parseFloat(reimbForm.amount) || 0,
      description: reimbForm.description,
      date: reimbForm.date,
    })
    setShowReimbDialog(false)
    setReimbForm({ category: "travel", amount: "", description: "", date: "" })
  }

  const handleApproval = () => {
    if (!approvalItem || !currentUser) return
    if (approvalItem.type === "leave") {
      updateLeaveRequest(approvalItem.id, {
        status: approvalItem.action,
        approvedBy: currentUser.id,
        remark: approvalRemark || undefined,
      })
    } else {
      updateReimbursement(approvalItem.id, {
        status: approvalItem.action,
        approvedBy: currentUser.id,
        remark: approvalRemark || undefined,
      })
    }
    setShowApprovalDialog(false)
    setApprovalItem(null)
    setApprovalRemark("")
  }

  const openApproval = (type: "leave" | "reimbursement", id: string, action: "approved" | "rejected") => {
    setApprovalItem({ type, id, action })
    setApprovalRemark("")
    setShowApprovalDialog(true)
  }

  const handleAddDocument = () => {
    if (!docUserId || !docForm.fileName) return
    addDocument({
      userId: docUserId,
      type: docForm.type,
      label: documentTypeLabels[docForm.type],
      fileName: docForm.fileName,
    })
    setShowDocUpload(false)
    setDocForm({ type: "aadhaar_card", fileName: "" })
  }

  const handleSaveBankDetails = () => {
    if (!bankForm.userId) return
    updateBankDetails(bankForm.userId, bankForm)
    setShowBankDialog(false)
  }

  const openBankEdit = (userId: string) => {
    const existing = bankDetails.find((b) => b.userId === userId)
    const user = getUserById(userId)
    setBankForm(existing || {
      userId,
      accountHolderName: user?.name || "",
      bankName: "",
      accountNumber: "",
      ifscCode: "",
      branch: "",
      documentFileName: "",
    })
    setShowBankDialog(true)
  }

  const pendingApprovalsCount = approvableLeaves.length + approvableReimbs.length

  const prevMonth = () => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() - 1, 1))
  const nextMonth = () => setCalendarDate(new Date(calendarDate.getFullYear(), calendarDate.getMonth() + 1, 1))

  const getStatusColor = (status?: string) => {
    if (!status) return ""
    const colors: Record<string, string> = {
      present: "bg-green-500",
      absent: "bg-red-500",
      half_day: "bg-amber-500",
      week_off: "bg-blue-400",
      leave_requested: "bg-indigo-400",
      leave_approved: "bg-teal-500",
    }
    return colors[status] || ""
  }

  const isExecutive = currentUser?.role === "sales_executive" || currentUser?.role === "presales_executive"
  const canApprove = currentUser?.role === "manager" || currentUser?.role === "admin"

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">HRMS</h1>
          <p className="text-sm text-muted-foreground">
            Attendance, leaves, reimbursements, documents, and team management
          </p>
        </div>
        {pendingApprovalsCount > 0 && canApprove && (
          <Badge variant="secondary" className="bg-amber-100 text-amber-800 text-sm px-3 py-1">
            {pendingApprovalsCount} pending approval{pendingApprovalsCount > 1 ? "s" : ""}
          </Badge>
        )}
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
              <Clock className="h-6 w-6 text-primary" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-foreground">
                {isLoggedIn ? "Checked In" : isLoggedOut ? "Checked Out" : "Not Checked In"}
              </span>
              <span className="text-xs text-muted-foreground">
                {todayAttendance?.loginTime ? `In: ${todayAttendance.loginTime}` : "Today"}
              </span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(160,45%,40%)]/10">
              <CalendarDays className="h-6 w-6 text-[hsl(160,45%,40%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-foreground">
                {myBalance ? (myBalance.casual.total - myBalance.casual.used) + (myBalance.earned.total - myBalance.earned.used) : 0}
              </span>
              <span className="text-xs text-muted-foreground">Leaves Remaining</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(210,50%,50%)]/10">
              <FileText className="h-6 w-6 text-[hsl(210,50%,50%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-foreground">
                {scopedLeaveRequests.filter((lr) => lr.status === "pending").length}
              </span>
              <span className="text-xs text-muted-foreground">Pending Leaves</span>
            </div>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(37,50%,70%)]/10">
              <Wallet className="h-6 w-6 text-[hsl(37,50%,70%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-sm font-semibold text-foreground">
                {scopedReimbursements.filter((r) => r.status === "pending").length}
              </span>
              <span className="text-xs text-muted-foreground">Pending Reimbursements</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Attendance Action */}
      <Card className="border-border/60">
        <CardContent className="flex flex-wrap items-center justify-between gap-4 p-5">
          <div className="flex flex-col gap-1">
            <span className="text-sm font-semibold text-foreground">
              {new Date().toLocaleDateString("en-IN", { weekday: "long", year: "numeric", month: "long", day: "numeric" })}
            </span>
            <span className="text-xs text-muted-foreground">
              {todayAttendance?.loginTime && `Login: ${todayAttendance.loginTime}`}
              {todayAttendance?.logoutTime && ` | Logout: ${todayAttendance.logoutTime}`}
              {todayAttendance?.totalHours && todayAttendance.totalHours !== "-" && ` | Total: ${todayAttendance.totalHours}`}
            </span>
          </div>
          <div className="flex items-center gap-2">
            {!isLoggedIn && !isLoggedOut && (
              <Button size="sm" className="bg-[hsl(160,45%,40%)] text-white hover:bg-[hsl(160,45%,35%)]" onClick={() => currentUser && markLogin(currentUser.id)}>
                <LogIn className="mr-2 h-4 w-4" /> Clock In
              </Button>
            )}
            {isLoggedIn && (
              <Button size="sm" variant="outline" className="border-destructive text-destructive hover:bg-destructive/10" onClick={() => currentUser && markLogout(currentUser.id)}>
                <LogOut className="mr-2 h-4 w-4" /> Clock Out
              </Button>
            )}
            {isLoggedOut && (
              <Badge variant="secondary" className="bg-green-100 text-green-800">
                <CheckCircle2 className="mr-1 h-3.5 w-3.5" /> Completed for today
              </Badge>
            )}
          </div>
        </CardContent>
      </Card>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-muted flex-wrap">
          <TabsTrigger value="attendance" className="text-foreground data-[state=active]:bg-background">
            <Timer className="mr-1.5 h-4 w-4" /> Attendance
          </TabsTrigger>
          <TabsTrigger value="calendar" className="text-foreground data-[state=active]:bg-background">
            <Calendar className="mr-1.5 h-4 w-4" /> Calendar
          </TabsTrigger>
          <TabsTrigger value="leaves" className="text-foreground data-[state=active]:bg-background">
            <CalendarDays className="mr-1.5 h-4 w-4" /> Leaves
          </TabsTrigger>
          <TabsTrigger value="reimbursements" className="text-foreground data-[state=active]:bg-background">
            <Wallet className="mr-1.5 h-4 w-4" /> Reimbursements
          </TabsTrigger>
          {canApprove && (
            <TabsTrigger value="approvals" className="relative text-foreground data-[state=active]:bg-background">
              <CheckCircle2 className="mr-1.5 h-4 w-4" /> Approvals
              {pendingApprovalsCount > 0 && (
                <span className="ml-1.5 flex h-5 w-5 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">
                  {pendingApprovalsCount}
                </span>
              )}
            </TabsTrigger>
          )}
          <TabsTrigger value="documents" className="text-foreground data-[state=active]:bg-background">
            <FolderOpen className="mr-1.5 h-4 w-4" /> Documents
          </TabsTrigger>
          <TabsTrigger value="weekoffs" className="text-foreground data-[state=active]:bg-background">
            <Sun className="mr-1.5 h-4 w-4" /> Week-offs
          </TabsTrigger>
          <TabsTrigger value="balance" className="text-foreground data-[state=active]:bg-background">
            <TrendingUp className="mr-1.5 h-4 w-4" /> Leave Balance
          </TabsTrigger>
        </TabsList>

        {/* Attendance Tab */}
        <TabsContent value="attendance" className="flex flex-col gap-4">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Attendance Log</CardTitle>
              <CardDescription className="text-muted-foreground">
                {isExecutive ? "Your attendance records" : "Team attendance records"}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    {!isExecutive && <TableHead className="text-foreground">Employee</TableHead>}
                    <TableHead className="text-foreground">Date</TableHead>
                    <TableHead className="text-foreground">Login Time</TableHead>
                    <TableHead className="text-foreground">Logout Time</TableHead>
                    <TableHead className="text-foreground">Total Hours</TableHead>
                    <TableHead className="text-foreground">Status</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopedAttendance
                    .sort((a, b) => b.date.localeCompare(a.date))
                    .map((record) => {
                      const user = getUserById(record.userId)
                      return (
                        <TableRow key={record.id}>
                          {!isExecutive && (
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                          )}
                          <TableCell className="text-foreground">{formatDate(record.date)}</TableCell>
                          <TableCell className="text-foreground">{record.loginTime || "-"}</TableCell>
                          <TableCell className="text-foreground">{record.logoutTime || "-"}</TableCell>
                          <TableCell className="text-foreground">{record.totalHours}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={statusColors[record.status] || "bg-muted text-foreground"}>
                              {record.status.replace(/_/g, " ")}
                            </Badge>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  {scopedAttendance.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={!isExecutive ? 6 : 5} className="py-8 text-center text-muted-foreground">
                        No attendance records found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Calendar Tab */}
        <TabsContent value="calendar" className="flex flex-col gap-4">
          <Card className="border-border/60">
            <CardHeader className="pb-3">
              <div className="flex items-center justify-between">
                <CardTitle className="text-base text-foreground">Attendance Calendar</CardTitle>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" onClick={prevMonth} className="h-8 w-8 text-foreground">
                    <ChevronLeft className="h-4 w-4" />
                  </Button>
                  <span className="min-w-[160px] text-center text-sm font-semibold text-foreground">
                    {MONTHS[calendarDate.getMonth()]} {calendarDate.getFullYear()}
                  </span>
                  <Button variant="ghost" size="icon" onClick={nextMonth} className="h-8 w-8 text-foreground">
                    <ChevronRight className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            </CardHeader>
            <CardContent>
              {/* Day headers */}
              <div className="grid grid-cols-7 gap-1 mb-1">
                {DAYS_OF_WEEK.map((day) => (
                  <div key={day} className="py-2 text-center text-xs font-semibold text-muted-foreground">
                    {day}
                  </div>
                ))}
              </div>
              {/* Calendar grid */}
              <div className="grid grid-cols-7 gap-1">
                {calendarData.map((cell, idx) => (
                  <div
                    key={idx}
                    className={`relative flex min-h-[56px] flex-col items-center justify-center rounded-lg border p-1 text-sm transition-colors ${
                      !cell.isCurrentMonth
                        ? "border-transparent text-muted-foreground/40"
                        : cell.isToday
                          ? "border-primary bg-primary/5 font-bold text-primary"
                          : "border-border/40 text-foreground"
                    }`}
                  >
                    <span className="text-xs">{cell.day}</span>
                    {cell.isCurrentMonth && cell.status && (
                      <span className={`mt-0.5 h-2 w-2 rounded-full ${getStatusColor(cell.status)}`} />
                    )}
                    {cell.isCurrentMonth && cell.isWeekOff && !cell.status && (
                      <span className="mt-0.5 text-[8px] font-medium text-blue-500">OFF</span>
                    )}
                  </div>
                ))}
              </div>
              {/* Legend */}
              <div className="mt-4 flex flex-wrap items-center gap-4">
                {[
                  { color: "bg-green-500", label: "Present" },
                  { color: "bg-red-500", label: "Absent" },
                  { color: "bg-amber-500", label: "Half Day" },
                  { color: "bg-blue-400", label: "Week Off" },
                  { color: "bg-teal-500", label: "On Leave" },
                ].map((item) => (
                  <div key={item.label} className="flex items-center gap-1.5">
                    <span className={`h-2.5 w-2.5 rounded-full ${item.color}`} />
                    <span className="text-xs text-muted-foreground">{item.label}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Leaves Tab */}
        <TabsContent value="leaves" className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-foreground">Leave Requests</h3>
              <p className="text-xs text-muted-foreground">Apply for leave and track your requests</p>
            </div>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setShowLeaveDialog(true)}>
              <Plus className="mr-2 h-4 w-4" /> Apply Leave
            </Button>
          </div>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    {!isExecutive && <TableHead className="text-foreground">Employee</TableHead>}
                    <TableHead className="text-foreground">Type</TableHead>
                    <TableHead className="text-foreground">Start Date</TableHead>
                    <TableHead className="text-foreground">End Date</TableHead>
                    <TableHead className="text-foreground">Days</TableHead>
                    <TableHead className="text-foreground">Reason</TableHead>
                    <TableHead className="text-foreground">Status</TableHead>
                    <TableHead className="text-foreground">Approved By</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopedLeaveRequests
                    .sort((a, b) => b.appliedOn.localeCompare(a.appliedOn))
                    .map((lr) => {
                      const user = getUserById(lr.userId)
                      const approver = lr.approvedBy ? getUserById(lr.approvedBy) : null
                      return (
                        <TableRow key={lr.id}>
                          {!isExecutive && (
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                          )}
                          <TableCell className="text-foreground capitalize">{lr.type.replace(/_/g, " ")}</TableCell>
                          <TableCell className="text-foreground">{formatDate(lr.startDate)}</TableCell>
                          <TableCell className="text-foreground">{formatDate(lr.endDate)}</TableCell>
                          <TableCell className="text-foreground">{lr.days}</TableCell>
                          <TableCell className="max-w-[200px] truncate text-foreground">{lr.reason}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={statusColors[lr.status]}>{lr.status}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {approver?.name || "-"}
                            {lr.remark && <p className="text-[10px] text-muted-foreground italic">{lr.remark}</p>}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  {scopedLeaveRequests.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={!isExecutive ? 8 : 7} className="py-8 text-center text-muted-foreground">
                        No leave requests found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Reimbursements Tab */}
        <TabsContent value="reimbursements" className="flex flex-col gap-4">
          <div className="flex items-center justify-between">
            <div>
              <h3 className="text-base font-semibold text-foreground">Reimbursements</h3>
              <p className="text-xs text-muted-foreground">Submit expense claims and track status</p>
            </div>
            <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setShowReimbDialog(true)}>
              <Plus className="mr-2 h-4 w-4" /> New Claim
            </Button>
          </div>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    {!isExecutive && <TableHead className="text-foreground">Employee</TableHead>}
                    <TableHead className="text-foreground">Category</TableHead>
                    <TableHead className="text-foreground">Amount</TableHead>
                    <TableHead className="text-foreground">Date</TableHead>
                    <TableHead className="text-foreground">Description</TableHead>
                    <TableHead className="text-foreground">Status</TableHead>
                    <TableHead className="text-foreground">Approved By</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {scopedReimbursements
                    .sort((a, b) => b.appliedOn.localeCompare(a.appliedOn))
                    .map((r) => {
                      const user = getUserById(r.userId)
                      const approver = r.approvedBy ? getUserById(r.approvedBy) : null
                      return (
                        <TableRow key={r.id}>
                          {!isExecutive && (
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                          )}
                          <TableCell className="text-foreground capitalize">{r.category.replace(/_/g, " ")}</TableCell>
                          <TableCell className="font-medium text-foreground">
                            {"Rs."} {r.amount.toLocaleString("en-IN")}
                          </TableCell>
                          <TableCell className="text-foreground">{formatDate(r.date)}</TableCell>
                          <TableCell className="max-w-[200px] truncate text-foreground">{r.description}</TableCell>
                          <TableCell>
                            <Badge variant="secondary" className={statusColors[r.status]}>{r.status}</Badge>
                          </TableCell>
                          <TableCell className="text-sm text-muted-foreground">
                            {approver?.name || "-"}
                            {r.remark && <p className="text-[10px] text-muted-foreground italic">{r.remark}</p>}
                          </TableCell>
                        </TableRow>
                      )
                    })}
                  {scopedReimbursements.length === 0 && (
                    <TableRow>
                      <TableCell colSpan={!isExecutive ? 7 : 6} className="py-8 text-center text-muted-foreground">
                        No reimbursement claims found
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Approvals Tab -- Managers & Admin only */}
        <TabsContent value="approvals" className="flex flex-col gap-6">
          {/* Leave Approvals */}
          <div>
            <h3 className="mb-3 text-base font-semibold text-foreground">Pending Leave Approvals</h3>
            {approvableLeaves.length > 0 ? (
              <Card className="border-border/60">
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="text-foreground">Employee</TableHead>
                        <TableHead className="text-foreground">Type</TableHead>
                        <TableHead className="text-foreground">Dates</TableHead>
                        <TableHead className="text-foreground">Days</TableHead>
                        <TableHead className="text-foreground">Reason</TableHead>
                        <TableHead className="text-foreground">Applied On</TableHead>
                        <TableHead className="text-right text-foreground">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {approvableLeaves.map((lr) => {
                        const user = getUserById(lr.userId)
                        return (
                          <TableRow key={lr.id}>
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                            <TableCell className="text-foreground capitalize">{lr.type.replace(/_/g, " ")}</TableCell>
                            <TableCell className="text-foreground">{formatDate(lr.startDate)} to {formatDate(lr.endDate)}</TableCell>
                            <TableCell className="text-foreground">{lr.days}</TableCell>
                            <TableCell className="max-w-[180px] truncate text-foreground">{lr.reason}</TableCell>
                            <TableCell className="text-muted-foreground">{formatDate(lr.appliedOn)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button size="sm" variant="ghost" className="h-8 text-green-700 hover:bg-green-50 hover:text-green-800" onClick={() => openApproval("leave", lr.id, "approved")}>
                                  <CheckCircle2 className="mr-1 h-4 w-4" /> Approve
                                </Button>
                                <Button size="sm" variant="ghost" className="h-8 text-red-700 hover:bg-red-50 hover:text-red-800" onClick={() => openApproval("leave", lr.id, "rejected")}>
                                  <XCircle className="mr-1 h-4 w-4" /> Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border/60">
                <CardContent className="flex items-center justify-center p-8">
                  <p className="text-sm text-muted-foreground">No pending leave requests to approve</p>
                </CardContent>
              </Card>
            )}
          </div>

          {/* Reimbursement Approvals */}
          <div>
            <h3 className="mb-3 text-base font-semibold text-foreground">Pending Reimbursement Approvals</h3>
            {approvableReimbs.length > 0 ? (
              <Card className="border-border/60">
                <CardContent className="p-0">
                  <Table>
                    <TableHeader>
                      <TableRow className="hover:bg-transparent">
                        <TableHead className="text-foreground">Employee</TableHead>
                        <TableHead className="text-foreground">Category</TableHead>
                        <TableHead className="text-foreground">Amount</TableHead>
                        <TableHead className="text-foreground">Date</TableHead>
                        <TableHead className="text-foreground">Description</TableHead>
                        <TableHead className="text-foreground">Applied On</TableHead>
                        <TableHead className="text-right text-foreground">Action</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {approvableReimbs.map((r) => {
                        const user = getUserById(r.userId)
                        return (
                          <TableRow key={r.id}>
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                            <TableCell className="text-foreground capitalize">{r.category.replace(/_/g, " ")}</TableCell>
                            <TableCell className="font-medium text-foreground">{"Rs."} {r.amount.toLocaleString("en-IN")}</TableCell>
                            <TableCell className="text-foreground">{formatDate(r.date)}</TableCell>
                            <TableCell className="max-w-[180px] truncate text-foreground">{r.description}</TableCell>
                            <TableCell className="text-muted-foreground">{formatDate(r.appliedOn)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex items-center justify-end gap-1">
                                <Button size="sm" variant="ghost" className="h-8 text-green-700 hover:bg-green-50 hover:text-green-800" onClick={() => openApproval("reimbursement", r.id, "approved")}>
                                  <CheckCircle2 className="mr-1 h-4 w-4" /> Approve
                                </Button>
                                <Button size="sm" variant="ghost" className="h-8 text-red-700 hover:bg-red-50 hover:text-red-800" onClick={() => openApproval("reimbursement", r.id, "rejected")}>
                                  <XCircle className="mr-1 h-4 w-4" /> Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        )
                      })}
                    </TableBody>
                  </Table>
                </CardContent>
              </Card>
            ) : (
              <Card className="border-border/60">
                <CardContent className="flex items-center justify-center p-8">
                  <p className="text-sm text-muted-foreground">No pending reimbursements to approve</p>
                </CardContent>
              </Card>
            )}
          </div>
        </TabsContent>

        {/* Documents Tab */}
        <TabsContent value="documents" className="flex flex-col gap-4">
          <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
            <div>
              <h3 className="text-base font-semibold text-foreground">Employee Documents</h3>
              <p className="text-xs text-muted-foreground">Upload and manage employee documents and bank details</p>
            </div>
            <div className="flex items-center gap-2">
              {viewableDocUsers.length > 1 && (
                <Select value={docUserId} onValueChange={setSelectedDocUser}>
                  <SelectTrigger className="w-[200px] border-border bg-background text-foreground">
                    <SelectValue placeholder="Select employee" />
                  </SelectTrigger>
                  <SelectContent>
                    {viewableDocUsers.map((u) => (
                      <SelectItem key={u.id} value={u.id}>{u.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              )}
              <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => setShowDocUpload(true)}>
                <Upload className="mr-2 h-4 w-4" /> Upload
              </Button>
            </div>
          </div>

          <div className="grid gap-4 lg:grid-cols-2">
            {/* Documents List */}
            <Card className="border-border/60">
              <CardHeader className="pb-2">
                <CardTitle className="flex items-center gap-2 text-base text-foreground">
                  <FolderOpen className="h-4 w-4" /> Documents
                </CardTitle>
                <CardDescription className="text-muted-foreground">
                  {getUserById(docUserId)?.name || "Employee"} - uploaded documents
                </CardDescription>
              </CardHeader>
              <CardContent>
                {allDocumentTypes.map((docType) => {
                  const doc = userDocs.find((d) => d.type === docType)
                  return (
                    <div key={docType} className="flex items-center justify-between border-b border-border/40 py-3 last:border-0">
                      <div className="flex flex-col">
                        <span className="text-sm font-medium text-foreground">{documentTypeLabels[docType]}</span>
                        {doc ? (
                          <span className="text-xs text-muted-foreground">
                            {doc.fileName} - uploaded {formatDate(doc.uploadedAt)}
                          </span>
                        ) : (
                          <span className="text-xs text-muted-foreground/50">Not uploaded</span>
                        )}
                      </div>
                      <div className="flex items-center gap-1">
                        {doc ? (
                          <>
                            <Badge variant="secondary" className="bg-green-100 text-green-800 text-[10px]">Uploaded</Badge>
                            {(currentUser?.role === "admin" || docUserId === currentUser?.id) && (
                              <Button variant="ghost" size="icon" className="h-7 w-7 text-destructive hover:bg-destructive/10" onClick={() => deleteDocument(doc.id)}>
                                <Trash2 className="h-3.5 w-3.5" />
                              </Button>
                            )}
                          </>
                        ) : (
                          <Badge variant="secondary" className="bg-muted text-muted-foreground text-[10px]">Missing</Badge>
                        )}
                      </div>
                    </div>
                  )
                })}
              </CardContent>
            </Card>

            {/* Bank Details */}
            <Card className="border-border/60">
              <CardHeader className="pb-2">
                <div className="flex items-center justify-between">
                  <div>
                    <CardTitle className="flex items-center gap-2 text-base text-foreground">
                      <CreditCard className="h-4 w-4" /> Bank Details
                    </CardTitle>
                    <CardDescription className="text-muted-foreground">
                      {getUserById(docUserId)?.name || "Employee"} - bank account information
                    </CardDescription>
                  </div>
                  {(currentUser?.role === "admin" || docUserId === currentUser?.id) && (
                    <Button size="sm" variant="outline" className="border-border text-foreground" onClick={() => openBankEdit(docUserId)}>
                      {userBank ? "Edit" : "Add"}
                    </Button>
                  )}
                </div>
              </CardHeader>
              <CardContent>
                {userBank ? (
                  <div className="flex flex-col gap-3">
                    {[
                      { label: "Account Holder", value: userBank.accountHolderName, icon: User },
                      { label: "Bank Name", value: userBank.bankName, icon: Building2 },
                      { label: "Account Number", value: userBank.accountNumber, icon: CreditCard },
                      { label: "IFSC Code", value: userBank.ifscCode, icon: FileText },
                      { label: "Branch", value: userBank.branch, icon: Building2 },
                    ].map((item) => (
                      <div key={item.label} className="flex items-center gap-3 rounded-lg bg-muted/50 px-4 py-3">
                        <item.icon className="h-4 w-4 text-muted-foreground" />
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">{item.label}</span>
                          <span className="text-sm font-medium text-foreground">{item.value || "-"}</span>
                        </div>
                      </div>
                    ))}
                    {userBank.documentFileName && (
                      <div className="flex items-center gap-3 rounded-lg bg-muted/50 px-4 py-3">
                        <FileText className="h-4 w-4 text-muted-foreground" />
                        <div className="flex flex-col">
                          <span className="text-[10px] uppercase tracking-wider text-muted-foreground">Document</span>
                          <span className="text-sm font-medium text-foreground">{userBank.documentFileName}</span>
                        </div>
                      </div>
                    )}
                  </div>
                ) : (
                  <div className="flex flex-col items-center justify-center py-8 text-center">
                    <CreditCard className="mb-2 h-8 w-8 text-muted-foreground/40" />
                    <p className="text-sm text-muted-foreground">No bank details added yet</p>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Week-offs Tab */}
        <TabsContent value="weekoffs" className="flex flex-col gap-4">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Week-off Schedule</CardTitle>
              <CardDescription className="text-muted-foreground">
                {isExecutive ? "Your weekly off days" : "Weekly off days for each team member"}
              </CardDescription>
            </CardHeader>
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground">Employee</TableHead>
                    <TableHead className="text-foreground">Role</TableHead>
                    <TableHead className="text-foreground">Department</TableHead>
                    <TableHead className="text-foreground">Week-offs</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {(isExecutive ? [currentUser!] : users.filter((u) => u.isActive))
                    .map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium text-foreground">{user.name}</TableCell>
                        <TableCell className="text-foreground">{roleLabels[user.role]}</TableCell>
                        <TableCell className="text-foreground">{user.department}</TableCell>
                        <TableCell>
                          <div className="flex items-center gap-1.5">
                            {user.weekOffs.map((day) => (
                              <Badge key={day} variant="secondary" className="bg-blue-100 text-blue-800 capitalize text-xs">
                                {day}
                              </Badge>
                            ))}
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Leave Balance Tab */}
        <TabsContent value="balance" className="flex flex-col gap-4">
          {/* My balance card */}
          {myBalance && (
            <Card className="border-border/60">
              <CardHeader className="pb-3">
                <CardTitle className="text-base text-foreground">Your Leave Balance</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
                  {(["casual", "sick", "earned", "comp_off"] as const).map((type) => {
                    const b = myBalance[type]
                    const remaining = b.total - b.used
                    return (
                      <div key={type} className="rounded-lg border border-border bg-muted/50 p-4">
                        <p className="text-xs text-muted-foreground capitalize">{type.replace(/_/g, " ")}</p>
                        <p className="mt-1 text-2xl font-bold text-foreground">{remaining}</p>
                        <p className="text-xs text-muted-foreground">{b.used} used of {b.total}</p>
                        <div className="mt-2 h-2 rounded-full bg-muted">
                          <div
                            className="h-2 rounded-full bg-primary"
                            style={{ width: `${b.total > 0 ? (remaining / b.total) * 100 : 0}%` }}
                          />
                        </div>
                      </div>
                    )
                  })}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Team balance -- for managers & admins */}
          {!isExecutive && (
            <Card className="border-border/60">
              <CardHeader className="pb-2">
                <CardTitle className="text-base text-foreground">Team Leave Balances</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-foreground">Employee</TableHead>
                      <TableHead className="text-foreground">Casual</TableHead>
                      <TableHead className="text-foreground">Sick</TableHead>
                      <TableHead className="text-foreground">Earned</TableHead>
                      <TableHead className="text-foreground">Comp Off</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {leaveBalances
                      .filter((lb) => {
                        const user = getUserById(lb.userId)
                        if (!user || !user.isActive) return false
                        if (currentUser?.role === "admin") return true
                        if (currentUser?.role === "manager") {
                          return lb.userId === currentUser.id || user.managerId === currentUser.id
                        }
                        return lb.userId === currentUser?.id
                      })
                      .map((lb) => {
                        const user = getUserById(lb.userId)
                        return (
                          <TableRow key={lb.userId}>
                            <TableCell className="font-medium text-foreground">{user?.name || "-"}</TableCell>
                            <TableCell className="text-foreground">{lb.casual.total - lb.casual.used} / {lb.casual.total}</TableCell>
                            <TableCell className="text-foreground">{lb.sick.total - lb.sick.used} / {lb.sick.total}</TableCell>
                            <TableCell className="text-foreground">{lb.earned.total - lb.earned.used} / {lb.earned.total}</TableCell>
                            <TableCell className="text-foreground">{lb.comp_off.total - lb.comp_off.used} / {lb.comp_off.total}</TableCell>
                          </TableRow>
                        )
                      })}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>

      {/* Apply Leave Dialog */}
      <Dialog open={showLeaveDialog} onOpenChange={setShowLeaveDialog}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Apply for Leave</DialogTitle>
            <DialogDescription className="text-muted-foreground">Submit a leave request to your manager</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Leave Type</Label>
              <Select value={leaveForm.type} onValueChange={(v) => setLeaveForm({ ...leaveForm, type: v as LeaveType })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {leaveTypes.map((lt) => (
                    <SelectItem key={lt.value} value={lt.value}>{lt.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {myBalance && leaveForm.type !== "unpaid" && (
                <p className="text-xs text-muted-foreground">
                  Available: {(myBalance[leaveForm.type as keyof typeof myBalance] as { total: number; used: number }).total - (myBalance[leaveForm.type as keyof typeof myBalance] as { total: number; used: number }).used} days
                </p>
              )}
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Start Date</Label>
                <Input type="date" value={leaveForm.startDate} onChange={(e) => setLeaveForm({ ...leaveForm, startDate: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">End Date</Label>
                <Input type="date" value={leaveForm.endDate} onChange={(e) => setLeaveForm({ ...leaveForm, endDate: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
            </div>
            {leaveForm.startDate && leaveForm.endDate && (
              <p className="text-sm text-primary font-medium">
                Duration: {calcDays(leaveForm.startDate, leaveForm.endDate)} day(s)
              </p>
            )}
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Reason</Label>
              <Textarea value={leaveForm.reason} onChange={(e) => setLeaveForm({ ...leaveForm, reason: e.target.value })} placeholder="Reason for leave..." rows={3} className="border-border bg-background text-foreground" />
            </div>
            <DialogFooter>
              <Button onClick={handleAddLeave} disabled={!leaveForm.startDate || !leaveForm.endDate || !leaveForm.reason} className="bg-primary text-primary-foreground hover:bg-primary/90">
                Submit Request
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Reimbursement Dialog */}
      <Dialog open={showReimbDialog} onOpenChange={setShowReimbDialog}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">New Reimbursement Claim</DialogTitle>
            <DialogDescription className="text-muted-foreground">Submit an expense claim for approval</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Category</Label>
              <Select value={reimbForm.category} onValueChange={(v) => setReimbForm({ ...reimbForm, category: v as ReimbursementCategory })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {reimbursementCategories.map((rc) => (
                    <SelectItem key={rc.value} value={rc.value}>{rc.label}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">{"Amount (Rs.)"}</Label>
                <Input type="number" value={reimbForm.amount} onChange={(e) => setReimbForm({ ...reimbForm, amount: e.target.value })} placeholder="0" className="border-border bg-background text-foreground" />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Expense Date</Label>
                <Input type="date" value={reimbForm.date} onChange={(e) => setReimbForm({ ...reimbForm, date: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Description</Label>
              <Textarea value={reimbForm.description} onChange={(e) => setReimbForm({ ...reimbForm, description: e.target.value })} placeholder="Describe the expense..." rows={3} className="border-border bg-background text-foreground" />
            </div>
            <DialogFooter>
              <Button onClick={handleAddReimb} disabled={!reimbForm.amount || !reimbForm.date || !reimbForm.description} className="bg-primary text-primary-foreground hover:bg-primary/90">
                Submit Claim
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Document Upload Dialog */}
      <Dialog open={showDocUpload} onOpenChange={setShowDocUpload}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Upload Document</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              Add a document for {getUserById(docUserId)?.name || "employee"}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Document Type</Label>
              <Select value={docForm.type} onValueChange={(v) => setDocForm({ ...docForm, type: v as DocumentType })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>
                  {allDocumentTypes.map((dt) => (
                    <SelectItem key={dt} value={dt}>{documentTypeLabels[dt]}</SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">File Name</Label>
              <Input
                value={docForm.fileName}
                onChange={(e) => setDocForm({ ...docForm, fileName: e.target.value })}
                placeholder="e.g. aadhaar_front.pdf"
                className="border-border bg-background text-foreground"
              />
              <p className="text-[10px] text-muted-foreground">Enter the file name to simulate upload</p>
            </div>
            <DialogFooter>
              <Button onClick={handleAddDocument} disabled={!docForm.fileName} className="bg-primary text-primary-foreground hover:bg-primary/90">
                Upload Document
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Bank Details Dialog */}
      <Dialog open={showBankDialog} onOpenChange={setShowBankDialog}>
        <DialogContent className="max-w-md bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Bank Details</DialogTitle>
            <DialogDescription className="text-muted-foreground">
              {getUserById(bankForm.userId)?.name || "Employee"} - bank account information
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Account Holder Name</Label>
              <Input value={bankForm.accountHolderName} onChange={(e) => setBankForm({ ...bankForm, accountHolderName: e.target.value })} className="border-border bg-background text-foreground" />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Bank Name</Label>
                <Input value={bankForm.bankName} onChange={(e) => setBankForm({ ...bankForm, bankName: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Branch</Label>
                <Input value={bankForm.branch} onChange={(e) => setBankForm({ ...bankForm, branch: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">Account Number</Label>
                <Input value={bankForm.accountNumber} onChange={(e) => setBankForm({ ...bankForm, accountNumber: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
              <div className="flex flex-col gap-2">
                <Label className="text-foreground">IFSC Code</Label>
                <Input value={bankForm.ifscCode} onChange={(e) => setBankForm({ ...bankForm, ifscCode: e.target.value })} className="border-border bg-background text-foreground" />
              </div>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Passbook / Cheque File</Label>
              <Input value={bankForm.documentFileName || ""} onChange={(e) => setBankForm({ ...bankForm, documentFileName: e.target.value })} placeholder="e.g. passbook.pdf" className="border-border bg-background text-foreground" />
            </div>
            <DialogFooter>
              <Button onClick={handleSaveBankDetails} disabled={!bankForm.accountHolderName || !bankForm.bankName || !bankForm.accountNumber || !bankForm.ifscCode} className="bg-primary text-primary-foreground hover:bg-primary/90">
                Save Details
              </Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Approval Confirmation Dialog */}
      <AlertDialog open={showApprovalDialog} onOpenChange={setShowApprovalDialog}>
        <AlertDialogContent className="bg-card text-card-foreground">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-foreground">
              {approvalItem?.action === "approved" ? "Approve" : "Reject"} {approvalItem?.type === "leave" ? "Leave Request" : "Reimbursement"}
            </AlertDialogTitle>
            <AlertDialogDescription className="text-muted-foreground">
              {approvalItem?.action === "approved"
                ? "Are you sure you want to approve this request?"
                : "Are you sure you want to reject this request?"}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <div className="flex flex-col gap-2 py-2">
            <Label className="text-foreground">Remark (optional)</Label>
            <Textarea
              value={approvalRemark}
              onChange={(e) => setApprovalRemark(e.target.value)}
              placeholder="Add a remark..."
              rows={2}
              className="border-border bg-background text-foreground"
            />
          </div>
          <AlertDialogFooter>
            <AlertDialogCancel className="border-border text-foreground">Cancel</AlertDialogCancel>
            <AlertDialogAction
              onClick={handleApproval}
              className={approvalItem?.action === "approved" ? "bg-[hsl(160,45%,40%)] text-white hover:bg-[hsl(160,45%,35%)]" : "bg-destructive text-destructive-foreground hover:bg-destructive/90"}
            >
              {approvalItem?.action === "approved" ? "Approve" : "Reject"}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  )
}
