"use client"

import { useCRM } from "@/lib/crm-context"
import { leadStatuses, leadSubStatuses, leadSources, roleLabels, formatDate } from "@/lib/data"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Download, TrendingUp, Target, Users, BarChart3 } from "lucide-react"
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
  Legend,
  AreaChart,
  Area,
} from "recharts"
import { useState } from "react"

const CHART_COLORS = [
  "hsl(37, 37%, 52%)",
  "hsl(160, 45%, 40%)",
  "hsl(210, 50%, 50%)",
  "hsl(37, 50%, 70%)",
  "hsl(0, 60%, 55%)",
  "hsl(280, 40%, 55%)",
  "hsl(37, 37%, 38%)",
  "hsl(190, 45%, 45%)",
  "hsl(30, 50%, 60%)",
  "hsl(140, 30%, 50%)",
  "hsl(350, 50%, 55%)",
]

export function Reports() {
  const { projects, users, hasPermission, currentUser, getScopedLeads, getScopedTasks, getTeamMemberIds } = useCRM()
  const [activeTab, setActiveTab] = useState("overview")

  const leads = getScopedLeads()
  const tasks = getScopedTasks()
  const teamMemberIds = getTeamMemberIds()

  const scopeLabel =
    currentUser?.role === "admin"
      ? "Company-wide"
      : currentUser?.role === "manager"
        ? "Your Team"
        : "Your"

  const totalLeads = leads.length
  const wonLeads = leads.filter((l) => l.status === "won").length
  const lostLeads = leads.filter((l) => l.status === "lost").length
  const conversionRate = totalLeads > 0 ? ((wonLeads / totalLeads) * 100).toFixed(1) : "0"

  // Source performance
  const sourcePerf = leadSources.map((source) => {
    const srcLeads = leads.filter((l) => l.source === source)
    const srcWon = srcLeads.filter((l) => l.status === "won").length
    return { source, total: srcLeads.length, won: srcWon, conversion: srcLeads.length > 0 ? ((srcWon / srcLeads.length) * 100).toFixed(0) : "0" }
  }).filter((s) => s.total > 0).sort((a, b) => b.total - a.total)

  // Team performance - scoped
  const scopedTeam = users.filter((u) => teamMemberIds.includes(u.id) && ["sales_executive", "presales_executive", "manager"].includes(u.role))
  const teamPerf = scopedTeam.map((u) => {
    const userLeads = leads.filter((l) => l.assignedTo === u.id)
    const userWon = userLeads.filter((l) => l.status === "won").length
    const userActive = userLeads.filter((l) => !["won", "lost", "unqualified"].includes(l.status)).length
    const userTasks = tasks.filter((t) => t.assignedTo === u.id)
    const completedTasks = userTasks.filter((t) => t.status === "completed").length
    return {
      name: u.name,
      role: roleLabels[u.role],
      totalLeads: userLeads.length,
      won: userWon,
      active: userActive,
      lost: userLeads.filter((l) => l.status === "lost").length,
      conversion: userLeads.length > 0 ? ((userWon / userLeads.length) * 100).toFixed(0) : "0",
      totalTasks: userTasks.length,
      completedTasks,
    }
  })

  // Pipeline data
  const pipelineData = leadStatuses.map((s) => ({
    name: s.label,
    count: leads.filter((l) => l.status === s.value).length,
  })).filter((d) => d.count > 0)

  // Sub-status distribution (replaces priority)
  const subStatusData = leadSubStatuses.map((ss) => ({
    name: ss.label,
    value: leads.filter((l) => l.subStatus === ss.value).length,
  })).filter((d) => d.value > 0)

  // Project performance
  const projectPerf = projects.map((p) => {
    const pLeads = leads.filter((l) => l.projectInterest === p.id)
    const pWon = pLeads.filter((l) => l.status === "won").length
    return { name: p.name.replace("Hestia ", ""), leads: pLeads.length, won: pWon, available: p.availableUnits, sold: p.totalUnits - p.availableUnits }
  })

  // Monthly trend
  const base = Math.max(leads.length, 3)
  const monthlyTrend = [
    { month: "Sep", newLeads: Math.round(base * 0.5), converted: Math.round(base * 0.08), lost: Math.round(base * 0.05) },
    { month: "Oct", newLeads: Math.round(base * 0.65), converted: Math.round(base * 0.12), lost: Math.round(base * 0.07) },
    { month: "Nov", newLeads: Math.round(base * 0.6), converted: Math.round(base * 0.1), lost: Math.round(base * 0.08) },
    { month: "Dec", newLeads: Math.round(base * 0.8), converted: Math.round(base * 0.15), lost: Math.round(base * 0.05) },
    { month: "Jan", newLeads: Math.round(base * 0.75), converted: Math.round(base * 0.18), lost: Math.round(base * 0.07) },
    { month: "Feb", newLeads: base, converted: Math.round(base * 0.22), lost: Math.round(base * 0.03) },
  ]

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Reports & Analytics</h1>
          <p className="text-sm text-muted-foreground">{scopeLabel} performance analysis across leads, team, and projects</p>
        </div>
        {hasPermission("reports", "export") && (
          <Button variant="outline" size="sm" className="border-border text-foreground">
            <Download className="mr-2 h-4 w-4" /> Export Report
          </Button>
        )}
      </div>

      {/* Summary Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <Target className="h-8 w-8 text-primary" />
            <div>
              <p className="text-2xl font-bold text-foreground">{totalLeads}</p>
              <p className="text-xs text-muted-foreground">Total Leads</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <TrendingUp className="h-8 w-8 text-[hsl(160,45%,40%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{conversionRate}%</p>
              <p className="text-xs text-muted-foreground">Conversion Rate</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <Users className="h-8 w-8 text-[hsl(210,50%,50%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{scopedTeam.length}</p>
              <p className="text-xs text-muted-foreground">Team Members</p>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-5">
            <BarChart3 className="h-8 w-8 text-[hsl(37,50%,70%)]" />
            <div>
              <p className="text-2xl font-bold text-foreground">{wonLeads}</p>
              <p className="text-xs text-muted-foreground">Deals Closed</p>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="bg-muted">
          <TabsTrigger value="overview" className="text-foreground data-[state=active]:bg-background">Overview</TabsTrigger>
          {currentUser?.role !== "sales_executive" && currentUser?.role !== "presales_executive" && (
            <TabsTrigger value="team" className="text-foreground data-[state=active]:bg-background">Team Performance</TabsTrigger>
          )}
          <TabsTrigger value="sources" className="text-foreground data-[state=active]:bg-background">Lead Sources</TabsTrigger>
          <TabsTrigger value="projects" className="text-foreground data-[state=active]:bg-background">Projects</TabsTrigger>
        </TabsList>

        <TabsContent value="overview" className="flex flex-col gap-6">
          <div className="grid gap-6 lg:grid-cols-2">
            <Card className="border-border/60">
              <CardHeader className="pb-2">
                <CardTitle className="text-base text-foreground">Monthly Trend</CardTitle>
                <CardDescription className="text-muted-foreground">Leads, conversions, and losses over time</CardDescription>
              </CardHeader>
              <CardContent>
                <ResponsiveContainer width="100%" height={280}>
                  <AreaChart data={monthlyTrend}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                    <XAxis dataKey="month" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                    <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                    <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                    <Area type="monotone" dataKey="newLeads" stroke="hsl(37,37%,52%)" fill="hsl(37,37%,52%)" fillOpacity={0.15} strokeWidth={2} name="New Leads" />
                    <Area type="monotone" dataKey="converted" stroke="hsl(160,45%,40%)" fill="hsl(160,45%,40%)" fillOpacity={0.15} strokeWidth={2} name="Converted" />
                    <Area type="monotone" dataKey="lost" stroke="hsl(0,60%,55%)" fill="hsl(0,60%,55%)" fillOpacity={0.15} strokeWidth={2} name="Lost" />
                  </AreaChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>

            <Card className="border-border/60">
              <CardHeader className="pb-2">
                <CardTitle className="text-base text-foreground">Sub-Status Distribution</CardTitle>
                <CardDescription className="text-muted-foreground">Breakdown of lead sub-statuses</CardDescription>
              </CardHeader>
              <CardContent className="flex items-center justify-center">
                <ResponsiveContainer width="100%" height={280}>
                  <PieChart>
                    <Pie data={subStatusData} cx="50%" cy="50%" innerRadius={55} outerRadius={95} paddingAngle={3} dataKey="value" label={({ name, value }) => `${name}: ${value}`}>
                      {subStatusData.map((_, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Pie>
                    <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  </PieChart>
                </ResponsiveContainer>
              </CardContent>
            </Card>
          </div>

          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Sales Pipeline</CardTitle>
              <CardDescription className="text-muted-foreground">Lead count at each pipeline stage</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={pipelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(30,5%,45%)" }} angle={-15} textAnchor="end" height={50} />
                  <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  <Bar dataKey="count" radius={[4, 4, 0, 0]}>
                    {pipelineData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Bar>
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="team" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Team Comparison</CardTitle>
              <CardDescription className="text-muted-foreground">Leads, conversions, and task completion</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={teamPerf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="totalLeads" fill="hsl(37,37%,52%)" radius={[4, 4, 0, 0]} name="Total Leads" />
                  <Bar dataKey="won" fill="hsl(160,45%,40%)" radius={[4, 4, 0, 0]} name="Won" />
                  <Bar dataKey="lost" fill="hsl(0,60%,55%)" radius={[4, 4, 0, 0]} name="Lost" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground">Name</TableHead>
                    <TableHead className="text-foreground">Role</TableHead>
                    <TableHead className="text-foreground">Total Leads</TableHead>
                    <TableHead className="text-foreground">Active</TableHead>
                    <TableHead className="text-foreground">Won</TableHead>
                    <TableHead className="text-foreground">Lost</TableHead>
                    <TableHead className="text-foreground">Conversion</TableHead>
                    <TableHead className="text-foreground">Tasks Done</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {teamPerf.map((member) => (
                    <TableRow key={member.name}>
                      <TableCell className="font-medium text-foreground">{member.name}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{member.role}</TableCell>
                      <TableCell className="text-foreground">{member.totalLeads}</TableCell>
                      <TableCell className="text-foreground">{member.active}</TableCell>
                      <TableCell className="font-medium text-green-700">{member.won}</TableCell>
                      <TableCell className="text-red-700">{member.lost}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-primary/10 text-primary">{member.conversion}%</Badge>
                      </TableCell>
                      <TableCell className="text-foreground">{member.completedTasks}/{member.totalTasks}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="sources" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Lead Source Performance</CardTitle>
              <CardDescription className="text-muted-foreground">Total leads and conversions by source</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={sourcePerf} layout="vertical">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                  <XAxis type="number" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <YAxis dataKey="source" type="category" tick={{ fontSize: 11, fill: "hsl(30,5%,45%)" }} width={90} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="total" fill="hsl(37,37%,52%)" radius={[0, 4, 4, 0]} name="Total" />
                  <Bar dataKey="won" fill="hsl(160,45%,40%)" radius={[0, 4, 4, 0]} name="Won" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground">Source</TableHead>
                    <TableHead className="text-foreground">Total Leads</TableHead>
                    <TableHead className="text-foreground">Won</TableHead>
                    <TableHead className="text-foreground">Conversion Rate</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sourcePerf.map((s) => (
                    <TableRow key={s.source}>
                      <TableCell className="font-medium text-foreground">{s.source}</TableCell>
                      <TableCell className="text-foreground">{s.total}</TableCell>
                      <TableCell className="font-medium text-green-700">{s.won}</TableCell>
                      <TableCell>
                        <Badge variant="secondary" className="bg-primary/10 text-primary">{s.conversion}%</Badge>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="projects" className="flex flex-col gap-6">
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base text-foreground">Project Performance</CardTitle>
              <CardDescription className="text-muted-foreground">Leads and sales per project</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={projectPerf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(30,5%,45%)" }} />
                  <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  <Legend />
                  <Bar dataKey="leads" fill="hsl(37,37%,52%)" radius={[4, 4, 0, 0]} name="Interested Leads" />
                  <Bar dataKey="sold" fill="hsl(160,45%,40%)" radius={[4, 4, 0, 0]} name="Units Sold" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>

          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground">Project</TableHead>
                    <TableHead className="text-foreground">Leads</TableHead>
                    <TableHead className="text-foreground">Won</TableHead>
                    <TableHead className="text-foreground">Units Sold</TableHead>
                    <TableHead className="text-foreground">Available</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {projectPerf.map((p) => (
                    <TableRow key={p.name}>
                      <TableCell className="font-medium text-foreground">{p.name}</TableCell>
                      <TableCell className="text-foreground">{p.leads}</TableCell>
                      <TableCell className="font-medium text-green-700">{p.won}</TableCell>
                      <TableCell className="text-foreground">{p.sold}</TableCell>
                      <TableCell className="text-foreground">{p.available}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
