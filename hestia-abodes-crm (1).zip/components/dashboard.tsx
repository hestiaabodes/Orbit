"use client"

import { useCRM } from "@/lib/crm-context"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { leadStatuses, leadSubStatuses, formatDate, roleLabels } from "@/lib/data"
import {
  Target, TrendingUp, Phone, Calendar, ClipboardList, Building2, MessageSquare, Mail,
} from "lucide-react"
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer,
  PieChart, Pie, Cell, AreaChart, Area,
} from "recharts"

export function Dashboard() {
  const { projects, getScopedLeads, getScopedTasks, users, currentUser, getUserById } = useCRM()

  const leads = getScopedLeads()
  const tasks = getScopedTasks()

  const totalLeads = leads.length
  const newLeads = leads.filter((l) => l.status === "new").length
  const wonLeads = leads.filter((l) => l.status === "won").length
  const hotLeads = leads.filter((l) => l.subStatus === "hot").length
  const activeTasks = tasks.filter((t) => t.status !== "completed").length
  const overdueFollowUps = leads.filter((l) => {
    if (!l.nextFollowUp) return false
    return new Date(l.nextFollowUp) <= new Date()
  }).length

  const sourceCount: Record<string, number> = {}
  leads.forEach((l) => { sourceCount[l.source] = (sourceCount[l.source] || 0) + 1 })
  const sourceData = Object.entries(sourceCount).map(([name, value]) => ({ name, value })).sort((a, b) => b.value - a.value)

  const statusData = leadStatuses.map((s) => ({ name: s.label, value: leads.filter((l) => l.status === s.value).length })).filter((d) => d.value > 0)

  const subStatusData = leadSubStatuses.map((p) => ({ name: p.label, value: leads.filter((l) => l.subStatus === p.value).length })).filter((d) => d.value > 0)

  const CHART_COLORS = ["hsl(37,37%,52%)", "hsl(160,45%,40%)", "hsl(210,50%,50%)", "hsl(37,50%,70%)", "hsl(0,60%,55%)", "hsl(280,40%,55%)", "hsl(37,37%,38%)", "hsl(170,50%,45%)", "hsl(45,80%,55%)", "hsl(330,45%,50%)", "hsl(200,60%,45%)"]

  const baseCount = Math.max(leads.length, 5)
  const monthlyData = [
    { month: "Sep", leads: Math.round(baseCount * 0.5), conversions: Math.round(baseCount * 0.08) },
    { month: "Oct", leads: Math.round(baseCount * 0.65), conversions: Math.round(baseCount * 0.12) },
    { month: "Nov", leads: Math.round(baseCount * 0.6), conversions: Math.round(baseCount * 0.1) },
    { month: "Dec", leads: Math.round(baseCount * 0.8), conversions: Math.round(baseCount * 0.15) },
    { month: "Jan", leads: Math.round(baseCount * 0.75), conversions: Math.round(baseCount * 0.18) },
    { month: "Feb", leads: baseCount, conversions: Math.round(baseCount * 0.22) },
  ]

  const recentLeads = [...leads].sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()).slice(0, 5)

  const upcomingFollowUps = leads.filter((l) => l.nextFollowUp).sort((a, b) => new Date(a.nextFollowUp!).getTime() - new Date(b.nextFollowUp!).getTime()).slice(0, 5)

  // Recent activities: pull the latest call/sms/email activities from scoped leads
  const recentActivities = leads
    .flatMap((l) => l.activities.map((a) => ({ ...a, leadName: l.name, leadId: l.id })))
    .filter((a) => ["call", "email", "sms", "whatsapp"].includes(a.type))
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())
    .slice(0, 5)

  const scopeLabel = currentUser?.role === "admin" ? "Company-wide" : currentUser?.role === "manager" ? "Your Team" : "Your"

  const teamPerf = currentUser?.role !== "sales_executive" && currentUser?.role !== "presales_executive"
    ? users
        .filter((u) => {
          if (currentUser?.role === "admin") return ["sales_executive", "presales_executive"].includes(u.role)
          if (currentUser?.role === "manager") return u.managerId === currentUser.id && ["sales_executive", "presales_executive"].includes(u.role)
          return false
        })
        .map((u) => ({
          name: u.name.split(" ")[0],
          leads: leads.filter((l) => l.assignedTo === u.id).length,
          won: leads.filter((l) => l.assignedTo === u.id && l.status === "won").length,
        }))
    : []

  const conversionRate = totalLeads > 0 ? ((wonLeads / totalLeads) * 100).toFixed(1) : "0"

  const activityIcon = (type: string) => {
    switch (type) {
      case "call": return <Phone className="h-3.5 w-3.5 text-green-600" />
      case "email": return <Mail className="h-3.5 w-3.5 text-blue-600" />
      case "sms": return <MessageSquare className="h-3.5 w-3.5 text-purple-600" />
      case "whatsapp": return <MessageSquare className="h-3.5 w-3.5 text-emerald-600" />
      default: return <Phone className="h-3.5 w-3.5 text-muted-foreground" />
    }
  }

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-1">
        <h1 className="text-2xl font-bold text-foreground">
          Welcome back, {currentUser?.name.split(" ")[0]}
        </h1>
        <p className="text-sm text-muted-foreground">
          {scopeLabel} overview &mdash; {"Here's what's happening with your leads and projects today."}
        </p>
      </div>

      {/* KPI Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-primary/10">
              <Target className="h-6 w-6 text-primary" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-foreground">{totalLeads}</span>
              <span className="text-xs text-muted-foreground">Total Leads</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(160,45%,40%)]/10">
              <TrendingUp className="h-6 w-6 text-[hsl(160,45%,40%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-foreground">{conversionRate}%</span>
              <span className="text-xs text-muted-foreground">Conversion Rate</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(0,60%,55%)]/10">
              <Phone className="h-6 w-6 text-[hsl(0,60%,55%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-foreground">{overdueFollowUps}</span>
              <span className="text-xs text-muted-foreground">Follow-ups Due</span>
            </div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-4 p-5">
            <div className="flex h-12 w-12 shrink-0 items-center justify-center rounded-xl bg-[hsl(210,50%,50%)]/10">
              <ClipboardList className="h-6 w-6 text-[hsl(210,50%,50%)]" />
            </div>
            <div className="flex flex-col">
              <span className="text-2xl font-bold text-foreground">{activeTasks}</span>
              <span className="text-xs text-muted-foreground">Active Tasks</span>
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Second row KPI */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center justify-between p-5">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-foreground">{newLeads}</span>
              <span className="text-xs text-muted-foreground">New Leads</span>
            </div>
            <Badge variant="secondary" className="bg-blue-50 text-blue-700">New</Badge>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center justify-between p-5">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-foreground">{hotLeads}</span>
              <span className="text-xs text-muted-foreground">Hot Leads</span>
            </div>
            <Badge variant="secondary" className="bg-red-50 text-red-700">Hot</Badge>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center justify-between p-5">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-foreground">{wonLeads}</span>
              <span className="text-xs text-muted-foreground">Won Deals</span>
            </div>
            <Badge variant="secondary" className="bg-green-50 text-green-700">Won</Badge>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center justify-between p-5">
            <div className="flex flex-col">
              <span className="text-lg font-bold text-foreground">{projects.length}</span>
              <span className="text-xs text-muted-foreground">Active Projects</span>
            </div>
            <Building2 className="h-5 w-5 text-primary" />
          </CardContent>
        </Card>
      </div>

      {/* Recent Leads, Recent Activity, Upcoming Follow-ups - ABOVE charts */}
      <div className="grid gap-6 lg:grid-cols-3">
        {/* Recent Leads */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-foreground">Recent Leads</CardTitle>
            <CardDescription className="text-muted-foreground">Latest leads in your scope</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {recentLeads.map((lead) => {
                const statusInfo = leadStatuses.find((s) => s.value === lead.status)
                const assignee = getUserById(lead.assignedTo)
                return (
                  <div key={lead.id} className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-sm font-medium text-foreground">{lead.name}</span>
                      <span className="text-xs text-muted-foreground">{lead.source} &middot; {assignee?.name || "Unassigned"}</span>
                    </div>
                    <Badge variant="secondary" className={statusInfo?.color}>{statusInfo?.label}</Badge>
                  </div>
                )
              })}
              {recentLeads.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">No leads to display</p>}
            </div>
          </CardContent>
        </Card>

        {/* Recent Activity */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-foreground">Recent Activity</CardTitle>
            <CardDescription className="text-muted-foreground">Latest calls and messages sent</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {recentActivities.map((activity) => {
                const creator = getUserById(activity.createdBy)
                return (
                  <div key={activity.id} className="flex items-start gap-3 rounded-lg bg-muted/50 px-4 py-3">
                    <div className="mt-0.5 flex h-7 w-7 shrink-0 items-center justify-center rounded-full bg-background">
                      {activityIcon(activity.type)}
                    </div>
                    <div className="flex flex-col gap-0.5 overflow-hidden">
                      <span className="truncate text-sm font-medium text-foreground">{activity.description}</span>
                      <span className="text-xs text-muted-foreground">
                        {activity.leadName} &middot; {creator?.name?.split(" ")[0] || "-"} &middot; {formatDate(activity.createdAt)}
                      </span>
                    </div>
                  </div>
                )
              })}
              {recentActivities.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">No recent activity</p>}
            </div>
          </CardContent>
        </Card>

        {/* Upcoming Follow-ups - horizontal layout */}
        <Card className="border-border/60">
          <CardHeader className="pb-3">
            <CardTitle className="text-base font-semibold text-foreground">Upcoming Follow-ups</CardTitle>
            <CardDescription className="text-muted-foreground">Scheduled follow-ups</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex flex-col gap-3">
              {upcomingFollowUps.map((lead) => {
                const assignee = getUserById(lead.assignedTo)
                const isOverdue = new Date(lead.nextFollowUp!) <= new Date()
                return (
                  <div key={lead.id} className="flex items-center justify-between rounded-lg bg-muted/50 px-4 py-3">
                    <div className="flex flex-col gap-0.5">
                      <span className="text-sm font-medium text-foreground">{lead.name}</span>
                      <span className="text-xs text-muted-foreground">{assignee?.name || "Unassigned"}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Calendar className="h-3.5 w-3.5 text-muted-foreground" />
                      <span className={`text-xs font-medium ${isOverdue ? "text-destructive" : "text-foreground"}`}>
                        {formatDate(lead.nextFollowUp)}
                      </span>
                    </div>
                  </div>
                )
              })}
              {upcomingFollowUps.length === 0 && <p className="py-4 text-center text-sm text-muted-foreground">No upcoming follow-ups</p>}
            </div>
          </CardContent>
        </Card>
      </div>

      {/* Charts BELOW the three tiles */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-border/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-foreground">Lead Generation Trend</CardTitle>
            <CardDescription className="text-muted-foreground">Leads vs Conversions (Last 6 Months)</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <AreaChart data={monthlyData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                <XAxis dataKey="month" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                <Area type="monotone" dataKey="leads" stackId="1" stroke="hsl(37,37%,52%)" fill="hsl(37,37%,52%)" fillOpacity={0.15} strokeWidth={2} />
                <Area type="monotone" dataKey="conversions" stackId="2" stroke="hsl(160,45%,40%)" fill="hsl(160,45%,40%)" fillOpacity={0.15} strokeWidth={2} />
              </AreaChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        <Card className="border-border/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-foreground">Lead Sources</CardTitle>
            <CardDescription className="text-muted-foreground">Distribution across channels</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={sourceData} layout="vertical">
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                <XAxis type="number" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                <YAxis dataKey="name" type="category" tick={{ fontSize: 11, fill: "hsl(30,5%,45%)" }} width={80} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                <Bar dataKey="value" fill="hsl(37,37%,52%)" radius={[0, 4, 4, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>

      {/* Pipeline and Team Performance */}
      <div className="grid gap-6 lg:grid-cols-2">
        <Card className="border-border/60">
          <CardHeader className="pb-2">
            <CardTitle className="text-base font-semibold text-foreground">Sales Pipeline</CardTitle>
            <CardDescription className="text-muted-foreground">Lead distribution by status</CardDescription>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={260}>
              <BarChart data={statusData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                <XAxis dataKey="name" tick={{ fontSize: 10, fill: "hsl(30,5%,45%)" }} angle={-20} textAnchor="end" height={50} />
                <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                <Bar dataKey="value" radius={[4, 4, 0, 0]}>
                  {statusData.map((_, index) => (
                    <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>

        {teamPerf.length > 0 ? (
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold text-foreground">Team Performance</CardTitle>
              <CardDescription className="text-muted-foreground">Leads assigned vs converted</CardDescription>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={260}>
                <BarChart data={teamPerf}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(30,15%,88%)" />
                  <XAxis dataKey="name" tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <YAxis tick={{ fontSize: 12, fill: "hsl(30,5%,45%)" }} />
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                  <Bar dataKey="leads" fill="hsl(37,37%,52%)" radius={[4, 4, 0, 0]} name="Total Leads" />
                  <Bar dataKey="won" fill="hsl(160,45%,40%)" radius={[4, 4, 0, 0]} name="Won" />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        ) : (
          <Card className="border-border/60">
            <CardHeader className="pb-2">
              <CardTitle className="text-base font-semibold text-foreground">Sub-Status Distribution</CardTitle>
              <CardDescription className="text-muted-foreground">Lead sub-status breakdown</CardDescription>
            </CardHeader>
            <CardContent className="flex items-center justify-center">
              <ResponsiveContainer width="100%" height={260}>
                <PieChart>
                  <Pie data={subStatusData} cx="50%" cy="50%" innerRadius={50} outerRadius={90} paddingAngle={3} dataKey="value" label={({ name, value }) => value > 0 ? `${name}: ${value}` : ""}>
                    {subStatusData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip contentStyle={{ backgroundColor: "hsl(0,0%,100%)", border: "1px solid hsl(30,15%,88%)", borderRadius: "8px", fontSize: 12 }} />
                </PieChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        )}
      </div>
    </div>
  )
}
