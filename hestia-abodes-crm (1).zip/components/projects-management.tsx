"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { type Project } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Progress } from "@/components/ui/progress"
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import {
  Search,
  Plus,
  MoreVertical,
  Eye,
  Edit,
  Trash2,
  MapPin,
  Building2,
  Home,
  Landmark,
  TreePine,
  Users,
  X,
} from "lucide-react"
import { ScrollArea } from "@/components/ui/scroll-area"

const projectTypes = [
  { value: "residential", label: "Residential", icon: Home },
  { value: "commercial", label: "Commercial", icon: Building2 },
  { value: "villa", label: "Villa", icon: Landmark },
  { value: "plot", label: "Plot", icon: TreePine },
]

const projectStatuses = [
  { value: "upcoming", label: "Upcoming", color: "bg-blue-100 text-blue-700" },
  { value: "ongoing", label: "Ongoing", color: "bg-green-100 text-green-700" },
  { value: "completed", label: "Completed", color: "bg-muted text-muted-foreground" },
]

export function ProjectsManagement() {
  const { projects, addProject, updateProject, deleteProject, leads, hasPermission } = useCRM()

  const [search, setSearch] = useState("")
  const [typeFilter, setTypeFilter] = useState<string>("all")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [showAddDialog, setShowAddDialog] = useState(false)
  const [showEditDialog, setShowEditDialog] = useState(false)
  const [showDetailDialog, setShowDetailDialog] = useState(false)
  const [selectedProject, setSelectedProject] = useState<Project | null>(null)

  const [formData, setFormData] = useState({
    name: "",
    location: "",
    type: "residential" as Project["type"],
    status: "upcoming" as Project["status"],
    totalUnits: 0,
    availableUnits: 0,
    priceRange: "",
    description: "",
    amenities: [] as string[],
  })
  const [amenityInput, setAmenityInput] = useState("")

  const resetForm = () => {
    setFormData({
      name: "",
      location: "",
      type: "residential",
      status: "upcoming",
      totalUnits: 0,
      availableUnits: 0,
      priceRange: "",
      description: "",
      amenities: [],
    })
    setAmenityInput("")
  }

  const filteredProjects = projects.filter((p) => {
    if (search && !p.name.toLowerCase().includes(search.toLowerCase()) && !p.location.toLowerCase().includes(search.toLowerCase())) return false
    if (typeFilter !== "all" && p.type !== typeFilter) return false
    if (statusFilter !== "all" && p.status !== statusFilter) return false
    return true
  })

  const handleAddProject = () => {
    addProject(formData)
    setShowAddDialog(false)
    resetForm()
  }

  const handleEditProject = () => {
    if (!selectedProject) return
    updateProject(selectedProject.id, formData)
    setShowEditDialog(false)
    setSelectedProject(null)
    resetForm()
  }

  const openEdit = (project: Project) => {
    setSelectedProject(project)
    setFormData({
      name: project.name,
      location: project.location,
      type: project.type,
      status: project.status,
      totalUnits: project.totalUnits,
      availableUnits: project.availableUnits,
      priceRange: project.priceRange,
      description: project.description,
      amenities: project.amenities,
    })
    setShowEditDialog(true)
  }

  const addAmenity = () => {
    if (amenityInput.trim() && !formData.amenities.includes(amenityInput.trim())) {
      setFormData({ ...formData, amenities: [...formData.amenities, amenityInput.trim()] })
      setAmenityInput("")
    }
  }

  const removeAmenity = (amenity: string) => {
    setFormData({ ...formData, amenities: formData.amenities.filter((a) => a !== amenity) })
  }

  const ProjectForm = ({ onSubmit, submitLabel }: { onSubmit: () => void; submitLabel: string }) => (
    <div className="grid gap-4 py-4">
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Project Name *</Label>
          <Input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} placeholder="Project name" className="border-border bg-background text-foreground" />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Location *</Label>
          <Input value={formData.location} onChange={(e) => setFormData({ ...formData, location: e.target.value })} placeholder="City, Area" className="border-border bg-background text-foreground" />
        </div>
      </div>
      <div className="grid grid-cols-2 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Type</Label>
          <Select value={formData.type} onValueChange={(v) => setFormData({ ...formData, type: v as Project["type"] })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
            <SelectContent>
              {projectTypes.map((t) => (
                <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Status</Label>
          <Select value={formData.status} onValueChange={(v) => setFormData({ ...formData, status: v as Project["status"] })}>
            <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
            <SelectContent>
              {projectStatuses.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
        </div>
      </div>
      <div className="grid grid-cols-3 gap-4">
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Total Units</Label>
          <Input type="number" value={formData.totalUnits} onChange={(e) => setFormData({ ...formData, totalUnits: parseInt(e.target.value) || 0 })} className="border-border bg-background text-foreground" />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Available Units</Label>
          <Input type="number" value={formData.availableUnits} onChange={(e) => setFormData({ ...formData, availableUnits: parseInt(e.target.value) || 0 })} className="border-border bg-background text-foreground" />
        </div>
        <div className="flex flex-col gap-2">
          <Label className="text-foreground">Price Range</Label>
          <Input value={formData.priceRange} onChange={(e) => setFormData({ ...formData, priceRange: e.target.value })} placeholder="e.g. 50L - 1Cr" className="border-border bg-background text-foreground" />
        </div>
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-foreground">Description</Label>
        <Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} rows={3} className="border-border bg-background text-foreground" />
      </div>
      <div className="flex flex-col gap-2">
        <Label className="text-foreground">Amenities</Label>
        <div className="flex gap-2">
          <Input
            value={amenityInput}
            onChange={(e) => setAmenityInput(e.target.value)}
            placeholder="Add amenity"
            className="border-border bg-background text-foreground"
            onKeyDown={(e) => e.key === "Enter" && (e.preventDefault(), addAmenity())}
          />
          <Button type="button" variant="outline" onClick={addAmenity} className="border-border text-foreground">Add</Button>
        </div>
        <div className="flex flex-wrap gap-2 mt-1">
          {formData.amenities.map((a) => (
            <Badge key={a} variant="secondary" className="bg-primary/10 text-primary">
              {a}
              <button onClick={() => removeAmenity(a)} className="ml-1"><X className="h-3 w-3" /></button>
            </Badge>
          ))}
        </div>
      </div>
      <DialogFooter>
        <Button onClick={onSubmit} disabled={!formData.name || !formData.location} className="bg-primary text-primary-foreground hover:bg-primary/90">
          {submitLabel}
        </Button>
      </DialogFooter>
    </div>
  )

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Projects & Properties</h1>
          <p className="text-sm text-muted-foreground">Manage your property listings and projects</p>
        </div>
        {hasPermission("projects", "create") && (
          <Button
            size="sm"
            className="bg-primary text-primary-foreground hover:bg-primary/90"
            onClick={() => { resetForm(); setShowAddDialog(true) }}
          >
            <Plus className="mr-2 h-4 w-4" /> Add Project
          </Button>
        )}
      </div>

      {/* Filters */}
      <Card className="border-border/60">
        <CardContent className="p-4">
          <div className="flex flex-wrap items-center gap-3">
            <div className="relative flex-1 min-w-[200px]">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input placeholder="Search projects..." value={search} onChange={(e) => setSearch(e.target.value)} className="border-border bg-background pl-9 text-foreground" />
            </div>
            <Select value={typeFilter} onValueChange={setTypeFilter}>
              <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue placeholder="Type" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Types</SelectItem>
                {projectTypes.map((t) => (
                  <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue placeholder="Status" /></SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Status</SelectItem>
                {projectStatuses.map((s) => (
                  <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Projects Grid */}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {filteredProjects.map((project) => {
          const statusInfo = projectStatuses.find((s) => s.value === project.status)
          const typeInfo = projectTypes.find((t) => t.value === project.type)
          const Icon = typeInfo?.icon || Building2
          const soldUnits = project.totalUnits - project.availableUnits
          const soldPercent = project.totalUnits > 0 ? (soldUnits / project.totalUnits) * 100 : 0
          const interestedLeads = leads.filter((l) => l.projectInterest === project.id).length

          return (
            <Card key={project.id} className="group border-border/60 transition-shadow hover:shadow-lg">
              <CardHeader className="pb-3">
                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-primary/10">
                      <Icon className="h-5 w-5 text-primary" />
                    </div>
                    <div>
                      <CardTitle className="text-base text-foreground">{project.name}</CardTitle>
                      <p className="flex items-center gap-1 text-xs text-muted-foreground">
                        <MapPin className="h-3 w-3" />{project.location}
                      </p>
                    </div>
                  </div>
                  <DropdownMenu>
                    <DropdownMenuTrigger asChild>
                      <Button variant="ghost" size="icon" className="h-8 w-8 text-muted-foreground opacity-0 group-hover:opacity-100">
                        <MoreVertical className="h-4 w-4" />
                      </Button>
                    </DropdownMenuTrigger>
                    <DropdownMenuContent align="end">
                      <DropdownMenuItem onClick={() => { setSelectedProject(project); setShowDetailDialog(true) }}>
                        <Eye className="mr-2 h-4 w-4" /> View Details
                      </DropdownMenuItem>
                      {hasPermission("projects", "edit") && (
                        <DropdownMenuItem onClick={() => openEdit(project)}>
                          <Edit className="mr-2 h-4 w-4" /> Edit
                        </DropdownMenuItem>
                      )}
                      {hasPermission("projects", "delete") && (
                        <DropdownMenuItem onClick={() => deleteProject(project.id)} className="text-destructive">
                          <Trash2 className="mr-2 h-4 w-4" /> Delete
                        </DropdownMenuItem>
                      )}
                    </DropdownMenuContent>
                  </DropdownMenu>
                </div>
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <div className="flex items-center justify-between">
                  <Badge variant="secondary" className={statusInfo?.color}>{statusInfo?.label}</Badge>
                  <Badge variant="secondary" className="bg-primary/10 text-primary capitalize">{typeInfo?.label}</Badge>
                </div>

                <p className="line-clamp-2 text-xs text-muted-foreground">{project.description}</p>

                <div className="flex flex-col gap-2">
                  <div className="flex items-center justify-between text-xs">
                    <span className="text-muted-foreground">Units Sold</span>
                    <span className="font-medium text-foreground">{soldUnits} / {project.totalUnits}</span>
                  </div>
                  <Progress value={soldPercent} className="h-2" />
                </div>

                <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2 text-xs">
                  <span className="text-muted-foreground">Price Range</span>
                  <span className="font-semibold text-foreground">{project.priceRange}</span>
                </div>

                <div className="flex items-center justify-between text-xs">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Users className="h-3 w-3" /> {interestedLeads} interested leads
                  </span>
                  <span className="text-muted-foreground">{project.availableUnits} available</span>
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>

      {/* Add Project Dialog */}
      <Dialog open={showAddDialog} onOpenChange={setShowAddDialog}>
        <DialogContent className="max-w-2xl bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Add New Project</DialogTitle>
            <DialogDescription className="text-muted-foreground">Enter the project details</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh]">
            <ProjectForm onSubmit={handleAddProject} submitLabel="Add Project" />
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Edit Project Dialog */}
      <Dialog open={showEditDialog} onOpenChange={setShowEditDialog}>
        <DialogContent className="max-w-2xl bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Edit Project</DialogTitle>
            <DialogDescription className="text-muted-foreground">Update the project details</DialogDescription>
          </DialogHeader>
          <ScrollArea className="max-h-[70vh]">
            <ProjectForm onSubmit={handleEditProject} submitLabel="Update Project" />
          </ScrollArea>
        </DialogContent>
      </Dialog>

      {/* Detail Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-2xl bg-card text-card-foreground">
          {selectedProject && (() => {
            const statusInfo = projectStatuses.find((s) => s.value === selectedProject.status)
            const typeInfo = projectTypes.find((t) => t.value === selectedProject.type)
            const soldUnits = selectedProject.totalUnits - selectedProject.availableUnits
            const soldPercent = selectedProject.totalUnits > 0 ? (soldUnits / selectedProject.totalUnits) * 100 : 0
            const interestedLeads = leads.filter((l) => l.projectInterest === selectedProject.id)

            return (
              <>
                <DialogHeader>
                  <DialogTitle className="text-xl text-foreground">{selectedProject.name}</DialogTitle>
                  <DialogDescription className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4" />{selectedProject.location}
                  </DialogDescription>
                </DialogHeader>

                <div className="flex flex-col gap-4">
                  <div className="flex gap-2">
                    <Badge variant="secondary" className={statusInfo?.color}>{statusInfo?.label}</Badge>
                    <Badge variant="secondary" className="bg-primary/10 text-primary capitalize">{typeInfo?.label}</Badge>
                  </div>

                  <p className="text-sm text-muted-foreground">{selectedProject.description}</p>

                  <div className="grid grid-cols-3 gap-4">
                    <div className="rounded-lg bg-muted p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{selectedProject.totalUnits}</p>
                      <p className="text-xs text-muted-foreground">Total Units</p>
                    </div>
                    <div className="rounded-lg bg-muted p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{selectedProject.availableUnits}</p>
                      <p className="text-xs text-muted-foreground">Available</p>
                    </div>
                    <div className="rounded-lg bg-muted p-3 text-center">
                      <p className="text-lg font-bold text-foreground">{soldUnits}</p>
                      <p className="text-xs text-muted-foreground">Sold</p>
                    </div>
                  </div>

                  <div className="flex flex-col gap-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-muted-foreground">Sales Progress</span>
                      <span className="font-medium text-foreground">{soldPercent.toFixed(0)}%</span>
                    </div>
                    <Progress value={soldPercent} className="h-3" />
                  </div>

                  <div className="rounded-lg bg-muted p-3">
                    <p className="mb-2 text-sm font-semibold text-foreground">Amenities</p>
                    <div className="flex flex-wrap gap-2">
                      {selectedProject.amenities.map((a) => (
                        <Badge key={a} variant="secondary" className="bg-primary/10 text-primary">{a}</Badge>
                      ))}
                    </div>
                  </div>

                  {interestedLeads.length > 0 && (
                    <div className="rounded-lg bg-muted p-3">
                      <p className="mb-2 text-sm font-semibold text-foreground">Interested Leads ({interestedLeads.length})</p>
                      <div className="flex flex-col gap-1">
                        {interestedLeads.slice(0, 5).map((l) => (
                          <div key={l.id} className="flex items-center justify-between text-sm">
                            <span className="text-foreground">{l.name}</span>
                            <span className="text-xs text-muted-foreground">{l.budget}</span>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>
              </>
            )
          })()}
        </DialogContent>
      </Dialog>
    </div>
  )
}
