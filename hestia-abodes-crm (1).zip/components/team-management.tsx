"use client"

import { useCRM } from "@/lib/crm-context"
import { roleLabels } from "@/lib/data"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Progress } from "@/components/ui/progress"
import { Phone, Mail, TrendingUp, CheckCircle2, Clock, User } from "lucide-react"

export function TeamManagement() {
  const { users, leads, tasks, currentUser, getScopedTeamMembers } = useCRM()

  const teamMembers = getScopedTeamMembers()

  const presalesCount = teamMembers.filter((u) => u.role === "presales_executive").length
  const salesCount = teamMembers.filter((u) => u.role === "sales_executive").length
  const managerCount = teamMembers.filter((u) => u.role === "manager").length

  return (
    <div className="flex flex-col gap-6">
      <div>
        <h1 className="text-2xl font-bold text-foreground">Team Management</h1>
        <p className="text-sm text-muted-foreground">
          {currentUser?.role === "admin" ? "Company-wide" : "Your"} team performance and details
        </p>
      </div>

      {/* Team Overview Cards */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="p-5">
            <p className="text-2xl font-bold text-foreground">{teamMembers.length}</p>
            <p className="text-xs text-muted-foreground">Active Members</p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-5">
            <p className="text-2xl font-bold text-foreground">{salesCount}</p>
            <p className="text-xs text-muted-foreground">Sales Executives</p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-5">
            <p className="text-2xl font-bold text-foreground">{presalesCount}</p>
            <p className="text-xs text-muted-foreground">Presales Executives</p>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="p-5">
            <p className="text-2xl font-bold text-foreground">{managerCount}</p>
            <p className="text-xs text-muted-foreground">Team Leads</p>
          </CardContent>
        </Card>
      </div>

      {/* Team Members Grid */}
      <div className="grid gap-6 md:grid-cols-2 xl:grid-cols-3">
        {teamMembers.map((member) => {
          const memberLeads = leads.filter((l) => l.assignedTo === member.id)
          const memberTasks = tasks.filter((t) => t.assignedTo === member.id)
          const wonLeads = memberLeads.filter((l) => l.status === "won").length
          const activeLeads = memberLeads.filter((l) => !["won", "lost", "unqualified"].includes(l.status)).length
          const completedTasks = memberTasks.filter((t) => t.status === "completed").length
          const pendingTasks = memberTasks.filter((t) => t.status !== "completed").length
          const conversionRate = memberLeads.length > 0 ? ((wonLeads / memberLeads.length) * 100).toFixed(0) : "0"
          const manager = member.managerId ? users.find((u) => u.id === member.managerId) : null

          return (
            <Card key={member.id} className="border-border/60">
              <CardHeader className="pb-3">
                <div className="flex items-center gap-4">
                  <div className="flex h-12 w-12 items-center justify-center rounded-full bg-primary text-lg font-bold text-primary-foreground">
                    {member.name.split(" ").map((n) => n[0]).join("")}
                  </div>
                  <div className="flex flex-col">
                    <CardTitle className="text-base text-foreground">{member.name}</CardTitle>
                    <Badge variant="secondary" className="w-fit bg-primary/10 text-primary text-[10px]">
                      {roleLabels[member.role]}
                    </Badge>
                  </div>
                </div>
              </CardHeader>
              <CardContent className="flex flex-col gap-4">
                <div className="flex flex-col gap-1 text-xs text-muted-foreground">
                  <span className="flex items-center gap-2"><Mail className="h-3 w-3" />{member.email}</span>
                  <span className="flex items-center gap-2"><Phone className="h-3 w-3" />{member.phone}</span>
                  {manager && (
                    <span className="flex items-center gap-2"><User className="h-3 w-3" />Reports to: {manager.name}</span>
                  )}
                </div>

                <div className="grid grid-cols-3 gap-3">
                  <div className="rounded-lg bg-muted p-2 text-center">
                    <p className="text-sm font-bold text-foreground">{memberLeads.length}</p>
                    <p className="text-[10px] text-muted-foreground">Total Leads</p>
                  </div>
                  <div className="rounded-lg bg-muted p-2 text-center">
                    <p className="text-sm font-bold text-foreground">{activeLeads}</p>
                    <p className="text-[10px] text-muted-foreground">Active</p>
                  </div>
                  <div className="rounded-lg bg-muted p-2 text-center">
                    <p className="text-sm font-bold text-foreground">{wonLeads}</p>
                    <p className="text-[10px] text-muted-foreground">Won</p>
                  </div>
                </div>

                <div className="flex flex-col gap-1">
                  <div className="flex items-center justify-between text-xs">
                    <span className="flex items-center gap-1 text-muted-foreground">
                      <TrendingUp className="h-3 w-3" /> Conversion Rate
                    </span>
                    <span className="font-medium text-foreground">{conversionRate}%</span>
                  </div>
                  <Progress value={parseFloat(conversionRate)} className="h-1.5" />
                </div>

                <div className="flex items-center justify-between rounded-lg bg-muted px-3 py-2 text-xs">
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <CheckCircle2 className="h-3 w-3 text-green-600" /> {completedTasks} done
                  </span>
                  <span className="flex items-center gap-1 text-muted-foreground">
                    <Clock className="h-3 w-3 text-orange-600" /> {pendingTasks} pending
                  </span>
                </div>

                <div className="flex flex-wrap gap-1">
                  {member.weekOffs.map((day) => (
                    <Badge key={day} variant="outline" className="border-border text-muted-foreground text-[9px] capitalize">
                      {day.slice(0, 3)} off
                    </Badge>
                  ))}
                </div>
              </CardContent>
            </Card>
          )
        })}
      </div>
    </div>
  )
}
