"use client"

import { useState } from "react"
import { useCRM } from "@/lib/crm-context"
import { formatDateTime, roleLabels, type ServiceRequestModule, type ServiceRequestStatus } from "@/lib/data"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Search, Plus, MessageSquareText, Clock, CheckCircle2, XCircle, AlertCircle, Inbox } from "lucide-react"
import { Separator } from "@/components/ui/separator"

const modules: { value: ServiceRequestModule; label: string }[] = [
  { value: "leads", label: "Leads" },
  { value: "projects", label: "Projects" },
  { value: "tasks", label: "Tasks" },
  { value: "hrms", label: "HRMS" },
  { value: "general", label: "General" },
]

const statusConfig: Record<ServiceRequestStatus, { label: string; color: string; icon: typeof Clock }> = {
  open: { label: "Open", color: "bg-blue-100 text-blue-700", icon: Inbox },
  in_progress: { label: "In Progress", color: "bg-amber-100 text-amber-700", icon: Clock },
  resolved: { label: "Resolved", color: "bg-green-100 text-green-700", icon: CheckCircle2 },
  closed: { label: "Closed", color: "bg-gray-100 text-gray-600", icon: CheckCircle2 },
  rejected: { label: "Rejected", color: "bg-red-100 text-red-600", icon: XCircle },
}

export function HelpDesk() {
  const {
    currentUser, getUserById, hasPermission,
    addServiceRequest, updateServiceRequest,
    getScopedServiceRequests, getManageableServiceRequests,
  } = useCRM()

  const scopedSRs = getScopedServiceRequests()
  const manageableSRs = getManageableServiceRequests()
  const canManage = hasPermission("helpdesk", "manage")

  const [search, setSearch] = useState("")
  const [statusFilter, setStatusFilter] = useState<string>("all")
  const [showCreateDialog, setShowCreateDialog] = useState(false)
  const [showDetailDialog, setShowDetailDialog] = useState(false)
  const [selectedSR, setSelectedSR] = useState<typeof scopedSRs[0] | null>(null)
  const [actionRemark, setActionRemark] = useState("")

  const [formData, setFormData] = useState({
    module: "general" as ServiceRequestModule,
    subject: "",
    description: "",
  })

  const resetForm = () => setFormData({ module: "general", subject: "", description: "" })

  const handleCreate = () => {
    if (!currentUser) return
    addServiceRequest({ userId: currentUser.id, module: formData.module, subject: formData.subject, description: formData.description })
    setShowCreateDialog(false)
    resetForm()
  }

  const handleStatusChange = (srId: string, newStatus: ServiceRequestStatus) => {
    updateServiceRequest(srId, {
      status: newStatus,
      resolvedBy: currentUser?.id,
      remarks: actionRemark || undefined,
    })
    setActionRemark("")
    setShowDetailDialog(false)
  }

  const filteredSRs = scopedSRs.filter((sr) => {
    if (search) {
      const q = search.toLowerCase()
      if (!sr.srId.toLowerCase().includes(q) && !sr.subject.toLowerCase().includes(q)) return false
    }
    if (statusFilter !== "all" && sr.status !== statusFilter) return false
    return true
  }).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())

  // Stats
  const openCount = scopedSRs.filter((sr) => sr.status === "open").length
  const inProgressCount = scopedSRs.filter((sr) => sr.status === "in_progress").length
  const resolvedCount = scopedSRs.filter((sr) => sr.status === "resolved" || sr.status === "closed").length

  return (
    <div className="flex flex-col gap-6">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl font-bold text-foreground">Help Desk</h1>
          <p className="text-sm text-muted-foreground">Raise and track service requests across modules</p>
        </div>
        {hasPermission("helpdesk", "create") && (
          <Button size="sm" className="bg-primary text-primary-foreground hover:bg-primary/90" onClick={() => { resetForm(); setShowCreateDialog(true) }}>
            <Plus className="mr-2 h-4 w-4" /> Raise Service Request
          </Button>
        )}
      </div>

      {/* Stats */}
      <div className="grid grid-cols-2 gap-4 lg:grid-cols-4">
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <MessageSquareText className="h-5 w-5 text-primary" />
            <div><p className="text-lg font-bold text-foreground">{scopedSRs.length}</p><p className="text-xs text-muted-foreground">Total SRs</p></div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <Inbox className="h-5 w-5 text-blue-600" />
            <div><p className="text-lg font-bold text-foreground">{openCount}</p><p className="text-xs text-muted-foreground">Open</p></div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <Clock className="h-5 w-5 text-amber-600" />
            <div><p className="text-lg font-bold text-foreground">{inProgressCount}</p><p className="text-xs text-muted-foreground">In Progress</p></div>
          </CardContent>
        </Card>
        <Card className="border-border/60">
          <CardContent className="flex items-center gap-3 p-4">
            <CheckCircle2 className="h-5 w-5 text-green-600" />
            <div><p className="text-lg font-bold text-foreground">{resolvedCount}</p><p className="text-xs text-muted-foreground">Resolved</p></div>
          </CardContent>
        </Card>
      </div>

      <Tabs defaultValue="my_requests" className="w-full">
        <TabsList className="bg-muted">
          <TabsTrigger value="my_requests" className="text-foreground data-[state=active]:bg-background">My Requests</TabsTrigger>
          {canManage && <TabsTrigger value="manage" className="text-foreground data-[state=active]:bg-background">Manage Requests ({manageableSRs.length})</TabsTrigger>}
        </TabsList>

        <TabsContent value="my_requests" className="mt-4 flex flex-col gap-4">
          <Card className="border-border/60">
            <CardContent className="p-4">
              <div className="flex flex-wrap items-center gap-3">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
                  <Input placeholder="Search by SR ID or subject..." value={search} onChange={(e) => setSearch(e.target.value)} className="border-border bg-background pl-9 text-foreground" />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px] border-border bg-background text-foreground"><SelectValue placeholder="Status" /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    {Object.entries(statusConfig).map(([k, v]) => <SelectItem key={k} value={k}>{v.label}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            </CardContent>
          </Card>
          <Card className="border-border/60">
            <CardContent className="p-0">
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent">
                    <TableHead className="text-foreground w-[110px]">SR ID</TableHead>
                    <TableHead className="text-foreground">Subject</TableHead>
                    <TableHead className="text-foreground">Module</TableHead>
                    <TableHead className="text-foreground">Status</TableHead>
                    <TableHead className="text-foreground">Raised By</TableHead>
                    <TableHead className="text-foreground">Created</TableHead>
                    <TableHead className="text-foreground">Remarks</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredSRs.map((sr) => {
                    const sConfig = statusConfig[sr.status]
                    const raiser = getUserById(sr.userId)
                    const moduleLabel = modules.find((m) => m.value === sr.module)?.label || sr.module
                    return (
                      <TableRow key={sr.id} className="cursor-pointer hover:bg-muted/50" onClick={() => { setSelectedSR(sr); setShowDetailDialog(true) }}>
                        <TableCell><span className="font-mono text-xs text-primary">{sr.srId}</span></TableCell>
                        <TableCell className="font-medium text-foreground">{sr.subject}</TableCell>
                        <TableCell><Badge variant="outline" className="text-xs">{moduleLabel}</Badge></TableCell>
                        <TableCell><Badge variant="secondary" className={sConfig.color}>{sConfig.label}</Badge></TableCell>
                        <TableCell className="text-sm text-foreground">{raiser?.name || "-"}</TableCell>
                        <TableCell className="text-xs text-muted-foreground">{formatDateTime(sr.createdAt)}</TableCell>
                        <TableCell className="text-xs text-muted-foreground max-w-[200px] truncate">{sr.remarks || "-"}</TableCell>
                      </TableRow>
                    )
                  })}
                  {filteredSRs.length === 0 && <TableRow><TableCell colSpan={7} className="py-8 text-center text-muted-foreground">No service requests found</TableCell></TableRow>}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {canManage && (
          <TabsContent value="manage" className="mt-4">
            <Card className="border-border/60">
              <CardHeader>
                <CardTitle className="text-lg text-foreground">Pending Service Requests</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow className="hover:bg-transparent">
                      <TableHead className="text-foreground w-[110px]">SR ID</TableHead>
                      <TableHead className="text-foreground">Subject</TableHead>
                      <TableHead className="text-foreground">Module</TableHead>
                      <TableHead className="text-foreground">Raised By</TableHead>
                      <TableHead className="text-foreground">Created</TableHead>
                      <TableHead className="text-foreground">Status</TableHead>
                      <TableHead className="text-right text-foreground">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {manageableSRs.map((sr) => {
                      const raiser = getUserById(sr.userId)
                      const sConfig = statusConfig[sr.status]
                      return (
                        <TableRow key={sr.id}>
                          <TableCell><span className="font-mono text-xs text-primary">{sr.srId}</span></TableCell>
                          <TableCell>
                            <div className="flex flex-col">
                              <span className="font-medium text-foreground">{sr.subject}</span>
                              <span className="text-xs text-muted-foreground line-clamp-1">{sr.description}</span>
                            </div>
                          </TableCell>
                          <TableCell><Badge variant="outline" className="text-xs">{modules.find((m) => m.value === sr.module)?.label}</Badge></TableCell>
                          <TableCell className="text-sm text-foreground">{raiser?.name || "-"}</TableCell>
                          <TableCell className="text-xs text-muted-foreground">{formatDateTime(sr.createdAt)}</TableCell>
                          <TableCell><Badge variant="secondary" className={sConfig.color}>{sConfig.label}</Badge></TableCell>
                          <TableCell className="text-right">
                            <div className="flex items-center justify-end gap-1">
                              {sr.status === "open" && (
                                <Button size="sm" variant="outline" className="h-7 text-xs border-blue-200 text-blue-700 hover:bg-blue-50" onClick={() => handleStatusChange(sr.id, "in_progress")}>
                                  Start
                                </Button>
                              )}
                              <Button size="sm" variant="outline" className="h-7 text-xs border-green-200 text-green-700 hover:bg-green-50" onClick={() => { setSelectedSR(sr); setActionRemark(""); setShowDetailDialog(true) }}>
                                Resolve
                              </Button>
                              <Button size="sm" variant="outline" className="h-7 text-xs border-red-200 text-red-600 hover:bg-red-50" onClick={() => handleStatusChange(sr.id, "rejected")}>
                                Reject
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      )
                    })}
                    {manageableSRs.length === 0 && <TableRow><TableCell colSpan={7} className="py-8 text-center text-muted-foreground">No pending service requests</TableCell></TableRow>}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </TabsContent>
        )}
      </Tabs>

      {/* Create SR Dialog */}
      <Dialog open={showCreateDialog} onOpenChange={setShowCreateDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          <DialogHeader>
            <DialogTitle className="text-foreground">Raise Service Request</DialogTitle>
            <DialogDescription className="text-muted-foreground">Submit a request for changes or support across any module.</DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Module</Label>
              <Select value={formData.module} onValueChange={(v) => setFormData({ ...formData, module: v as ServiceRequestModule })}>
                <SelectTrigger className="border-border bg-background text-foreground"><SelectValue /></SelectTrigger>
                <SelectContent>{modules.map((m) => <SelectItem key={m.value} value={m.value}>{m.label}</SelectItem>)}</SelectContent>
              </Select>
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Subject *</Label>
              <Input value={formData.subject} onChange={(e) => setFormData({ ...formData, subject: e.target.value })} placeholder="Brief subject of your request" className="border-border bg-background text-foreground" />
            </div>
            <div className="flex flex-col gap-2">
              <Label className="text-foreground">Description *</Label>
              <Textarea value={formData.description} onChange={(e) => setFormData({ ...formData, description: e.target.value })} placeholder="Provide detailed description of what you need..." rows={4} className="border-border bg-background text-foreground" />
            </div>
            <DialogFooter>
              <Button onClick={handleCreate} disabled={!formData.subject || !formData.description} className="bg-primary text-primary-foreground hover:bg-primary/90">Submit Request</Button>
            </DialogFooter>
          </div>
        </DialogContent>
      </Dialog>

      {/* Detail / Resolve Dialog */}
      <Dialog open={showDetailDialog} onOpenChange={setShowDetailDialog}>
        <DialogContent className="max-w-lg bg-card text-card-foreground">
          {selectedSR && (() => {
            const sConfig = statusConfig[selectedSR.status]
            const raiser = getUserById(selectedSR.userId)
            const resolver = selectedSR.resolvedBy ? getUserById(selectedSR.resolvedBy) : null
            return (
              <>
                <DialogHeader>
                  <div className="flex items-center gap-2">
                    <span className="font-mono text-sm text-primary">{selectedSR.srId}</span>
                    <Badge variant="secondary" className={sConfig.color}>{sConfig.label}</Badge>
                  </div>
                  <DialogTitle className="text-foreground">{selectedSR.subject}</DialogTitle>
                </DialogHeader>
                <div className="flex flex-col gap-3">
                  <div className="grid grid-cols-2 gap-3 text-sm">
                    <div className="rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Module</span><p className="font-medium capitalize text-foreground">{selectedSR.module}</p></div>
                    <div className="rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Raised By</span><p className="font-medium text-foreground">{raiser?.name || "-"}</p></div>
                    <div className="rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Created</span><p className="font-medium text-foreground">{formatDateTime(selectedSR.createdAt)}</p></div>
                    <div className="rounded-lg bg-muted/50 px-3 py-2"><span className="text-xs text-muted-foreground">Updated</span><p className="font-medium text-foreground">{formatDateTime(selectedSR.updatedAt)}</p></div>
                  </div>
                  <div className="rounded-lg bg-muted/50 px-3 py-2 text-sm"><span className="text-xs text-muted-foreground">Description</span><p className="mt-1 text-foreground">{selectedSR.description}</p></div>
                  {selectedSR.remarks && <div className="rounded-lg bg-muted/50 px-3 py-2 text-sm"><span className="text-xs text-muted-foreground">Remarks</span><p className="mt-1 text-foreground">{selectedSR.remarks}</p></div>}
                  {resolver && <div className="rounded-lg bg-muted/50 px-3 py-2 text-sm"><span className="text-xs text-muted-foreground">Resolved By</span><p className="mt-1 font-medium text-foreground">{resolver.name}</p></div>}
                  {canManage && (selectedSR.status === "open" || selectedSR.status === "in_progress") && (
                    <>
                      <Separator />
                      <div className="flex flex-col gap-2">
                        <Label className="text-foreground">Remarks (optional)</Label>
                        <Textarea value={actionRemark} onChange={(e) => setActionRemark(e.target.value)} placeholder="Add remarks..." rows={2} className="border-border bg-background text-foreground" />
                      </div>
                      <div className="flex items-center gap-2">
                        {selectedSR.status === "open" && <Button size="sm" className="bg-blue-600 text-white hover:bg-blue-700" onClick={() => handleStatusChange(selectedSR.id, "in_progress")}>Mark In Progress</Button>}
                        <Button size="sm" className="bg-green-600 text-white hover:bg-green-700" onClick={() => handleStatusChange(selectedSR.id, "resolved")}>Resolve</Button>
                        <Button size="sm" variant="outline" className="border-red-200 text-red-600 hover:bg-red-50" onClick={() => handleStatusChange(selectedSR.id, "rejected")}>Reject</Button>
                      </div>
                    </>
                  )}
                </div>
              </>
            )
          })()}
        </DialogContent>
      </Dialog>
    </div>
  )
}
