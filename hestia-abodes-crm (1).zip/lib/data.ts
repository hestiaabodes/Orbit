// Dummy data for the CRM

export type UserRole = "admin" | "manager" | "sales_executive" | "presales_executive" | "viewer"

export const roleLabels: Record<UserRole, string> = {
  admin: "Principal Consultant",
  manager: "Team Lead",
  sales_executive: "Sales Executive",
  presales_executive: "Presales Executive",
  viewer: "Viewer",
}

export interface User {
  id: string
  name: string
  email: string
  password: string
  role: UserRole
  phone: string
  department: string
  avatar?: string
  isActive: boolean
  createdAt: string
  lastLogin?: string
  managerId?: string
  weekOffs: string[]
}

export type LeadStatus =
  | "new" | "contact_established" | "not_connected" | "details_shared"
  | "site_visit_scheduled" | "site_visit_done" | "won" | "lost"
  | "unqualified" | "resale_seller" | "resale_buyer"

export type LeadSubStatus =
  | "hot" | "warm" | "cold" | "asked_to_call_later" | "follow_up_scheduled"
  | "not_responding" | "booked" | "booked_with_others" | "low_budget"
  | "not_looking_for_properties" | "no_inventory" | "is_a_cp"

export interface Lead {
  id: string
  leadId: string // Sequential ID like HA00001
  name: string
  email: string
  phone: string
  alternatePhone?: string
  source: string
  status: LeadStatus
  subStatus: LeadSubStatus
  assignedTo: string
  projectInterest: string
  budget: string
  notes: string
  createdAt: string
  updatedAt: string
  lastContactedAt?: string
  nextFollowUp?: string
  activities: Activity[]
}

export interface Activity {
  id: string
  type: "call" | "email" | "meeting" | "note" | "site_visit" | "whatsapp" | "status_change" | "sms"
  description: string
  createdAt: string // ISO string with time
  createdBy: string
}

export interface Project {
  id: string
  name: string
  location: string
  type: "residential" | "commercial" | "villa" | "plot"
  status: "upcoming" | "ongoing" | "completed"
  totalUnits: number
  availableUnits: number
  priceRange: string
  description: string
  amenities: string[]
  image?: string
  createdAt: string
}

export interface Task {
  id: string
  title: string
  description: string
  assignedTo: string
  assignedBy: string
  priority: "low" | "medium" | "high" | "urgent"
  status: "pending" | "in_progress" | "completed" | "overdue"
  dueDate: string
  leadId?: string
  createdAt: string
}

// Service Request for Help Desk
export type ServiceRequestModule = "leads" | "projects" | "tasks" | "hrms" | "general"
export type ServiceRequestStatus = "open" | "in_progress" | "resolved" | "closed" | "rejected"

export interface ServiceRequest {
  id: string
  srId: string // Sequential SR-00001
  userId: string
  module: ServiceRequestModule
  subject: string
  description: string
  status: ServiceRequestStatus
  assignedTo?: string
  resolvedBy?: string
  createdAt: string
  updatedAt: string
  remarks?: string
}

// Field-level edit permissions
export interface FieldEditPermissions {
  name: boolean; email: boolean; phone: boolean; alternatePhone: boolean; source: boolean
  status: boolean; subStatus: boolean; assignedTo: boolean
  projectInterest: boolean; budget: boolean; notes: boolean; nextFollowUp: boolean
}

export function getFieldEditPermissions(role: UserRole): FieldEditPermissions {
  switch (role) {
    case "admin":
      return { name: true, email: true, phone: true, alternatePhone: true, source: true, status: true, subStatus: true, assignedTo: true, projectInterest: true, budget: true, notes: true, nextFollowUp: true }
    case "manager":
      return { name: true, email: true, phone: false, alternatePhone: false, source: false, status: true, subStatus: true, assignedTo: true, projectInterest: true, budget: true, notes: true, nextFollowUp: true }
    case "sales_executive":
    case "presales_executive":
      return { name: false, email: false, phone: false, alternatePhone: false, source: false, status: true, subStatus: true, assignedTo: false, projectInterest: true, budget: true, notes: true, nextFollowUp: true }
    case "viewer":
    default:
      return { name: false, email: false, phone: false, alternatePhone: false, source: false, status: false, subStatus: false, assignedTo: false, projectInterest: false, budget: false, notes: false, nextFollowUp: false }
  }
}

export interface RolePermission {
  role: UserRole
  permissions: {
    dashboard: { view: boolean }
    leads: { view: boolean; create: boolean; edit: boolean; delete: boolean; assign: boolean; export: boolean }
    projects: { view: boolean; create: boolean; edit: boolean; delete: boolean }
    tasks: { view: boolean; create: boolean; edit: boolean; delete: boolean; assign: boolean }
    team: { view: boolean; manage: boolean }
    reports: { view: boolean; export: boolean }
    admin: { access: boolean; manageUsers: boolean; manageRoles: boolean; manageSettings: boolean }
    hrms: { view: boolean; manage: boolean; approve: boolean }
    helpdesk: { view: boolean; create: boolean; manage: boolean }
  }
}

export const rolePermissions: RolePermission[] = [
  { role: "admin", permissions: { dashboard: { view: true }, leads: { view: true, create: true, edit: true, delete: true, assign: true, export: true }, projects: { view: true, create: true, edit: true, delete: true }, tasks: { view: true, create: true, edit: true, delete: true, assign: true }, team: { view: true, manage: true }, reports: { view: true, export: true }, admin: { access: true, manageUsers: true, manageRoles: true, manageSettings: true }, hrms: { view: true, manage: true, approve: true }, helpdesk: { view: true, create: true, manage: true } } },
  { role: "manager", permissions: { dashboard: { view: true }, leads: { view: true, create: true, edit: true, delete: false, assign: true, export: true }, projects: { view: true, create: true, edit: true, delete: false }, tasks: { view: true, create: true, edit: true, delete: false, assign: true }, team: { view: true, manage: false }, reports: { view: true, export: true }, admin: { access: false, manageUsers: false, manageRoles: false, manageSettings: false }, hrms: { view: true, manage: false, approve: true }, helpdesk: { view: true, create: true, manage: true } } },
  { role: "sales_executive", permissions: { dashboard: { view: true }, leads: { view: true, create: true, edit: true, delete: false, assign: false, export: false }, projects: { view: true, create: false, edit: false, delete: false }, tasks: { view: true, create: true, edit: true, delete: false, assign: false }, team: { view: false, manage: false }, reports: { view: true, export: false }, admin: { access: false, manageUsers: false, manageRoles: false, manageSettings: false }, hrms: { view: true, manage: false, approve: false }, helpdesk: { view: true, create: true, manage: false } } },
  { role: "presales_executive", permissions: { dashboard: { view: true }, leads: { view: true, create: true, edit: true, delete: false, assign: false, export: false }, projects: { view: true, create: false, edit: false, delete: false }, tasks: { view: true, create: true, edit: true, delete: false, assign: false }, team: { view: false, manage: false }, reports: { view: true, export: false }, admin: { access: false, manageUsers: false, manageRoles: false, manageSettings: false }, hrms: { view: true, manage: false, approve: false }, helpdesk: { view: true, create: true, manage: false } } },
  { role: "viewer", permissions: { dashboard: { view: true }, leads: { view: true, create: false, edit: false, delete: false, assign: false, export: false }, projects: { view: true, create: false, edit: false, delete: false }, tasks: { view: true, create: false, edit: false, delete: false, assign: false }, team: { view: false, manage: false }, reports: { view: true, export: false }, admin: { access: false, manageUsers: false, manageRoles: false, manageSettings: false }, hrms: { view: true, manage: false, approve: false }, helpdesk: { view: true, create: true, manage: false } } },
]

// HRMS Types
export type LeaveType = "casual" | "sick" | "earned" | "unpaid" | "comp_off"
export type LeaveStatus = "pending" | "approved" | "rejected"
export type ReimbursementCategory = "travel" | "food" | "accommodation" | "office_supplies" | "client_meeting" | "other"
export type ReimbursementStatus = "pending" | "approved" | "rejected"
export type AttendanceStatus = "present" | "absent" | "half_day" | "week_off" | "leave_requested" | "leave_approved"

export interface AttendanceRecord { id: string; userId: string; date: string; loginTime: string | null; logoutTime: string | null; totalHours: string; status: AttendanceStatus }
export interface LeaveRequest { id: string; userId: string; type: LeaveType; startDate: string; endDate: string; days: number; reason: string; status: LeaveStatus; approvedBy?: string; appliedOn: string; remark?: string }
export interface LeaveBalance { userId: string; casual: { total: number; used: number }; sick: { total: number; used: number }; earned: { total: number; used: number }; comp_off: { total: number; used: number } }
export interface Reimbursement { id: string; userId: string; category: ReimbursementCategory; amount: number; description: string; date: string; receipt?: string; status: ReimbursementStatus; approvedBy?: string; appliedOn: string; remark?: string }

export type DocumentType = "aadhaar_card" | "pan_card" | "passport_photo" | "education_10th" | "education_12th" | "education_graduation" | "education_post_graduation" | "education_other" | "work_experience" | "pay_slips" | "bank_details"

export interface EmployeeDocument {
  id: string; userId: string; type: DocumentType; label: string
  fileName: string; fileData?: string; uploadedAt: string
}

export interface BankDetails {
  userId: string; accountHolderName: string; bankName: string
  accountNumber: string; ifscCode: string; branch: string; documentFileName?: string
}

export const documentTypeLabels: Record<DocumentType, string> = {
  aadhaar_card: "Aadhaar Card", pan_card: "PAN Card", passport_photo: "Passport Size Photo",
  education_10th: "10th Certificate", education_12th: "12th Certificate",
  education_graduation: "Graduation Certificate", education_post_graduation: "Post Graduation Certificate",
  education_other: "Other Certifications", work_experience: "Relieving Letter / Experience",
  pay_slips: "Pay Slips", bank_details: "Bank Passbook / Cancelled Cheque",
}

// Utility: format date as DD-MM-YYYY
export function formatDate(dateStr: string | undefined | null): string {
  if (!dateStr) return "-"
  // Handle ISO strings
  const datePart = dateStr.includes("T") ? dateStr.split("T")[0] : dateStr
  const parts = datePart.split("-")
  if (parts.length !== 3) return dateStr
  return `${parts[2]}-${parts[1]}-${parts[0]}`
}

// Utility: format datetime as DD-MM-YYYY HH:MM AM/PM
export function formatDateTime(dateStr: string | undefined | null): string {
  if (!dateStr) return "-"
  try {
    const d = new Date(dateStr)
    if (isNaN(d.getTime())) return formatDate(dateStr)
    const day = String(d.getDate()).padStart(2, "0")
    const month = String(d.getMonth() + 1).padStart(2, "0")
    const year = d.getFullYear()
    let hours = d.getHours()
    const mins = String(d.getMinutes()).padStart(2, "0")
    const ampm = hours >= 12 ? "PM" : "AM"
    hours = hours % 12
    if (hours === 0) hours = 12
    return `${day}-${month}-${year} ${String(hours).padStart(2, "0")}:${mins} ${ampm}`
  } catch {
    return formatDate(dateStr)
  }
}

export function getNowISO(): string {
  return new Date().toISOString()
}

// Lead status / sub-status / source definitions
export const leadStatuses: { value: LeadStatus; label: string; color: string }[] = [
  { value: "new", label: "New", color: "bg-blue-100 text-blue-700" },
  { value: "contact_established", label: "Contact Established", color: "bg-emerald-100 text-emerald-700" },
  { value: "not_connected", label: "Not Connected", color: "bg-gray-100 text-gray-600" },
  { value: "details_shared", label: "Details Shared", color: "bg-indigo-100 text-indigo-700" },
  { value: "site_visit_scheduled", label: "Site Visit Scheduled", color: "bg-amber-100 text-amber-700" },
  { value: "site_visit_done", label: "Site Visit Done", color: "bg-teal-100 text-teal-700" },
  { value: "won", label: "Won", color: "bg-green-100 text-green-700" },
  { value: "lost", label: "Lost", color: "bg-red-100 text-red-600" },
  { value: "unqualified", label: "Unqualified", color: "bg-stone-100 text-stone-600" },
  { value: "resale_seller", label: "Resale - Seller", color: "bg-purple-100 text-purple-700" },
  { value: "resale_buyer", label: "Resale - Buyer", color: "bg-pink-100 text-pink-700" },
]

export const leadSubStatuses: { value: LeadSubStatus; label: string; color: string }[] = [
  { value: "hot", label: "Hot", color: "bg-red-100 text-red-700" },
  { value: "warm", label: "Warm", color: "bg-orange-100 text-orange-600" },
  { value: "cold", label: "Cold", color: "bg-sky-100 text-sky-600" },
  { value: "asked_to_call_later", label: "Asked to Call Later", color: "bg-yellow-100 text-yellow-700" },
  { value: "follow_up_scheduled", label: "Follow-up Scheduled", color: "bg-blue-100 text-blue-600" },
  { value: "not_responding", label: "Not Responding", color: "bg-gray-100 text-gray-600" },
  { value: "booked", label: "Booked", color: "bg-green-100 text-green-700" },
  { value: "booked_with_others", label: "Booked with Others", color: "bg-red-100 text-red-600" },
  { value: "low_budget", label: "Low Budget", color: "bg-amber-100 text-amber-600" },
  { value: "not_looking_for_properties", label: "Not Looking", color: "bg-stone-100 text-stone-600" },
  { value: "no_inventory", label: "No Inventory", color: "bg-slate-100 text-slate-600" },
  { value: "is_a_cp", label: "Is a CP", color: "bg-violet-100 text-violet-600" },
]

export const leadSources = ["Facebook", "Instagram", "Google Ads", "Website", "99acres", "MagicBricks", "Housing.com", "OLX", "Referral", "Walk-in", "Call-in", "WhatsApp", "Other"]

// Users
export const dummyUsers: User[] = [
  { id: "u1", name: "Rajesh Kumar", email: "admin@hestiaabodes.in", password: "admin123", role: "admin", phone: "+91 98765 43210", department: "Management", isActive: true, createdAt: "2025-01-15", lastLogin: "2026-02-13", weekOffs: ["sunday"] },
  { id: "u2", name: "Priya Sharma", email: "priya@hestiaabodes.in", password: "priya123", role: "manager", phone: "+91 98765 43211", department: "Sales", isActive: true, createdAt: "2025-02-01", lastLogin: "2026-02-12", managerId: "u1", weekOffs: ["sunday"] },
  { id: "u3", name: "Amit Patel", email: "amit@hestiaabodes.in", password: "amit123", role: "sales_executive", phone: "+91 98765 43212", department: "Sales", isActive: true, createdAt: "2025-03-10", lastLogin: "2026-02-13", managerId: "u2", weekOffs: ["sunday"] },
  { id: "u4", name: "Sneha Reddy", email: "sneha@hestiaabodes.in", password: "sneha123", role: "sales_executive", phone: "+91 98765 43213", department: "Sales", isActive: true, createdAt: "2025-03-15", lastLogin: "2026-02-11", managerId: "u2", weekOffs: ["sunday"] },
  { id: "u5", name: "Vikram Singh", email: "vikram@hestiaabodes.in", password: "vikram123", role: "presales_executive", phone: "+91 98765 43214", department: "Pre-Sales", isActive: true, createdAt: "2025-04-01", lastLogin: "2026-02-10", managerId: "u2", weekOffs: ["saturday", "sunday"] },
  { id: "u6", name: "Neha Gupta", email: "viewer@hestiaabodes.in", password: "viewer123", role: "viewer", phone: "+91 98765 43215", department: "Marketing", isActive: false, createdAt: "2025-05-20", lastLogin: "2026-01-05", managerId: "u1", weekOffs: ["saturday", "sunday"] },
  { id: "u7", name: "Rohit Mehra", email: "rohit@hestiaabodes.in", password: "rohit123", role: "sales_executive", phone: "+91 98765 43216", department: "Sales", isActive: true, createdAt: "2025-06-10", lastLogin: "2026-02-14", managerId: "u2", weekOffs: ["sunday"] },
]

export const dummyProjects: Project[] = [
  { id: "p1", name: "Hestia Grand Residences", location: "Whitefield, Bangalore", type: "residential", status: "ongoing", totalUnits: 120, availableUnits: 45, priceRange: "65L - 1.2Cr", description: "Premium 2 & 3 BHK apartments.", amenities: ["Swimming Pool", "Gym", "Clubhouse", "Garden", "Children's Play Area", "24/7 Security"], createdAt: "2025-01-01" },
  { id: "p2", name: "Hestia Business Park", location: "Bandra Kurla Complex, Mumbai", type: "commercial", status: "ongoing", totalUnits: 80, availableUnits: 32, priceRange: "1.5Cr - 5Cr", description: "Premium Grade A office spaces.", amenities: ["Parking", "Food Court", "Conference Room", "High-Speed Elevator", "Power Backup"], createdAt: "2025-02-15" },
  { id: "p3", name: "Hestia Valley Villas", location: "Lonavala, Maharashtra", type: "villa", status: "upcoming", totalUnits: 40, availableUnits: 40, priceRange: "2Cr - 4.5Cr", description: "Luxury villas in Sahyadri mountains.", amenities: ["Private Pool", "Garden", "Smart Home", "Helipad Access", "Spa", "Golf Course"], createdAt: "2025-06-01" },
  { id: "p4", name: "Hestia Green Plots", location: "Devanahalli, Bangalore", type: "plot", status: "ongoing", totalUnits: 200, availableUnits: 87, priceRange: "30L - 80L", description: "RERA approved residential plots.", amenities: ["Gated Community", "Road Connectivity", "Water Supply", "Electricity", "Parks"], createdAt: "2025-03-20" },
  { id: "p5", name: "Hestia Skyline Towers", location: "Gachibowli, Hyderabad", type: "residential", status: "completed", totalUnits: 200, availableUnits: 12, priceRange: "55L - 95L", description: "Completed premium residential project.", amenities: ["Swimming Pool", "Gym", "Tennis Court", "Jogging Track", "Multipurpose Hall"], createdAt: "2024-01-01" },
]

// Leads with sequential leadId
export const dummyLeads: Lead[] = [
  { id: "l1", leadId: "HA00001", name: "Arjun Mehta", email: "arjun.mehta@gmail.com", phone: "+91 99887 76543", alternatePhone: "+91 98765 00001", source: "Facebook", status: "new", subStatus: "hot", assignedTo: "u3", projectInterest: "p1", budget: "80L - 1Cr", notes: "Interested in 3BHK, wants south-facing.", createdAt: "2026-02-12T09:30:00", updatedAt: "2026-02-12T09:30:00", nextFollowUp: "2026-02-14", activities: [{ id: "a1", type: "note", description: "Lead captured from Facebook campaign", createdAt: "2026-02-12T09:30:00", createdBy: "u3" }] },
  { id: "l2", leadId: "HA00002", name: "Kavita Joshi", email: "kavita.j@yahoo.com", phone: "+91 88776 65432", source: "Website", status: "contact_established", subStatus: "warm", assignedTo: "u4", projectInterest: "p1", budget: "65L - 80L", notes: "Looking for 2BHK for investment.", createdAt: "2026-02-10T11:15:00", updatedAt: "2026-02-11T14:20:00", lastContactedAt: "2026-02-11T14:20:00", nextFollowUp: "2026-02-15", activities: [{ id: "a2", type: "call", description: "Initial call - discussed project details", createdAt: "2026-02-11T14:20:00", createdBy: "u4" }, { id: "a3", type: "note", description: "Lead from website inquiry", createdAt: "2026-02-10T11:15:00", createdBy: "u4" }] },
  { id: "l3", leadId: "HA00003", name: "Ravi Shankar", email: "ravi.shankar@outlook.com", phone: "+91 77665 54321", alternatePhone: "+91 77665 99999", source: "99acres", status: "details_shared", subStatus: "hot", assignedTo: "u3", projectInterest: "p2", budget: "2Cr - 3Cr", notes: "Corporate client looking for office space.", createdAt: "2026-02-05T10:00:00", updatedAt: "2026-02-12T16:45:00", lastContactedAt: "2026-02-12T16:45:00", nextFollowUp: "2026-02-13", activities: [{ id: "a4", type: "meeting", description: "Site visit completed. Client impressed", createdAt: "2026-02-12T16:45:00", createdBy: "u3" }, { id: "a5", type: "email", description: "Sent brochure and floor plans", createdAt: "2026-02-08T09:00:00", createdBy: "u3" }] },
  { id: "l4", leadId: "HA00004", name: "Deepika Nair", email: "deepika.nair@gmail.com", phone: "+91 66554 43210", source: "MagicBricks", status: "site_visit_done", subStatus: "hot", assignedTo: "u5", projectInterest: "p3", budget: "3Cr - 4Cr", notes: "Interested in premium villa with pool.", createdAt: "2026-01-20T15:30:00", updatedAt: "2026-02-10T11:00:00", lastContactedAt: "2026-02-10T11:00:00", nextFollowUp: "2026-02-14", activities: [{ id: "a7", type: "meeting", description: "Discussed pricing and payment plans", createdAt: "2026-02-10T11:00:00", createdBy: "u5" }, { id: "a8", type: "site_visit", description: "Site visit completed, interested in Plot 12", createdAt: "2026-02-02T10:30:00", createdBy: "u5" }] },
  { id: "l5", leadId: "HA00005", name: "Suresh Prabhu", email: "suresh.p@gmail.com", phone: "+91 55443 32109", source: "Referral", status: "site_visit_scheduled", subStatus: "follow_up_scheduled", assignedTo: "u4", projectInterest: "p5", budget: "70L - 90L", notes: "Referred by existing customer.", createdAt: "2026-02-01T08:45:00", updatedAt: "2026-02-09T17:00:00", lastContactedAt: "2026-02-09T17:00:00", nextFollowUp: "2026-02-13", activities: [{ id: "a11", type: "site_visit", description: "Visited sample flat", createdAt: "2026-02-09T17:00:00", createdBy: "u4" }] },
  { id: "l6", leadId: "HA00006", name: "Meera Kapoor", email: "meera.k@hotmail.com", phone: "+91 44332 21098", source: "Google Ads", status: "won", subStatus: "booked", assignedTo: "u3", projectInterest: "p5", budget: "85L", notes: "Booked 3BHK Unit #507.", createdAt: "2025-12-15T12:00:00", updatedAt: "2026-02-05T10:30:00", lastContactedAt: "2026-02-05T10:30:00", activities: [{ id: "a13", type: "status_change", description: "Lead converted - Booked Unit #507", createdAt: "2026-02-05T10:30:00", createdBy: "u3" }] },
  { id: "l7", leadId: "HA00007", name: "Anil Deshmukh", email: "anil.d@gmail.com", phone: "+91 33221 10987", source: "Housing.com", status: "lost", subStatus: "booked_with_others", assignedTo: "u5", projectInterest: "p4", budget: "40L - 50L", notes: "Went with competitor.", createdAt: "2025-11-01T09:00:00", updatedAt: "2026-01-15T14:00:00", lastContactedAt: "2026-01-15T14:00:00", activities: [{ id: "a16", type: "status_change", description: "Marked as lost - chose competitor", createdAt: "2026-01-15T14:00:00", createdBy: "u5" }] },
  { id: "l8", leadId: "HA00008", name: "Pooja Verma", email: "pooja.v@gmail.com", phone: "+91 22110 09876", source: "Walk-in", status: "contact_established", subStatus: "warm", assignedTo: "u3", projectInterest: "p4", budget: "35L - 55L", notes: "Walk-in customer.", createdAt: "2026-02-08T13:00:00", updatedAt: "2026-02-09T10:00:00", lastContactedAt: "2026-02-09T10:00:00", nextFollowUp: "2026-02-16", activities: [{ id: "a18", type: "call", description: "Discussed available plots", createdAt: "2026-02-09T10:00:00", createdBy: "u3" }] },
  { id: "l9", leadId: "HA00009", name: "Rahul Dravid", email: "rahul.d@yahoo.com", phone: "+91 11009 98765", source: "Instagram", status: "new", subStatus: "cold", assignedTo: "u4", projectInterest: "p1", budget: "60L - 75L", notes: "Instagram DM inquiry.", createdAt: "2026-02-13T07:30:00", updatedAt: "2026-02-13T07:30:00", nextFollowUp: "2026-02-15", activities: [{ id: "a20", type: "note", description: "Instagram inquiry", createdAt: "2026-02-13T07:30:00", createdBy: "u4" }] },
  { id: "l10", leadId: "HA00010", name: "Ananya Iyer", email: "ananya.i@gmail.com", phone: "+91 99001 12345", source: "Facebook", status: "details_shared", subStatus: "warm", assignedTo: "u5", projectInterest: "p3", budget: "2.5Cr - 3.5Cr", notes: "NRI client in Dubai.", createdAt: "2026-01-25T16:00:00", updatedAt: "2026-02-08T11:45:00", lastContactedAt: "2026-02-08T11:45:00", nextFollowUp: "2026-02-15", activities: [{ id: "a21", type: "call", description: "Video call - discussed villa options", createdAt: "2026-02-08T11:45:00", createdBy: "u5" }] },
  { id: "l11", leadId: "HA00011", name: "Vikash Yadav", email: "vikash.y@gmail.com", phone: "+91 88990 01234", source: "OLX", status: "new", subStatus: "asked_to_call_later", assignedTo: "u3", projectInterest: "p4", budget: "45L - 60L", notes: "First-time buyer.", createdAt: "2026-02-11T14:30:00", updatedAt: "2026-02-11T14:30:00", nextFollowUp: "2026-02-14", activities: [{ id: "a23", type: "note", description: "OLX lead captured", createdAt: "2026-02-11T14:30:00", createdBy: "u3" }] },
  { id: "l12", leadId: "HA00012", name: "Sanjay Malhotra", email: "sanjay.m@corp.com", phone: "+91 77880 09876", source: "Google Ads", status: "site_visit_scheduled", subStatus: "warm", assignedTo: "u4", projectInterest: "p2", budget: "2Cr - 4Cr", notes: "Looking for large office space.", createdAt: "2026-02-07T10:15:00", updatedAt: "2026-02-11T09:30:00", lastContactedAt: "2026-02-11T09:30:00", nextFollowUp: "2026-02-16", activities: [{ id: "a24", type: "call", description: "Confirmed site visit for next week", createdAt: "2026-02-11T09:30:00", createdBy: "u4" }] },
]

export const dummyTasks: Task[] = [
  { id: "t1", title: "Follow up with Arjun Mehta", description: "Call regarding 3BHK preferences", assignedTo: "u3", assignedBy: "u2", priority: "high", status: "pending", dueDate: "2026-02-14", leadId: "l1", createdAt: "2026-02-12" },
  { id: "t2", title: "Send brochure to Kavita", description: "Email Hestia Grand brochure", assignedTo: "u4", assignedBy: "u2", priority: "medium", status: "in_progress", dueDate: "2026-02-13", leadId: "l2", createdAt: "2026-02-11" },
  { id: "t3", title: "Schedule site visit for Sanjay", description: "Coordinate with project team", assignedTo: "u4", assignedBy: "u2", priority: "high", status: "pending", dueDate: "2026-02-15", leadId: "l12", createdAt: "2026-02-11" },
  { id: "t4", title: "Update pricing sheet", description: "Incorporate new pricing from finance", assignedTo: "u3", assignedBy: "u1", priority: "urgent", status: "pending", dueDate: "2026-02-12", createdAt: "2026-02-10" },
  { id: "t5", title: "Weekly team report", description: "Compile weekly lead conversion report", assignedTo: "u2", assignedBy: "u1", priority: "medium", status: "completed", dueDate: "2026-02-10", createdAt: "2026-02-08" },
  { id: "t6", title: "Negotiate pricing for Deepika", description: "Prepare pricing proposal for villa", assignedTo: "u5", assignedBy: "u2", priority: "high", status: "in_progress", dueDate: "2026-02-14", leadId: "l4", createdAt: "2026-02-10" },
]

export const dummyAttendance: AttendanceRecord[] = [
  { id: "att1", userId: "u3", date: "2026-02-13", loginTime: "09:15", logoutTime: "18:45", totalHours: "9h 30m", status: "present" },
  { id: "att2", userId: "u4", date: "2026-02-13", loginTime: "09:30", logoutTime: "17:00", totalHours: "7h 30m", status: "half_day" },
  { id: "att3", userId: "u3", date: "2026-02-12", loginTime: "09:00", logoutTime: "18:30", totalHours: "9h 30m", status: "present" },
  { id: "att4", userId: "u5", date: "2026-02-13", loginTime: "10:00", logoutTime: "19:00", totalHours: "9h 0m", status: "present" },
  { id: "att5", userId: "u2", date: "2026-02-13", loginTime: "08:45", logoutTime: "18:00", totalHours: "9h 15m", status: "present" },
]

export const dummyLeaveRequests: LeaveRequest[] = [
  { id: "lv1", userId: "u3", type: "casual", startDate: "2026-02-20", endDate: "2026-02-21", days: 2, reason: "Family function", status: "pending", appliedOn: "2026-02-13" },
  { id: "lv2", userId: "u4", type: "sick", startDate: "2026-02-10", endDate: "2026-02-10", days: 1, reason: "Not feeling well", status: "approved", approvedBy: "u2", appliedOn: "2026-02-10", remark: "Get well soon" },
]

export const dummyLeaveBalances: LeaveBalance[] = [
  { userId: "u1", casual: { total: 12, used: 1 }, sick: { total: 6, used: 0 }, earned: { total: 15, used: 2 }, comp_off: { total: 2, used: 0 } },
  { userId: "u2", casual: { total: 12, used: 2 }, sick: { total: 6, used: 1 }, earned: { total: 15, used: 3 }, comp_off: { total: 1, used: 0 } },
  { userId: "u3", casual: { total: 12, used: 3 }, sick: { total: 6, used: 1 }, earned: { total: 15, used: 2 }, comp_off: { total: 0, used: 0 } },
  { userId: "u4", casual: { total: 12, used: 2 }, sick: { total: 6, used: 2 }, earned: { total: 15, used: 1 }, comp_off: { total: 1, used: 1 } },
  { userId: "u5", casual: { total: 12, used: 1 }, sick: { total: 6, used: 0 }, earned: { total: 15, used: 0 }, comp_off: { total: 0, used: 0 } },
  { userId: "u7", casual: { total: 12, used: 0 }, sick: { total: 6, used: 0 }, earned: { total: 15, used: 0 }, comp_off: { total: 0, used: 0 } },
]

export const dummyReimbursements: Reimbursement[] = [
  { id: "r1", userId: "u3", category: "travel", amount: 2500, description: "Cab to site visit - Whitefield", date: "2026-02-12", status: "pending", appliedOn: "2026-02-12" },
  { id: "r2", userId: "u4", category: "client_meeting", amount: 1800, description: "Lunch with client at Hyatt", date: "2026-02-10", status: "approved", approvedBy: "u2", appliedOn: "2026-02-10" },
]

export const dummyDocuments: EmployeeDocument[] = [
  { id: "doc1", userId: "u3", type: "aadhaar_card", label: "Aadhaar Card", fileName: "amit_aadhaar.pdf", fileData: "aadhaar_file_data", uploadedAt: "2025-03-15" },
  { id: "doc2", userId: "u3", type: "pan_card", label: "PAN Card", fileName: "amit_pan.pdf", fileData: "pan_file_data", uploadedAt: "2025-03-15" },
]

export const dummyBankDetails: BankDetails[] = [
  { userId: "u3", accountHolderName: "Amit Patel", bankName: "HDFC Bank", accountNumber: "50100123456789", ifscCode: "HDFC0001234", branch: "Whitefield Branch" },
]

export const dummyServiceRequests: ServiceRequest[] = [
  { id: "sr1", srId: "SR-00001", userId: "u3", module: "leads", subject: "Update phone number for Lead HA00001", description: "Client provided new phone number +91 99887 76544. Please update.", status: "open", createdAt: "2026-02-13T10:30:00", updatedAt: "2026-02-13T10:30:00" },
  { id: "sr2", srId: "SR-00002", userId: "u4", module: "hrms", subject: "Request week-off change", description: "Need Saturday as week-off instead of default.", status: "resolved", resolvedBy: "u2", createdAt: "2026-02-10T09:00:00", updatedAt: "2026-02-11T11:00:00", remarks: "Updated in system" },
]
