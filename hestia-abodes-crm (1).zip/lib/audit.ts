// Audit logging -- records who changed what in the system

export async function logAudit(
  userId: string | null,
  action: string,
  entityType: string,
  entityId: string | null,
  details?: Record<string, any>,
  ipAddress?: string
) {
  try {
    const { execute } = await import("./db")
    await execute(
      "INSERT INTO audit_log (user_id, action, entity_type, entity_id, details, ip_address) VALUES (?, ?, ?, ?, ?, ?)",
      [userId, action, entityType, entityId, details ? JSON.stringify(details) : null, ipAddress || null]
    )
  } catch {
    // Silently fail -- audit logging should never break the main flow
  }
}
