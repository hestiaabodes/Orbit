"use client"

import { createContext, useContext, useState, useCallback, useRef, useEffect, type ReactNode } from "react"
import useSWR, { mutate as globalMutate } from "swr"
import {
  rolePermissions as defaultRolePermissions, getFieldEditPermissions, getNowISO,
  type User, type Lead, type Task, type Project, type UserRole, type RolePermission,
  type Activity, type FieldEditPermissions,
  type AttendanceRecord, type LeaveRequest, type LeaveBalance,
  type Reimbursement, type EmployeeDocument, type BankDetails,
  type ServiceRequest, type ServiceRequestStatus,
  // Keep dummy data as fallback when DB is not connected
  dummyUsers, dummyLeads, dummyProjects, dummyTasks,
  dummyAttendance, dummyLeaveRequests, dummyLeaveBalances, dummyReimbursements,
  dummyDocuments, dummyBankDetails, dummyServiceRequests,
} from "./data"

// SWR fetcher
const fetcher = async (url: string) => {
  const res = await fetch(url)
  if (!res.ok) {
    // If API unavailable (no DB) or unauthorized, return null so fallback kicks in
    if (res.status === 500 || res.status === 401 || res.status === 503) return null
    throw new Error("API error")
  }
  return res.json()
}

interface CRMContextType {
  currentUser: User | null
  login: (email: string, password: string) => Promise<boolean>
  logout: () => void
  isAuthenticated: boolean
  isLoading: boolean
  users: User[]
  addUser: (user: Omit<User, "id" | "createdAt">) => void
  updateUser: (id: string, user: Partial<User>) => void
  deleteUser: (id: string) => void
  getUserById: (id: string) => User | undefined
  getTeamMemberIds: () => string[]
  getScopedLeads: () => Lead[]
  getScopedTasks: () => Task[]
  getScopedTeamMembers: () => User[]
  getFieldPermissions: () => FieldEditPermissions
  getAssignableUsers: () => User[]
  leads: Lead[]
  leadCounter: number
  addLead: (lead: Omit<Lead, "id" | "leadId" | "createdAt" | "updatedAt" | "activities">) => void
  updateLead: (id: string, lead: Partial<Lead>) => void
  deleteLead: (id: string) => void
  addLeadActivity: (leadId: string, activity: Omit<Activity, "id" | "createdAt">) => void
  projects: Project[]
  addProject: (project: Omit<Project, "id" | "createdAt">) => void
  updateProject: (id: string, project: Partial<Project>) => void
  deleteProject: (id: string) => void
  tasks: Task[]
  addTask: (task: Omit<Task, "id" | "createdAt">) => void
  updateTask: (id: string, task: Partial<Task>) => void
  deleteTask: (id: string) => void
  hasPermission: (category: string, action: string) => boolean
  getRolePermissions: (role: UserRole) => RolePermission | undefined
  allRolePermissions: RolePermission[]
  updateRolePermissions: (role: UserRole, permissions: RolePermission["permissions"]) => void
  attendance: AttendanceRecord[]
  markLogin: (userId: string) => void
  markLogout: (userId: string) => void
  leaveRequests: LeaveRequest[]
  addLeaveRequest: (req: Omit<LeaveRequest, "id" | "appliedOn" | "status">) => void
  updateLeaveRequest: (id: string, data: Partial<LeaveRequest>) => void
  leaveBalances: LeaveBalance[]
  reimbursements: Reimbursement[]
  addReimbursement: (req: Omit<Reimbursement, "id" | "appliedOn" | "status">) => void
  updateReimbursement: (id: string, data: Partial<Reimbursement>) => void
  getScopedAttendance: () => AttendanceRecord[]
  getScopedLeaveRequests: () => LeaveRequest[]
  getScopedReimbursements: () => Reimbursement[]
  getApprovableLeaveRequests: () => LeaveRequest[]
  getApprovableReimbursements: () => Reimbursement[]
  documents: EmployeeDocument[]
  addDocument: (doc: Omit<EmployeeDocument, "id" | "uploadedAt">) => void
  deleteDocument: (id: string) => void
  canEditDocument: (docUserId: string) => boolean
  bankDetails: BankDetails[]
  updateBankDetails: (userId: string, data: BankDetails) => void
  canEditBankDetails: (targetUserId: string) => boolean
  serviceRequests: ServiceRequest[]
  srCounter: number
  addServiceRequest: (sr: Omit<ServiceRequest, "id" | "srId" | "createdAt" | "updatedAt" | "status">) => void
  updateServiceRequest: (id: string, data: Partial<ServiceRequest>) => void
  getScopedServiceRequests: () => ServiceRequest[]
  getManageableServiceRequests: () => ServiceRequest[]
  notificationCount: number
  playNotificationSound: () => void
}

const CRMContext = createContext<CRMContextType | undefined>(undefined)

export function CRMProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<User | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [dbAvailable, setDbAvailable] = useState<boolean | null>(null)
  const [notificationCount, setNotificationCount] = useState(0)
  const prevLeadCountRef = useRef(0)

  // ----- FALLBACK STATE (used when DB not available) -----
  const [fbUsers, setFbUsers] = useState<User[]>(dummyUsers)
  const [fbLeads, setFbLeads] = useState<Lead[]>(dummyLeads)
  const [fbLeadCounter, setFbLeadCounter] = useState(13)
  const [fbProjects, setFbProjects] = useState<Project[]>(dummyProjects)
  const [fbTasks, setFbTasks] = useState<Task[]>(dummyTasks)
  const [fbPermissions, setFbPermissions] = useState(defaultRolePermissions)
  const [fbAttendance, setFbAttendance] = useState<AttendanceRecord[]>(dummyAttendance)
  const [fbLeaveRequests, setFbLeaveRequests] = useState<LeaveRequest[]>(dummyLeaveRequests)
  const [fbLeaveBalances, setFbLeaveBalances] = useState<LeaveBalance[]>(dummyLeaveBalances)
  const [fbReimbursements, setFbReimbursements] = useState<Reimbursement[]>(dummyReimbursements)
  const [fbDocuments, setFbDocuments] = useState<EmployeeDocument[]>(dummyDocuments)
  const [fbBankDetails, setFbBankDetails] = useState<BankDetails[]>(dummyBankDetails)
  const [fbServiceRequests, setFbServiceRequests] = useState<ServiceRequest[]>(dummyServiceRequests)
  const [fbSrCounter, setFbSrCounter] = useState(3)

  // ----- SWR DATA (used when DB is available) -----
  const shouldFetch = dbAvailable === true && currentUser !== null
  const { data: usersData } = useSWR(shouldFetch ? "/api/users" : null, fetcher, { refreshInterval: 30000 })
  const { data: leadsData } = useSWR(shouldFetch ? "/api/leads" : null, fetcher, { refreshInterval: 15000 })
  const { data: projectsData } = useSWR(shouldFetch ? "/api/projects" : null, fetcher, { refreshInterval: 30000 })
  const { data: tasksData } = useSWR(shouldFetch ? "/api/tasks" : null, fetcher, { refreshInterval: 30000 })
  const { data: permissionsData } = useSWR(shouldFetch ? "/api/permissions" : null, fetcher, { refreshInterval: 60000 })
  const { data: attendanceData } = useSWR(shouldFetch ? "/api/hrms/attendance" : null, fetcher, { refreshInterval: 30000 })
  const { data: leavesData } = useSWR(shouldFetch ? "/api/hrms/leaves" : null, fetcher, { refreshInterval: 30000 })
  const { data: leaveBalancesData } = useSWR(shouldFetch ? "/api/hrms/leave-balances" : null, fetcher, { refreshInterval: 60000 })
  const { data: reimbursementsData } = useSWR(shouldFetch ? "/api/hrms/reimbursements" : null, fetcher, { refreshInterval: 30000 })
  const { data: documentsData } = useSWR(shouldFetch ? "/api/hrms/documents" : null, fetcher, { refreshInterval: 60000 })
  const { data: bankData } = useSWR(shouldFetch ? "/api/hrms/bank-details" : null, fetcher, { refreshInterval: 60000 })
  const { data: srData } = useSWR(shouldFetch ? "/api/service-requests" : null, fetcher, { refreshInterval: 30000 })

  // Resolved data: API data if DB available, fallback state otherwise
  const users: User[] = (dbAvailable && usersData?.users) || fbUsers
  const leads: Lead[] = (dbAvailable && leadsData?.leads) || fbLeads
  const leadCounter: number = (dbAvailable && leadsData?.leadCounter) || fbLeadCounter
  const projects: Project[] = (dbAvailable && projectsData?.projects) || fbProjects
  const tasks: Task[] = (dbAvailable && tasksData?.tasks) || fbTasks
  const allRolePermissions: RolePermission[] = (dbAvailable && permissionsData?.permissions) || fbPermissions
  const attendance: AttendanceRecord[] = (dbAvailable && attendanceData?.attendance) || fbAttendance
  const leaveRequests: LeaveRequest[] = (dbAvailable && leavesData?.leaveRequests) || fbLeaveRequests
  const leaveBalances: LeaveBalance[] = (dbAvailable && leaveBalancesData?.leaveBalances) || fbLeaveBalances
  const reimbursements: Reimbursement[] = (dbAvailable && reimbursementsData?.reimbursements) || fbReimbursements
  const documents: EmployeeDocument[] = (dbAvailable && documentsData?.documents) || fbDocuments
  const bankDetails: BankDetails[] = (dbAvailable && bankData?.bankDetails) || fbBankDetails
  const serviceRequests: ServiceRequest[] = (dbAvailable && srData?.serviceRequests) || fbServiceRequests
  const srCounter: number = fbSrCounter

  // ----- NOTIFICATION SOUND -----
  const playNotificationSound = useCallback(() => {
    try {
      const ctx = new (window.AudioContext || (window as any).webkitAudioContext)()
      const oscillator = ctx.createOscillator()
      const gain = ctx.createGain()
      oscillator.connect(gain)
      gain.connect(ctx.destination)
      oscillator.frequency.value = 880
      oscillator.type = "sine"
      gain.gain.setValueAtTime(0.3, ctx.currentTime)
      gain.gain.exponentialRampToValueAtTime(0.01, ctx.currentTime + 0.5)
      oscillator.start(ctx.currentTime)
      oscillator.stop(ctx.currentTime + 0.5)
    } catch { /* silent fallback */ }
  }, [])

  useEffect(() => {
    if (leads.length > prevLeadCountRef.current && currentUser && prevLeadCountRef.current > 0) {
      setNotificationCount((c) => c + (leads.length - prevLeadCountRef.current))
      playNotificationSound()
    }
    prevLeadCountRef.current = leads.length
  }, [leads.length, currentUser, playNotificationSound])

  // ----- AUTH: Try API first, fallback to local -----
  useEffect(() => {
    const controller = new AbortController()
    const timeout = setTimeout(() => controller.abort(), 3000) // 3s timeout
    async function checkSession() {
      try {
        const res = await fetch("/api/auth/me", { signal: controller.signal })
        clearTimeout(timeout)
        if (res.ok) {
          const data = await res.json()
          if (data.user) {
            setCurrentUser(data.user)
            setDbAvailable(true)
            setIsLoading(false)
            return
          }
        }
        // API responded but no user -- DB is available but not logged in
        if (res.status === 401) {
          setDbAvailable(true)
          setIsLoading(false)
          return
        }
        // API error or 503 -- no DB
        setDbAvailable(false)
        setIsLoading(false)
      } catch {
        clearTimeout(timeout)
        // Network error or timeout -- no DB available, use fallback
        setDbAvailable(false)
        setIsLoading(false)
      }
    }
    checkSession()
    return () => { clearTimeout(timeout); controller.abort() }
  }, [])

  // ----- LOGIN -----
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    if (dbAvailable) {
      try {
        const res = await fetch("/api/auth/login", {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify({ email, password }),
        })
        if (res.status === 503) {
          // DB went down, switch to fallback
          setDbAvailable(false)
          const user = fbUsers.find((u) => u.email === email && u.password === password && u.isActive)
          if (user) { setCurrentUser(user); return true }
          return false
        }
        if (res.ok) {
          const meRes = await fetch("/api/auth/me")
          const meData = await meRes.json()
          if (meData.user) {
            setCurrentUser(meData.user)
            return true
          }
        }
        return false
      } catch {
        // Network error, switch to fallback
        setDbAvailable(false)
        const user = fbUsers.find((u) => u.email === email && u.password === password && u.isActive)
        if (user) { setCurrentUser(user); return true }
        return false
      }
    } else {
      // Fallback: local auth
      const user = fbUsers.find((u) => u.email === email && u.password === password && u.isActive)
      if (user) { setCurrentUser(user); return true }
      return false
    }
  }, [dbAvailable, fbUsers])

  const logout = useCallback(async () => {
    if (dbAvailable) {
      await fetch("/api/auth/logout", { method: "POST" }).catch(() => {})
    }
    setCurrentUser(null)
  }, [dbAvailable])

  // ----- Helper to call API and revalidate -----
  const apiCall = useCallback(async (url: string, method: string, body?: any) => {
    if (!dbAvailable) return null
    try {
      const res = await fetch(url, {
        method,
        headers: { "Content-Type": "application/json" },
        body: body ? JSON.stringify(body) : undefined,
      })
      return res.ok ? await res.json() : null
    } catch {
      return null
    }
  }, [dbAvailable])

  const revalidate = useCallback((...keys: string[]) => {
    keys.forEach((k) => globalMutate(k))
  }, [])

  // ----- HIERARCHY -----
  const getTeamMemberIds = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return users.map((u) => u.id)
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      return [currentUser.id, ...directReports]
    }
    return [currentUser.id]
  }, [currentUser, users])

  const getScopedLeads = useCallback(() => {
    if (!currentUser) return []
    const teamIds = getTeamMemberIds()
    return leads.filter((l) => teamIds.includes(l.assignedTo))
  }, [currentUser, leads, getTeamMemberIds])

  const getScopedTasks = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return tasks
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      const teamIds = [currentUser.id, ...directReports]
      return tasks.filter((t) => teamIds.includes(t.assignedTo))
    }
    return tasks.filter((t) => t.assignedTo === currentUser.id)
  }, [currentUser, tasks, users])

  const getScopedTeamMembers = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return users.filter((u) => u.isActive && u.role !== "viewer")
    if (currentUser.role === "manager") {
      return users.filter((u) => u.isActive && (u.id === currentUser.id || u.managerId === currentUser.id) && u.role !== "viewer")
    }
    return []
  }, [currentUser, users])

  const getAssignableUsers = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return users.filter((u) => u.isActive)
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id && u.isActive)
      return [currentUser, ...directReports]
    }
    return [currentUser]
  }, [currentUser, users])

  const getFieldPermissions = useCallback(() => {
    if (!currentUser) return getFieldEditPermissions("viewer")
    return getFieldEditPermissions(currentUser.role)
  }, [currentUser])

  // ----- PERMISSIONS -----
  const hasPermission = useCallback((category: string, action: string) => {
    if (!currentUser) return false
    const rolePerm = allRolePermissions.find((rp) => rp.role === currentUser.role)
    if (!rolePerm) return false
    const cat = rolePerm.permissions[category as keyof typeof rolePerm.permissions]
    if (!cat) return false
    return (cat as Record<string, boolean>)[action] ?? false
  }, [currentUser, allRolePermissions])

  const getRolePermissions = useCallback((role: UserRole) => allRolePermissions.find((rp) => rp.role === role), [allRolePermissions])
  const updateRolePermissions = useCallback(async (role: UserRole, newPerms: RolePermission["permissions"]) => {
    if (dbAvailable) {
      await apiCall(`/api/permissions/${role}`, "PATCH", { permissions: newPerms })
      revalidate("/api/permissions")
    } else {
      setFbPermissions((prev) => prev.map((rp) => (rp.role === role ? { ...rp, permissions: newPerms } : rp)))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- USER CRUD -----
  const addUser = useCallback(async (user: Omit<User, "id" | "createdAt">) => {
    if (dbAvailable) {
      await apiCall("/api/users", "POST", user)
      revalidate("/api/users", "/api/hrms/leave-balances")
    } else {
      const newUser: User = { ...user, id: `u${Date.now()}`, createdAt: new Date().toISOString().split("T")[0] }
      setFbUsers((prev) => [...prev, newUser])
      setFbLeaveBalances((prev) => [...prev, { userId: newUser.id, casual: { total: 12, used: 0 }, sick: { total: 6, used: 0 }, earned: { total: 15, used: 0 }, comp_off: { total: 0, used: 0 } }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const updateUser = useCallback(async (id: string, data: Partial<User>) => {
    if (dbAvailable) {
      await apiCall(`/api/users/${id}`, "PATCH", data)
      revalidate("/api/users")
    } else {
      setFbUsers((prev) => prev.map((u) => (u.id === id ? { ...u, ...data } : u)))
    }
  }, [dbAvailable, apiCall, revalidate])

  const deleteUser = useCallback(async (id: string) => {
    if (dbAvailable) {
      await apiCall(`/api/users/${id}`, "DELETE")
      revalidate("/api/users")
    } else {
      setFbUsers((prev) => prev.filter((u) => u.id !== id))
    }
  }, [dbAvailable, apiCall, revalidate])

  const getUserById = useCallback((id: string) => users.find((u) => u.id === id), [users])

  // ----- LEAD CRUD -----
  const addLead = useCallback(async (lead: Omit<Lead, "id" | "leadId" | "createdAt" | "updatedAt" | "activities">) => {
    if (dbAvailable) {
      await apiCall("/api/leads", "POST", lead)
      revalidate("/api/leads")
    } else {
      const now = getNowISO()
      const newLeadId = `HA${String(fbLeadCounter).padStart(5, "0")}`
      const newLead: Lead = { ...lead, id: `l${Date.now()}`, leadId: newLeadId, createdAt: now, updatedAt: now, activities: [{ id: `a${Date.now()}`, type: "note", description: "Lead created", createdAt: now, createdBy: currentUser?.id || lead.assignedTo }] }
      setFbLeads((prev) => [...prev, newLead])
      setFbLeadCounter((c) => c + 1)
    }
    playNotificationSound()
  }, [dbAvailable, apiCall, revalidate, fbLeadCounter, currentUser, playNotificationSound])

  const updateLead = useCallback(async (id: string, data: Partial<Lead>) => {
    if (dbAvailable) {
      await apiCall(`/api/leads/${id}`, "PATCH", data)
      revalidate("/api/leads")
    } else {
      setFbLeads((prev) => prev.map((l) => l.id === id ? { ...l, ...data, updatedAt: getNowISO() } : l))
    }
  }, [dbAvailable, apiCall, revalidate])

  const deleteLead = useCallback(async (id: string) => {
    if (dbAvailable) {
      await apiCall(`/api/leads/${id}`, "DELETE")
      revalidate("/api/leads")
    } else {
      setFbLeads((prev) => prev.filter((l) => l.id !== id))
    }
  }, [dbAvailable, apiCall, revalidate])

  const addLeadActivity = useCallback(async (leadId: string, activity: Omit<Activity, "id" | "createdAt">) => {
    if (dbAvailable) {
      await apiCall(`/api/leads/${leadId}/activities`, "POST", activity)
      revalidate("/api/leads")
    } else {
      const now = getNowISO()
      setFbLeads((prev) => prev.map((l) => l.id === leadId ? { ...l, updatedAt: now, activities: [{ ...activity, id: `a${Date.now()}`, createdAt: now }, ...l.activities] } : l))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- PROJECT CRUD -----
  const addProject = useCallback(async (project: Omit<Project, "id" | "createdAt">) => {
    if (dbAvailable) {
      await apiCall("/api/projects", "POST", project)
      revalidate("/api/projects")
    } else {
      setFbProjects((prev) => [...prev, { ...project, id: `p${Date.now()}`, createdAt: new Date().toISOString().split("T")[0] }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const updateProject = useCallback(async (id: string, data: Partial<Project>) => {
    if (dbAvailable) {
      await apiCall(`/api/projects/${id}`, "PATCH", data)
      revalidate("/api/projects")
    } else {
      setFbProjects((prev) => prev.map((p) => (p.id === id ? { ...p, ...data } : p)))
    }
  }, [dbAvailable, apiCall, revalidate])

  const deleteProject = useCallback(async (id: string) => {
    if (dbAvailable) {
      await apiCall(`/api/projects/${id}`, "DELETE")
      revalidate("/api/projects")
    } else {
      setFbProjects((prev) => prev.filter((p) => p.id !== id))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- TASK CRUD -----
  const addTask = useCallback(async (task: Omit<Task, "id" | "createdAt">) => {
    if (dbAvailable) {
      await apiCall("/api/tasks", "POST", task)
      revalidate("/api/tasks")
    } else {
      setFbTasks((prev) => [...prev, { ...task, id: `t${Date.now()}`, createdAt: new Date().toISOString().split("T")[0] }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const updateTask = useCallback(async (id: string, data: Partial<Task>) => {
    if (dbAvailable) {
      await apiCall(`/api/tasks/${id}`, "PATCH", data)
      revalidate("/api/tasks")
    } else {
      setFbTasks((prev) => prev.map((t) => (t.id === id ? { ...t, ...data } : t)))
    }
  }, [dbAvailable, apiCall, revalidate])

  const deleteTask = useCallback(async (id: string) => {
    if (dbAvailable) {
      await apiCall(`/api/tasks/${id}`, "DELETE")
      revalidate("/api/tasks")
    } else {
      setFbTasks((prev) => prev.filter((t) => t.id !== id))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- HRMS: ATTENDANCE -----
  const markLogin = useCallback(async (userId: string) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/attendance/login", "POST", { userId })
      revalidate("/api/hrms/attendance")
    } else {
      const today = new Date().toISOString().split("T")[0]
      const now = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })
      const existing = fbAttendance.find((a) => a.userId === userId && a.date === today)
      if (existing) {
        setFbAttendance((prev) => prev.map((a) => (a.id === existing.id ? { ...a, loginTime: now, status: "present" } : a)))
      } else {
        setFbAttendance((prev) => [...prev, { id: `att${Date.now()}`, userId, date: today, loginTime: now, logoutTime: null, totalHours: "-", status: "present" }])
      }
    }
  }, [dbAvailable, apiCall, revalidate, fbAttendance])

  const markLogout = useCallback(async (userId: string) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/attendance/logout", "POST", { userId })
      revalidate("/api/hrms/attendance")
    } else {
      const today = new Date().toISOString().split("T")[0]
      const now = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })
      setFbAttendance((prev) => prev.map((a) => {
        if (a.userId === userId && a.date === today && a.loginTime) {
          const loginParts = a.loginTime.split(":")
          const logoutParts = now.split(":")
          const loginMin = parseInt(loginParts[0]) * 60 + parseInt(loginParts[1])
          const logoutMin = parseInt(logoutParts[0]) * 60 + parseInt(logoutParts[1])
          const diff = Math.max(logoutMin - loginMin, 0)
          const hours = Math.floor(diff / 60)
          const mins = diff % 60
          const totalHoursStr = `${hours}h ${mins}m`
          const totalMinutes = hours * 60 + mins
          const status = totalMinutes >= 510 ? "present" : totalMinutes >= 270 ? "half_day" : "absent"
          return { ...a, logoutTime: now, totalHours: totalHoursStr, status: status as any }
        }
        return a
      }))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- HRMS: LEAVES -----
  const addLeaveRequest = useCallback(async (req: Omit<LeaveRequest, "id" | "appliedOn" | "status">) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/leaves", "POST", req)
      revalidate("/api/hrms/leaves")
    } else {
      setFbLeaveRequests((prev) => [...prev, { ...req, id: `lv${Date.now()}`, appliedOn: new Date().toISOString().split("T")[0], status: "pending" }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const updateLeaveRequest = useCallback(async (id: string, data: Partial<LeaveRequest>) => {
    if (dbAvailable) {
      await apiCall(`/api/hrms/leaves/${id}`, "PATCH", data)
      revalidate("/api/hrms/leaves")
    } else {
      setFbLeaveRequests((prev) => prev.map((lr) => (lr.id === id ? { ...lr, ...data } : lr)))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- HRMS: REIMBURSEMENTS -----
  const addReimbursement = useCallback(async (req: Omit<Reimbursement, "id" | "appliedOn" | "status">) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/reimbursements", "POST", req)
      revalidate("/api/hrms/reimbursements")
    } else {
      setFbReimbursements((prev) => [...prev, { ...req, id: `r${Date.now()}`, appliedOn: new Date().toISOString().split("T")[0], status: "pending" }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const updateReimbursement = useCallback(async (id: string, data: Partial<Reimbursement>) => {
    if (dbAvailable) {
      await apiCall(`/api/hrms/reimbursements/${id}`, "PATCH", data)
      revalidate("/api/hrms/reimbursements")
    } else {
      setFbReimbursements((prev) => prev.map((r) => (r.id === id ? { ...r, ...data } : r)))
    }
  }, [dbAvailable, apiCall, revalidate])

  // ----- SCOPED HRMS DATA -----
  const getScopedAttendance = useCallback(() => {
    if (!currentUser) return []; const teamIds = getTeamMemberIds(); return attendance.filter((a) => teamIds.includes(a.userId))
  }, [currentUser, attendance, getTeamMemberIds])

  const getScopedLeaveRequests = useCallback(() => {
    if (!currentUser) return []; const teamIds = getTeamMemberIds(); return leaveRequests.filter((lr) => teamIds.includes(lr.userId))
  }, [currentUser, leaveRequests, getTeamMemberIds])

  const getScopedReimbursements = useCallback(() => {
    if (!currentUser) return []; const teamIds = getTeamMemberIds(); return reimbursements.filter((r) => teamIds.includes(r.userId))
  }, [currentUser, reimbursements, getTeamMemberIds])

  const getApprovableLeaveRequests = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return leaveRequests.filter((lr) => lr.userId !== currentUser.id && lr.status === "pending")
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      return leaveRequests.filter((lr) => directReports.includes(lr.userId) && lr.status === "pending")
    }
    return []
  }, [currentUser, leaveRequests, users])

  const getApprovableReimbursements = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return reimbursements.filter((r) => r.userId !== currentUser.id && r.status === "pending")
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      return reimbursements.filter((r) => directReports.includes(r.userId) && r.status === "pending")
    }
    return []
  }, [currentUser, reimbursements, users])

  // ----- DOCUMENTS -----
  const addDocument = useCallback(async (doc: Omit<EmployeeDocument, "id" | "uploadedAt">) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/documents", "POST", doc)
      revalidate("/api/hrms/documents")
    } else {
      setFbDocuments((prev) => [...prev, { ...doc, id: `doc${Date.now()}`, uploadedAt: new Date().toISOString().split("T")[0] }])
    }
  }, [dbAvailable, apiCall, revalidate])

  const deleteDocument = useCallback(async (id: string) => {
    if (dbAvailable) {
      await apiCall(`/api/hrms/documents/${id}`, "DELETE")
      revalidate("/api/hrms/documents")
    } else {
      setFbDocuments((prev) => prev.filter((d) => d.id !== id))
    }
  }, [dbAvailable, apiCall, revalidate])

  const canEditDocument = useCallback((docUserId: string) => {
    if (!currentUser) return false
    return currentUser.role === "admin"
  }, [currentUser])

  // ----- BANK DETAILS -----
  const updateBankDetailsHandler = useCallback(async (userId: string, data: BankDetails) => {
    if (dbAvailable) {
      await apiCall("/api/hrms/bank-details", "PUT", data)
      revalidate("/api/hrms/bank-details")
    } else {
      setFbBankDetails((prev) => {
        const existing = prev.find((b) => b.userId === userId)
        if (existing) return prev.map((b) => (b.userId === userId ? data : b))
        return [...prev, data]
      })
    }
  }, [dbAvailable, apiCall, revalidate])

  const canEditBankDetails = useCallback((targetUserId: string) => {
    if (!currentUser) return false
    if (currentUser.role === "admin") return true
    if (currentUser.id === targetUserId) {
      const existing = bankDetails.find((b) => b.userId === targetUserId)
      return !existing
    }
    return false
  }, [currentUser, bankDetails])

  // ----- SERVICE REQUESTS -----
  const addServiceRequest = useCallback(async (sr: Omit<ServiceRequest, "id" | "srId" | "createdAt" | "updatedAt" | "status">) => {
    if (dbAvailable) {
      await apiCall("/api/service-requests", "POST", sr)
      revalidate("/api/service-requests")
    } else {
      const now = getNowISO()
      const newSrId = `SR-${String(fbSrCounter).padStart(5, "0")}`
      setFbServiceRequests((prev) => [...prev, { ...sr, id: `sr${Date.now()}`, srId: newSrId, createdAt: now, updatedAt: now, status: "open" }])
      setFbSrCounter((c) => c + 1)
    }
  }, [dbAvailable, apiCall, revalidate, fbSrCounter])

  const updateServiceRequest = useCallback(async (id: string, data: Partial<ServiceRequest>) => {
    if (dbAvailable) {
      await apiCall(`/api/service-requests/${id}`, "PATCH", data)
      revalidate("/api/service-requests")
    } else {
      setFbServiceRequests((prev) => prev.map((sr) => (sr.id === id ? { ...sr, ...data, updatedAt: getNowISO() } : sr)))
    }
  }, [dbAvailable, apiCall, revalidate])

  const getScopedServiceRequests = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return serviceRequests
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      const teamIds = [currentUser.id, ...directReports]
      return serviceRequests.filter((sr) => teamIds.includes(sr.userId))
    }
    return serviceRequests.filter((sr) => sr.userId === currentUser.id)
  }, [currentUser, serviceRequests, users])

  const getManageableServiceRequests = useCallback(() => {
    if (!currentUser) return []
    if (currentUser.role === "admin") return serviceRequests.filter((sr) => sr.status === "open" || sr.status === "in_progress")
    if (currentUser.role === "manager") {
      const directReports = users.filter((u) => u.managerId === currentUser.id).map((u) => u.id)
      return serviceRequests.filter((sr) => directReports.includes(sr.userId) && (sr.status === "open" || sr.status === "in_progress"))
    }
    return []
  }, [currentUser, serviceRequests, users])

  return (
    <CRMContext.Provider value={{
      currentUser, login: login as any, logout, isAuthenticated: !!currentUser, isLoading,
      users, addUser: addUser as any, updateUser: updateUser as any, deleteUser: deleteUser as any, getUserById,
      getTeamMemberIds, getScopedLeads, getScopedTasks, getScopedTeamMembers, getFieldPermissions, getAssignableUsers,
      leads, leadCounter, addLead: addLead as any, updateLead: updateLead as any, deleteLead: deleteLead as any, addLeadActivity: addLeadActivity as any,
      projects, addProject: addProject as any, updateProject: updateProject as any, deleteProject: deleteProject as any,
      tasks, addTask: addTask as any, updateTask: updateTask as any, deleteTask: deleteTask as any,
      hasPermission, getRolePermissions, allRolePermissions, updateRolePermissions: updateRolePermissions as any,
      attendance, markLogin: markLogin as any, markLogout: markLogout as any,
      leaveRequests, addLeaveRequest: addLeaveRequest as any, updateLeaveRequest: updateLeaveRequest as any, leaveBalances,
      reimbursements, addReimbursement: addReimbursement as any, updateReimbursement: updateReimbursement as any,
      getScopedAttendance, getScopedLeaveRequests, getScopedReimbursements,
      getApprovableLeaveRequests, getApprovableReimbursements,
      documents, addDocument: addDocument as any, deleteDocument: deleteDocument as any, canEditDocument,
      bankDetails, updateBankDetails: updateBankDetailsHandler as any, canEditBankDetails,
      serviceRequests, srCounter, addServiceRequest: addServiceRequest as any, updateServiceRequest: updateServiceRequest as any,
      getScopedServiceRequests, getManageableServiceRequests,
      notificationCount, playNotificationSound,
    }}>
      {children}
    </CRMContext.Provider>
  )
}

export function useCRM() {
  const context = useContext(CRMContext)
  if (!context) throw new Error("useCRM must be used within a CRMProvider")
  return context
}
