import bcrypt from "bcryptjs"
import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"

const JWT_SECRET = new TextEncoder().encode(process.env.JWT_SECRET || "orbit-crm-secret-key-change-in-production-2026")
const COOKIE_NAME = "orbit_session"

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 12)
}

export async function verifyPassword(password: string, hash: string): Promise<boolean> {
  return bcrypt.compare(password, hash)
}

export async function createSession(userId: string): Promise<string> {
  const token = await new SignJWT({ userId })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime("7d")
    .sign(JWT_SECRET)

  const cookieStore = await cookies()
  cookieStore.set(COOKIE_NAME, token, {
    httpOnly: true,
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
    maxAge: 60 * 60 * 24 * 7, // 7 days
    path: "/",
  })

  return token
}

export async function getSession(): Promise<{ userId: string } | null> {
  try {
    const cookieStore = await cookies()
    const token = cookieStore.get(COOKIE_NAME)?.value
    if (!token) return null

    const { payload } = await jwtVerify(token, JWT_SECRET)
    return { userId: payload.userId as string }
  } catch {
    return null
  }
}

export async function getCurrentUser() {
  const session = await getSession()
  if (!session) return null

  const { queryOne } = await import("./db")
  const user = await queryOne(
    `SELECT id, name, email, role, phone, department, avatar, is_active, created_at, last_login, manager_id, week_offs
     FROM users WHERE id = ? AND is_active = 1`,
    [session.userId]
  )

  if (!user) return null

  return {
    id: user.id,
    name: user.name,
    email: user.email,
    role: user.role,
    phone: user.phone,
    department: user.department,
    avatar: user.avatar,
    isActive: !!user.is_active,
    createdAt: user.created_at,
    lastLogin: user.last_login,
    managerId: user.manager_id,
    weekOffs: user.week_offs ? JSON.parse(user.week_offs) : ["sunday"],
  }
}

export async function destroySession() {
  const cookieStore = await cookies()
  cookieStore.set(COOKIE_NAME, "", { maxAge: 0, path: "/" })
}
