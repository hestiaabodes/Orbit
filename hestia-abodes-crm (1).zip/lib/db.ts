import mysql from "mysql2/promise"

// Lazy pool initialization -- only connect when first query runs
let pool: mysql.Pool | null = null

function getPool(): mysql.Pool {
  if (!pool) {
    const dbUrl = process.env.DATABASE_URL
    if (dbUrl) {
      pool = mysql.createPool({
        uri: dbUrl,
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        connectTimeout: 5000,
      })
    } else {
      pool = mysql.createPool({
        host: process.env.DB_HOST || "localhost",
        port: parseInt(process.env.DB_PORT || "3306"),
        user: process.env.DB_USER || "orbit_user",
        password: process.env.DB_PASSWORD || "orbit_pass",
        database: process.env.DB_NAME || "orbit_crm",
        waitForConnections: true,
        connectionLimit: 10,
        queueLimit: 0,
        connectTimeout: 5000,
      })
    }
  }
  return pool
}

export async function query<T = any>(sql: string, params?: any[]): Promise<T[]> {
  const [rows] = await getPool().execute(sql, params)
  return rows as T[]
}

export async function queryOne<T = any>(sql: string, params?: any[]): Promise<T | null> {
  const rows = await query<T>(sql, params)
  return rows[0] || null
}

export async function execute(sql: string, params?: any[]): Promise<{ insertId: number; affectedRows: number }> {
  const [result] = await getPool().execute(sql, params) as any
  return { insertId: result.insertId, affectedRows: result.affectedRows }
}

export default { query, queryOne, execute }
