// Server-side input validation

export function sanitize(str: string | undefined | null): string {
  if (!str) return ""
  return str.trim().replace(/[<>]/g, "")
}

export function isValidEmail(email: string): boolean {
  if (!email) return true // optional
  return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)
}

export function isValidPhone(phone: string): boolean {
  if (!phone) return false
  // Allow +91 prefix, spaces, hyphens, 10-15 digits
  const cleaned = phone.replace(/[\s\-()]/g, "")
  return /^\+?\d{10,15}$/.test(cleaned)
}

export function isValidName(name: string): boolean {
  return name.length >= 2 && name.length <= 255
}

export interface ValidationError {
  field: string
  message: string
}

export function validateLead(data: any): ValidationError[] {
  const errors: ValidationError[] = []
  if (!data.name || !isValidName(data.name)) errors.push({ field: "name", message: "Name is required (2-255 characters)" })
  if (!data.phone || !isValidPhone(data.phone)) errors.push({ field: "phone", message: "Valid phone number is required" })
  if (data.email && !isValidEmail(data.email)) errors.push({ field: "email", message: "Invalid email format" })
  return errors
}

export function validateUser(data: any): ValidationError[] {
  const errors: ValidationError[] = []
  if (!data.name || !isValidName(data.name)) errors.push({ field: "name", message: "Name is required (2-255 characters)" })
  if (!data.email || !isValidEmail(data.email)) errors.push({ field: "email", message: "Valid email is required" })
  const validRoles = ["admin", "manager", "sales_executive", "presales_executive", "viewer"]
  if (!data.role || !validRoles.includes(data.role)) errors.push({ field: "role", message: "Valid role is required" })
  return errors
}
