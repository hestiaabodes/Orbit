-- ORBIT CRM Seed Data for MySQL
-- All passwords are bcrypt-hashed (12 rounds)
-- For production, generate your own hashes using: node -e "const b=require('bcryptjs');b.hash('yourpassword',12).then(h=>console.log(h))"
-- Default passwords: admin123, priya123, amit123, sneha123, vikram123, viewer123, rohit123

-- Users (inserting without manager_id first, then updating)
INSERT INTO users (id, name, email, password_hash, role, phone, department, is_active, created_at, last_login, week_offs) VALUES
('u1', 'Rajesh Kumar', 'admin@hestiaabodes.in', '$2b$12$M2Tf9bGIuNftQRhajERnQO6inZZ0s/xdwztnvo4ujxgiG0zfbk76G', 'admin', '+91 98765 43210', 'Management', 1, '2025-01-15', '2026-02-13', '["sunday"]'),
('u2', 'Priya Sharma', 'priya@hestiaabodes.in', '$2b$12$/o5UR4UoTrVdeABBIlccJu/uO1l.a9yRMDdfdrHYUGm9VQQNGNNh6', 'manager', '+91 98765 43211', 'Sales', 1, '2025-02-01', '2026-02-12', '["sunday"]'),
('u3', 'Amit Patel', 'amit@hestiaabodes.in', '$2b$12$I5QwsfFMjmfBORwTOiU/0.yB4ETtMNDdDrQ8dYJWZ4SWbAJPdPEdW', 'sales_executive', '+91 98765 43212', 'Sales', 1, '2025-03-10', '2026-02-13', '["sunday"]'),
('u4', 'Sneha Reddy', 'sneha@hestiaabodes.in', '$2b$12$SZBfN4B.8xXZFmKVO6bOl.jJVpN2BPlr24M6H1E/GkZa8h.twKdoS', 'sales_executive', '+91 98765 43213', 'Sales', 1, '2025-03-15', '2026-02-11', '["sunday"]'),
('u5', 'Vikram Singh', 'vikram@hestiaabodes.in', '$2b$12$/MhEaw6jvwsLOlFuzAZOJu6bThglgNtoOn/PsOX3wtT5R053OC3DC', 'presales_executive', '+91 98765 43214', 'Pre-Sales', 1, '2025-04-01', '2026-02-10', '["saturday","sunday"]'),
('u6', 'Neha Gupta', 'viewer@hestiaabodes.in', '$2b$12$3zWDbc0kh93VwpIqH.iL9O.xLMLixljLg6KRc9PEImFPiK/3DlIJC', 'viewer', '+91 98765 43215', 'Marketing', 0, '2025-05-20', '2026-01-05', '["saturday","sunday"]'),
('u7', 'Rohit Mehra', 'rohit@hestiaabodes.in', '$2b$12$tCrLU.w8cmpRyLszel6iR.GrTGIWvL0bE1trAHQaQfn10FkAZiOEm', 'sales_executive', '+91 98765 43216', 'Sales', 1, '2025-06-10', '2026-02-14', '["sunday"]');

-- Set manager relationships
UPDATE users SET manager_id = 'u1' WHERE id IN ('u2', 'u6');
UPDATE users SET manager_id = 'u2' WHERE id IN ('u3', 'u4', 'u5', 'u7');

-- Projects
INSERT INTO projects (id, name, location, type, status, total_units, available_units, price_range, description, amenities, created_at) VALUES
('p1', 'Hestia Grand Residences', 'Whitefield, Bangalore', 'residential', 'ongoing', 120, 45, '65L - 1.2Cr', 'Premium 2 & 3 BHK apartments.', '["Swimming Pool","Gym","Clubhouse","Garden","Children''s Play Area","24/7 Security"]', '2025-01-01'),
('p2', 'Hestia Business Park', 'Bandra Kurla Complex, Mumbai', 'commercial', 'ongoing', 80, 32, '1.5Cr - 5Cr', 'Premium Grade A office spaces.', '["Parking","Food Court","Conference Room","High-Speed Elevator","Power Backup"]', '2025-02-15'),
('p3', 'Hestia Valley Villas', 'Lonavala, Maharashtra', 'villa', 'upcoming', 40, 40, '2Cr - 4.5Cr', 'Luxury villas in Sahyadri mountains.', '["Private Pool","Garden","Smart Home","Helipad Access","Spa","Golf Course"]', '2025-06-01'),
('p4', 'Hestia Green Plots', 'Devanahalli, Bangalore', 'plot', 'ongoing', 200, 87, '30L - 80L', 'RERA approved residential plots.', '["Gated Community","Road Connectivity","Water Supply","Electricity","Parks"]', '2025-03-20'),
('p5', 'Hestia Skyline Towers', 'Gachibowli, Hyderabad', 'residential', 'completed', 200, 12, '55L - 95L', 'Completed premium residential project.', '["Swimming Pool","Gym","Tennis Court","Jogging Track","Multipurpose Hall"]', '2024-01-01');

-- Leads
INSERT INTO leads (id, lead_id, name, email, phone, alternate_phone, source, status, sub_status, assigned_to, project_interest, budget, notes, created_at, updated_at, last_contacted_at, next_follow_up) VALUES
('l1', 'HA00001', 'Arjun Mehta', 'arjun.mehta@gmail.com', '+91 99887 76543', '+91 98765 00001', 'Facebook', 'new', 'hot', 'u3', 'p1', '80L - 1Cr', 'Interested in 3BHK, wants south-facing.', '2026-02-12 09:30:00', '2026-02-12 09:30:00', NULL, '2026-02-14'),
('l2', 'HA00002', 'Kavita Joshi', 'kavita.j@yahoo.com', '+91 88776 65432', NULL, 'Website', 'contact_established', 'warm', 'u4', 'p1', '65L - 80L', 'Looking for 2BHK for investment.', '2026-02-10 11:15:00', '2026-02-11 14:20:00', '2026-02-11 14:20:00', '2026-02-15'),
('l3', 'HA00003', 'Ravi Shankar', 'ravi.shankar@outlook.com', '+91 77665 54321', '+91 77665 99999', '99acres', 'details_shared', 'hot', 'u3', 'p2', '2Cr - 3Cr', 'Corporate client looking for office space.', '2026-02-05 10:00:00', '2026-02-12 16:45:00', '2026-02-12 16:45:00', '2026-02-13'),
('l4', 'HA00004', 'Deepika Nair', 'deepika.nair@gmail.com', '+91 66554 43210', NULL, 'MagicBricks', 'site_visit_done', 'hot', 'u5', 'p3', '3Cr - 4Cr', 'Interested in premium villa with pool.', '2026-01-20 15:30:00', '2026-02-10 11:00:00', '2026-02-10 11:00:00', '2026-02-14'),
('l5', 'HA00005', 'Suresh Prabhu', 'suresh.p@gmail.com', '+91 55443 32109', NULL, 'Referral', 'site_visit_scheduled', 'follow_up_scheduled', 'u4', 'p5', '70L - 90L', 'Referred by existing customer.', '2026-02-01 08:45:00', '2026-02-09 17:00:00', '2026-02-09 17:00:00', '2026-02-13'),
('l6', 'HA00006', 'Meera Kapoor', 'meera.k@hotmail.com', '+91 44332 21098', NULL, 'Google Ads', 'won', 'booked', 'u3', 'p5', '85L', 'Booked 3BHK Unit #507.', '2025-12-15 12:00:00', '2026-02-05 10:30:00', '2026-02-05 10:30:00', NULL),
('l7', 'HA00007', 'Anil Deshmukh', 'anil.d@gmail.com', '+91 33221 10987', NULL, 'Housing.com', 'lost', 'booked_with_others', 'u5', 'p4', '40L - 50L', 'Went with competitor.', '2025-11-01 09:00:00', '2026-01-15 14:00:00', '2026-01-15 14:00:00', NULL),
('l8', 'HA00008', 'Pooja Verma', 'pooja.v@gmail.com', '+91 22110 09876', NULL, 'Walk-in', 'contact_established', 'warm', 'u3', 'p4', '35L - 55L', 'Walk-in customer.', '2026-02-08 13:00:00', '2026-02-09 10:00:00', '2026-02-09 10:00:00', '2026-02-16'),
('l9', 'HA00009', 'Rahul Dravid', 'rahul.d@yahoo.com', '+91 11009 98765', NULL, 'Instagram', 'new', 'cold', 'u4', 'p1', '60L - 75L', 'Instagram DM inquiry.', '2026-02-13 07:30:00', '2026-02-13 07:30:00', NULL, '2026-02-15'),
('l10', 'HA00010', 'Ananya Iyer', 'ananya.i@gmail.com', '+91 99001 12345', NULL, 'Facebook', 'details_shared', 'warm', 'u5', 'p3', '2.5Cr - 3.5Cr', 'NRI client in Dubai.', '2026-01-25 16:00:00', '2026-02-08 11:45:00', '2026-02-08 11:45:00', '2026-02-15'),
('l11', 'HA00011', 'Vikash Yadav', 'vikash.y@gmail.com', '+91 88990 01234', NULL, 'OLX', 'new', 'asked_to_call_later', 'u3', 'p4', '45L - 60L', 'First-time buyer.', '2026-02-11 14:30:00', '2026-02-11 14:30:00', NULL, '2026-02-14'),
('l12', 'HA00012', 'Sanjay Malhotra', 'sanjay.m@corp.com', '+91 77880 09876', NULL, 'Google Ads', 'site_visit_scheduled', 'warm', 'u4', 'p2', '2Cr - 4Cr', 'Looking for large office space.', '2026-02-07 10:15:00', '2026-02-11 09:30:00', '2026-02-11 09:30:00', '2026-02-16');

-- Lead Activities
INSERT INTO lead_activities (id, lead_id, type, description, created_at, created_by) VALUES
('a1', 'l1', 'note', 'Lead captured from Facebook campaign', '2026-02-12 09:30:00', 'u3'),
('a2', 'l2', 'call', 'Initial call - discussed project details', '2026-02-11 14:20:00', 'u4'),
('a3', 'l2', 'note', 'Lead from website inquiry', '2026-02-10 11:15:00', 'u4'),
('a4', 'l3', 'meeting', 'Site visit completed. Client impressed', '2026-02-12 16:45:00', 'u3'),
('a5', 'l3', 'email', 'Sent brochure and floor plans', '2026-02-08 09:00:00', 'u3'),
('a7', 'l4', 'meeting', 'Discussed pricing and payment plans', '2026-02-10 11:00:00', 'u5'),
('a8', 'l4', 'site_visit', 'Site visit completed, interested in Plot 12', '2026-02-02 10:30:00', 'u5'),
('a11', 'l5', 'site_visit', 'Visited sample flat', '2026-02-09 17:00:00', 'u4'),
('a13', 'l6', 'status_change', 'Lead converted - Booked Unit #507', '2026-02-05 10:30:00', 'u3'),
('a16', 'l7', 'status_change', 'Marked as lost - chose competitor', '2026-01-15 14:00:00', 'u5'),
('a18', 'l8', 'call', 'Discussed available plots', '2026-02-09 10:00:00', 'u3'),
('a20', 'l9', 'note', 'Instagram inquiry', '2026-02-13 07:30:00', 'u4'),
('a21', 'l10', 'call', 'Video call - discussed villa options', '2026-02-08 11:45:00', 'u5'),
('a23', 'l11', 'note', 'OLX lead captured', '2026-02-11 14:30:00', 'u3'),
('a24', 'l12', 'call', 'Confirmed site visit for next week', '2026-02-11 09:30:00', 'u4');

-- Tasks
INSERT INTO tasks (id, title, description, assigned_to, assigned_by, priority, status, due_date, lead_id, created_at) VALUES
('t1', 'Follow up with Arjun Mehta', 'Call regarding 3BHK preferences', 'u3', 'u2', 'high', 'pending', '2026-02-14', 'l1', '2026-02-12'),
('t2', 'Send brochure to Kavita', 'Email Hestia Grand brochure', 'u4', 'u2', 'medium', 'in_progress', '2026-02-13', 'l2', '2026-02-11'),
('t3', 'Schedule site visit for Sanjay', 'Coordinate with project team', 'u4', 'u2', 'high', 'pending', '2026-02-15', 'l12', '2026-02-11'),
('t4', 'Update pricing sheet', 'Incorporate new pricing from finance', 'u3', 'u1', 'urgent', 'pending', '2026-02-12', NULL, '2026-02-10'),
('t5', 'Weekly team report', 'Compile weekly lead conversion report', 'u2', 'u1', 'medium', 'completed', '2026-02-10', NULL, '2026-02-08'),
('t6', 'Negotiate pricing for Deepika', 'Prepare pricing proposal for villa', 'u5', 'u2', 'high', 'in_progress', '2026-02-14', 'l4', '2026-02-10');

-- Role Permissions
INSERT INTO role_permissions (role, permissions) VALUES
('admin', '{"dashboard":{"view":true},"leads":{"view":true,"create":true,"edit":true,"delete":true,"assign":true,"export":true},"projects":{"view":true,"create":true,"edit":true,"delete":true},"tasks":{"view":true,"create":true,"edit":true,"delete":true,"assign":true},"team":{"view":true,"manage":true},"reports":{"view":true,"export":true},"admin":{"access":true,"manageUsers":true,"manageRoles":true,"manageSettings":true},"hrms":{"view":true,"manage":true,"approve":true},"helpdesk":{"view":true,"create":true,"manage":true}}'),
('manager', '{"dashboard":{"view":true},"leads":{"view":true,"create":true,"edit":true,"delete":false,"assign":true,"export":true},"projects":{"view":true,"create":true,"edit":true,"delete":false},"tasks":{"view":true,"create":true,"edit":true,"delete":false,"assign":true},"team":{"view":true,"manage":false},"reports":{"view":true,"export":true},"admin":{"access":false,"manageUsers":false,"manageRoles":false,"manageSettings":false},"hrms":{"view":true,"manage":false,"approve":true},"helpdesk":{"view":true,"create":true,"manage":true}}'),
('sales_executive', '{"dashboard":{"view":true},"leads":{"view":true,"create":true,"edit":true,"delete":false,"assign":false,"export":false},"projects":{"view":true,"create":false,"edit":false,"delete":false},"tasks":{"view":true,"create":true,"edit":true,"delete":false,"assign":false},"team":{"view":false,"manage":false},"reports":{"view":true,"export":false},"admin":{"access":false,"manageUsers":false,"manageRoles":false,"manageSettings":false},"hrms":{"view":true,"manage":false,"approve":false},"helpdesk":{"view":true,"create":true,"manage":false}}'),
('presales_executive', '{"dashboard":{"view":true},"leads":{"view":true,"create":true,"edit":true,"delete":false,"assign":false,"export":false},"projects":{"view":true,"create":false,"edit":false,"delete":false},"tasks":{"view":true,"create":true,"edit":true,"delete":false,"assign":false},"team":{"view":false,"manage":false},"reports":{"view":true,"export":false},"admin":{"access":false,"manageUsers":false,"manageRoles":false,"manageSettings":false},"hrms":{"view":true,"manage":false,"approve":false},"helpdesk":{"view":true,"create":true,"manage":false}}'),
('viewer', '{"dashboard":{"view":true},"leads":{"view":true,"create":false,"edit":false,"delete":false,"assign":false,"export":false},"projects":{"view":true,"create":false,"edit":false,"delete":false},"tasks":{"view":true,"create":false,"edit":false,"delete":false,"assign":false},"team":{"view":false,"manage":false},"reports":{"view":true,"export":false},"admin":{"access":false,"manageUsers":false,"manageRoles":false,"manageSettings":false},"hrms":{"view":true,"manage":false,"approve":false},"helpdesk":{"view":true,"create":true,"manage":false}}');

-- Attendance Records
INSERT INTO attendance_records (id, user_id, date, login_time, logout_time, total_hours, status) VALUES
('att1', 'u3', '2026-02-13', '09:15', '18:45', '9h 30m', 'present'),
('att2', 'u4', '2026-02-13', '09:30', '17:00', '7h 30m', 'half_day'),
('att3', 'u3', '2026-02-12', '09:00', '18:30', '9h 30m', 'present'),
('att4', 'u5', '2026-02-13', '10:00', '19:00', '9h 0m', 'present'),
('att5', 'u2', '2026-02-13', '08:45', '18:00', '9h 15m', 'present');

-- Leave Requests
INSERT INTO leave_requests (id, user_id, type, start_date, end_date, days, reason, status, approved_by, applied_on, remark) VALUES
('lv1', 'u3', 'casual', '2026-02-20', '2026-02-21', 2, 'Family function', 'pending', NULL, '2026-02-13', NULL),
('lv2', 'u4', 'sick', '2026-02-10', '2026-02-10', 1, 'Not feeling well', 'approved', 'u2', '2026-02-10', 'Get well soon');

-- Leave Balances
INSERT INTO leave_balances (user_id, casual_total, casual_used, sick_total, sick_used, earned_total, earned_used, comp_off_total, comp_off_used) VALUES
('u1', 12, 1, 6, 0, 15, 2, 2, 0),
('u2', 12, 2, 6, 1, 15, 3, 1, 0),
('u3', 12, 3, 6, 1, 15, 2, 0, 0),
('u4', 12, 2, 6, 2, 15, 1, 1, 1),
('u5', 12, 1, 6, 0, 15, 0, 0, 0),
('u7', 12, 0, 6, 0, 15, 0, 0, 0);

-- Reimbursements
INSERT INTO reimbursements (id, user_id, category, amount, description, date, status, approved_by, applied_on) VALUES
('r1', 'u3', 'travel', 2500.00, 'Cab to site visit - Whitefield', '2026-02-12', 'pending', NULL, '2026-02-12'),
('r2', 'u4', 'client_meeting', 1800.00, 'Lunch with client at Hyatt', '2026-02-10', 'approved', 'u2', '2026-02-10');

-- Employee Documents
INSERT INTO employee_documents (id, user_id, type, label, file_name, file_data, uploaded_at) VALUES
('doc1', 'u3', 'aadhaar_card', 'Aadhaar Card', 'amit_aadhaar.pdf', 'aadhaar_file_data', '2025-03-15'),
('doc2', 'u3', 'pan_card', 'PAN Card', 'amit_pan.pdf', 'pan_file_data', '2025-03-15');

-- Bank Details
INSERT INTO bank_details (user_id, account_holder_name, bank_name, account_number, ifsc_code, branch) VALUES
('u3', 'Amit Patel', 'HDFC Bank', '50100123456789', 'HDFC0001234', 'Whitefield Branch');

-- Service Requests
INSERT INTO service_requests (id, sr_id, user_id, module, subject, description, status, resolved_by, created_at, updated_at, remarks) VALUES
('sr1', 'SR-00001', 'u3', 'leads', 'Update phone number for Lead HA00001', 'Client provided new phone number +91 99887 76544. Please update.', 'open', NULL, '2026-02-13 10:30:00', '2026-02-13 10:30:00', NULL),
('sr2', 'SR-00002', 'u4', 'hrms', 'Request week-off change', 'Need Saturday as week-off instead of default.', 'resolved', 'u2', '2026-02-10 09:00:00', '2026-02-11 11:00:00', 'Updated in system');

-- Counters
INSERT INTO counters (name, value) VALUES
('lead_counter', 13),
('sr_counter', 3);
