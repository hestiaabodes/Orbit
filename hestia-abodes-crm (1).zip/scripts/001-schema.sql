-- ORBIT CRM Database Schema for MySQL

CREATE TABLE IF NOT EXISTS users (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255) NOT NULL UNIQUE,
  password_hash VARCHAR(255) NOT NULL,
  role ENUM('admin','manager','sales_executive','presales_executive','viewer') NOT NULL DEFAULT 'sales_executive',
  phone VARCHAR(50),
  department VARCHAR(100) DEFAULT 'Sales',
  avatar VARCHAR(500),
  is_active TINYINT(1) DEFAULT 1,
  created_at DATE NOT NULL,
  last_login DATE,
  manager_id VARCHAR(50),
  week_offs JSON DEFAULT '["sunday"]',
  FOREIGN KEY (manager_id) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS projects (
  id VARCHAR(50) PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  location VARCHAR(500),
  type ENUM('residential','commercial','villa','plot') DEFAULT 'residential',
  status ENUM('upcoming','ongoing','completed') DEFAULT 'ongoing',
  total_units INT DEFAULT 0,
  available_units INT DEFAULT 0,
  price_range VARCHAR(100),
  description TEXT,
  amenities JSON DEFAULT '[]',
  image VARCHAR(500),
  created_at DATE NOT NULL
);

CREATE TABLE IF NOT EXISTS leads (
  id VARCHAR(50) PRIMARY KEY,
  lead_id VARCHAR(20) NOT NULL UNIQUE,
  name VARCHAR(255) NOT NULL,
  email VARCHAR(255),
  phone VARCHAR(50) NOT NULL,
  alternate_phone VARCHAR(50),
  source VARCHAR(100),
  status ENUM('new','contact_established','not_connected','details_shared','site_visit_scheduled','site_visit_done','won','lost','unqualified','resale_seller','resale_buyer') DEFAULT 'new',
  sub_status ENUM('hot','warm','cold','asked_to_call_later','follow_up_scheduled','not_responding','booked','booked_with_others','low_budget','not_looking_for_properties','no_inventory','is_a_cp') DEFAULT 'warm',
  assigned_to VARCHAR(50),
  project_interest VARCHAR(50),
  budget VARCHAR(100),
  notes TEXT,
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  last_contacted_at DATETIME,
  next_follow_up DATE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (project_interest) REFERENCES projects(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS lead_activities (
  id VARCHAR(50) PRIMARY KEY,
  lead_id VARCHAR(50) NOT NULL,
  type ENUM('call','email','meeting','note','site_visit','whatsapp','status_change','sms') NOT NULL,
  description TEXT,
  created_at DATETIME NOT NULL,
  created_by VARCHAR(50),
  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE CASCADE,
  FOREIGN KEY (created_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS tasks (
  id VARCHAR(50) PRIMARY KEY,
  title VARCHAR(500) NOT NULL,
  description TEXT,
  assigned_to VARCHAR(50),
  assigned_by VARCHAR(50),
  priority ENUM('low','medium','high','urgent') DEFAULT 'medium',
  status ENUM('pending','in_progress','completed','overdue') DEFAULT 'pending',
  due_date DATE,
  lead_id VARCHAR(50),
  created_at DATE NOT NULL,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (assigned_by) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (lead_id) REFERENCES leads(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS role_permissions (
  role ENUM('admin','manager','sales_executive','presales_executive','viewer') PRIMARY KEY,
  permissions JSON NOT NULL
);

CREATE TABLE IF NOT EXISTS attendance_records (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  date DATE NOT NULL,
  login_time VARCHAR(10),
  logout_time VARCHAR(10),
  total_hours VARCHAR(20) DEFAULT '-',
  status ENUM('present','absent','half_day','week_off','leave_requested','leave_approved') DEFAULT 'present',
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  UNIQUE KEY unique_user_date (user_id, date)
);

CREATE TABLE IF NOT EXISTS leave_requests (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  type ENUM('casual','sick','earned','unpaid','comp_off') NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  days INT NOT NULL,
  reason TEXT,
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  approved_by VARCHAR(50),
  applied_on DATE NOT NULL,
  remark TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS leave_balances (
  user_id VARCHAR(50) PRIMARY KEY,
  casual_total INT DEFAULT 12,
  casual_used INT DEFAULT 0,
  sick_total INT DEFAULT 6,
  sick_used INT DEFAULT 0,
  earned_total INT DEFAULT 15,
  earned_used INT DEFAULT 0,
  comp_off_total INT DEFAULT 0,
  comp_off_used INT DEFAULT 0,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS reimbursements (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  category ENUM('travel','food','accommodation','office_supplies','client_meeting','other') NOT NULL,
  amount DECIMAL(10,2) NOT NULL,
  description TEXT,
  date DATE NOT NULL,
  receipt VARCHAR(500),
  status ENUM('pending','approved','rejected') DEFAULT 'pending',
  approved_by VARCHAR(50),
  applied_on DATE NOT NULL,
  remark TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (approved_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS employee_documents (
  id VARCHAR(50) PRIMARY KEY,
  user_id VARCHAR(50) NOT NULL,
  type VARCHAR(50) NOT NULL,
  label VARCHAR(255) NOT NULL,
  file_name VARCHAR(500),
  file_data LONGTEXT,
  uploaded_at DATE NOT NULL,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS bank_details (
  user_id VARCHAR(50) PRIMARY KEY,
  account_holder_name VARCHAR(255),
  bank_name VARCHAR(255),
  account_number VARCHAR(50),
  ifsc_code VARCHAR(20),
  branch VARCHAR(255),
  document_file_name VARCHAR(500),
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS service_requests (
  id VARCHAR(50) PRIMARY KEY,
  sr_id VARCHAR(20) NOT NULL UNIQUE,
  user_id VARCHAR(50) NOT NULL,
  module ENUM('leads','projects','tasks','hrms','general') DEFAULT 'general',
  subject VARCHAR(500) NOT NULL,
  description TEXT,
  status ENUM('open','in_progress','resolved','closed','rejected') DEFAULT 'open',
  assigned_to VARCHAR(50),
  resolved_by VARCHAR(50),
  created_at DATETIME NOT NULL,
  updated_at DATETIME NOT NULL,
  remarks TEXT,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  FOREIGN KEY (assigned_to) REFERENCES users(id) ON DELETE SET NULL,
  FOREIGN KEY (resolved_by) REFERENCES users(id) ON DELETE SET NULL
);

CREATE TABLE IF NOT EXISTS counters (
  name VARCHAR(50) PRIMARY KEY,
  value INT NOT NULL DEFAULT 0
);
