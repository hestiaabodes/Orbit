-- API Keys table for external lead capture (property portals, webhooks, etc.)

CREATE TABLE IF NOT EXISTS api_keys (
  id VARCHAR(50) PRIMARY KEY,
  key_value VARCHAR(100) NOT NULL UNIQUE,
  label VARCHAR(255) NOT NULL,
  source VARCHAR(100) NOT NULL,
  project_id VARCHAR(50),
  assign_to VARCHAR(50),
  is_active TINYINT(1) DEFAULT 1,
  created_at DATETIME NOT NULL,
  last_used_at DATETIME,
  lead_count INT DEFAULT 0,
  FOREIGN KEY (project_id) REFERENCES projects(id) ON DELETE SET NULL,
  FOREIGN KEY (assign_to) REFERENCES users(id) ON DELETE SET NULL
);
