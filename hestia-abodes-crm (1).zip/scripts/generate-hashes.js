const bcrypt = require("bcryptjs")

async function main() {
  const passwords = ["admin123", "priya123", "amit123", "sneha123", "vikram123", "viewer123", "rohit123"]
  for (const pw of passwords) {
    const hash = await bcrypt.hash(pw, 12)
    console.log(pw + ": " + hash)
  }
}
main()
