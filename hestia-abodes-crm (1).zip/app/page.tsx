"use client"

import { useState, useEffect, useRef, useCallback } from "react"
import { CRMProvider, useCRM } from "@/lib/crm-context"
import { roleLabels } from "@/lib/data"
import { LoginPage } from "@/components/login-page"
import { AppSidebar } from "@/components/app-sidebar"
import { Dashboard } from "@/components/dashboard"
import { LeadsManagement } from "@/components/leads-management"
import { ProjectsManagement } from "@/components/projects-management"
import { TasksManagement } from "@/components/tasks-management"
import { TeamManagement } from "@/components/team-management"
import { Reports } from "@/components/reports"
import { AdminPanel } from "@/components/admin-panel"
import { SettingsPage } from "@/components/settings-page"
import { HRMSModule } from "@/components/hrms-module"
import { HelpDesk } from "@/components/help-desk"
import { Bell, Search, Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"
import { Badge } from "@/components/ui/badge"

function CRMApp() {
  const { isAuthenticated, isLoading, currentUser, getScopedLeads, notificationCount, playNotificationSound } = useCRM()
  const leads = getScopedLeads()
  const [activeView, setActiveView] = useState("dashboard")
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false)
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [mobileSearchOpen, setMobileSearchOpen] = useState(false)
  const [searchQuery, setSearchQuery] = useState("")
  const [searchResults, setSearchResults] = useState<any[]>([])
  const [showSearchResults, setShowSearchResults] = useState(false)
  const searchTimeout = useRef<NodeJS.Timeout | null>(null)

  const handleSearch = useCallback((q: string) => {
    setSearchQuery(q)
    if (searchTimeout.current) clearTimeout(searchTimeout.current)
    if (q.length < 2) { setSearchResults([]); setShowSearchResults(false); return }
    searchTimeout.current = setTimeout(async () => {
      try {
        const res = await fetch(`/api/search?q=${encodeURIComponent(q)}`)
        if (res.ok) {
          const data = await res.json()
          setSearchResults(data.results || [])
          setShowSearchResults(true)
        }
      } catch { setSearchResults([]) }
    }, 300)
  }, [])

  // Track previous notification count and play sound on increase
  const prevNotifRef = useRef(0)
  useEffect(() => {
    if (notificationCount > prevNotifRef.current && notificationCount > 0) {
      playNotificationSound()
    }
    prevNotifRef.current = notificationCount
  }, [notificationCount, playNotificationSound])

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center bg-background">
        <div className="flex flex-col items-center gap-4">
          <div className="h-10 w-10 animate-spin rounded-full border-4 border-muted border-t-primary" />
          <p className="text-sm text-muted-foreground">Loading ORBIT CRM...</p>
        </div>
      </div>
    )
  }

  if (!isAuthenticated) {
    return <LoginPage />
  }

  const today = new Date()
  const todayStr = today.toISOString().split("T")[0]
  const overdueFollowUpLeads = leads.filter((l) => l.nextFollowUp && new Date(l.nextFollowUp) <= today)
  const todayFollowUpLeads = leads.filter((l) => l.nextFollowUp && l.nextFollowUp === todayStr)
  const newLeadsTodayList = leads.filter((l) => l.createdAt.split("T")[0] === todayStr)
  const pendingTasks = getScopedLeads().length > 0 ? [] : [] // placeholder
  const overdueFollowUps = overdueFollowUpLeads.length
  const notifCount = overdueFollowUps + newLeadsTodayList.length + todayFollowUpLeads.length

  const renderView = () => {
    switch (activeView) {
      case "dashboard": return <Dashboard />
      case "leads": return <LeadsManagement />
      case "projects": return <ProjectsManagement />
      case "tasks": return <TasksManagement />
      case "team": return <TeamManagement />
      case "reports": return <Reports />
      case "hrms": return <HRMSModule />
      case "helpdesk": return <HelpDesk />
      case "admin": return <AdminPanel />
      case "settings": return <SettingsPage />
      default: return <Dashboard />
    }
  }

  const viewTitles: Record<string, string> = {
    dashboard: "Dashboard",
    leads: "Leads",
    projects: "Projects",
    tasks: "Tasks",
    team: "Team",
    reports: "Reports",
    hrms: "HRMS",
    helpdesk: "Help Desk",
    admin: "Admin Panel",
    settings: "Settings",
  }

  return (
    <div className="flex h-screen overflow-hidden bg-background">
      {mobileMenuOpen && (
        <div className="fixed inset-0 z-40 bg-foreground/20 lg:hidden" onClick={() => setMobileMenuOpen(false)} />
      )}
      <div className={`fixed inset-y-0 left-0 z-50 lg:relative lg:z-0 ${mobileMenuOpen ? "translate-x-0" : "-translate-x-full lg:translate-x-0"} transition-transform duration-300`}>
        <AppSidebar activeView={activeView} onNavigate={(view) => { setActiveView(view); setMobileMenuOpen(false) }} collapsed={sidebarCollapsed} onToggleCollapse={() => setSidebarCollapsed(!sidebarCollapsed)} />
      </div>
      <main className="flex flex-1 flex-col overflow-hidden">
        <header className="flex items-center justify-between border-b border-border bg-card px-4 py-3 lg:px-6">
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="lg:hidden text-foreground" onClick={() => setMobileMenuOpen(!mobileMenuOpen)} aria-label="Toggle menu">
              <Menu className="h-5 w-5" />
            </Button>
            <div className="hidden sm:block">
              <h2 className="text-lg font-semibold text-foreground">{viewTitles[activeView]}</h2>
            </div>
          </div>
          <div className="flex items-center gap-3">
            <Button variant="ghost" size="icon" className="md:hidden text-foreground" onClick={() => setMobileSearchOpen(!mobileSearchOpen)} aria-label="Search">
              <Search className="h-5 w-5" />
            </Button>
            <div className="relative hidden md:block">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search leads, projects, tasks..."
                className="w-64 border-border bg-background pl-9 text-foreground"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                onFocus={() => { if (searchResults.length > 0) setShowSearchResults(true) }}
                onBlur={() => setTimeout(() => setShowSearchResults(false), 200)}
              />
              {showSearchResults && searchResults.length > 0 && (
                <div className="absolute left-0 top-full z-50 mt-1 w-80 rounded-lg border border-border bg-card shadow-lg">
                  <div className="max-h-80 overflow-y-auto p-1">
                    {searchResults.map((r: any, i: number) => (
                      <button
                        key={`${r.type}-${r.id}-${i}`}
                        className="flex w-full items-center gap-3 rounded-md px-3 py-2 text-left text-sm hover:bg-muted"
                        onMouseDown={() => {
                          if (r.type === "lead") setActiveView("leads")
                          else if (r.type === "project") setActiveView("projects")
                          else if (r.type === "task") setActiveView("tasks")
                          else if (r.type === "user") setActiveView("team")
                          setShowSearchResults(false)
                          setSearchQuery("")
                        }}
                      >
                        <Badge variant="outline" className="shrink-0 text-[10px]">{r.type}</Badge>
                        <div className="flex flex-col overflow-hidden">
                          <span className="truncate font-medium text-foreground">{r.title}</span>
                          {r.subtitle && <span className="truncate text-xs text-muted-foreground">{r.subtitle}</span>}
                        </div>
                      </button>
                    ))}
                  </div>
                </div>
              )}
            </div>
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" size="icon" className="relative text-foreground">
                  <Bell className="h-5 w-5" />
                  {notifCount > 0 && (
                    <span className="absolute -right-0.5 -top-0.5 flex h-4 w-4 items-center justify-center rounded-full bg-destructive text-[10px] font-bold text-destructive-foreground">{notifCount}</span>
                  )}
                  <span className="sr-only">Notifications</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-80">
                <div className="px-3 py-2 text-sm font-semibold text-foreground">Notifications</div>
                <div className="max-h-80 overflow-y-auto">
                  {overdueFollowUpLeads.length > 0 && (
                    <DropdownMenuItem onClick={() => setActiveView("leads")} className="flex flex-col items-start gap-1 px-3 py-2">
                      <span className="text-sm font-medium text-destructive">{overdueFollowUpLeads.length} overdue follow-ups</span>
                      <span className="text-xs text-muted-foreground">
                        {overdueFollowUpLeads.slice(0, 3).map(l => l.name).join(", ")}{overdueFollowUpLeads.length > 3 ? ` +${overdueFollowUpLeads.length - 3} more` : ""}
                      </span>
                    </DropdownMenuItem>
                  )}
                  {todayFollowUpLeads.length > 0 && (
                    <DropdownMenuItem onClick={() => setActiveView("leads")} className="flex flex-col items-start gap-1 px-3 py-2">
                      <span className="text-sm font-medium text-foreground">{todayFollowUpLeads.length} follow-ups due today</span>
                      <span className="text-xs text-muted-foreground">
                        {todayFollowUpLeads.slice(0, 3).map(l => l.name).join(", ")}
                      </span>
                    </DropdownMenuItem>
                  )}
                  {newLeadsTodayList.length > 0 && (
                    <DropdownMenuItem onClick={() => setActiveView("leads")} className="flex flex-col items-start gap-1 px-3 py-2">
                      <span className="text-sm font-medium text-foreground">{newLeadsTodayList.length} new leads today</span>
                      <span className="text-xs text-muted-foreground">
                        {newLeadsTodayList.slice(0, 3).map(l => `${l.name} (${l.source})`).join(", ")}
                      </span>
                    </DropdownMenuItem>
                  )}
                  {notifCount === 0 && <div className="px-3 py-6 text-center text-sm text-muted-foreground">No new notifications</div>}
                </div>
              </DropdownMenuContent>
            </DropdownMenu>
            <div className="flex items-center gap-2">
              <div className="flex h-8 w-8 items-center justify-center rounded-full bg-primary text-xs font-bold text-primary-foreground">
                {currentUser?.name.split(" ").map((n) => n[0]).join("")}
              </div>
              <div className="hidden flex-col sm:flex">
                <span className="text-xs font-medium text-foreground">{currentUser?.name}</span>
                <span className="text-[10px] text-muted-foreground">{currentUser?.role ? roleLabels[currentUser.role] : ""}</span>
              </div>
            </div>
          </div>
        </header>
        {mobileSearchOpen && (
          <div className="border-b border-border bg-card px-4 py-2 md:hidden">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
              <Input
                placeholder="Search leads, projects, tasks..."
                className="border-border bg-background pl-9 text-foreground"
                value={searchQuery}
                onChange={(e) => handleSearch(e.target.value)}
                autoFocus
              />
            </div>
          </div>
        )}
        <div className="flex-1 overflow-y-auto p-4 lg:p-6">{renderView()}</div>
      </main>
    </div>
  )
}

export default function Page() {
  return (
    <CRMProvider>
      <CRMApp />
    </CRMProvider>
  )
}
