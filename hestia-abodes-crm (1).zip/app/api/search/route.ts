import { NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const { query } = await import("@/lib/db")

    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const q = req.nextUrl.searchParams.get("q")?.trim()
    if (!q || q.length < 2) return NextResponse.json({ results: [] })

    const searchTerm = `%${q}%`

    const [leads, projects, tasks, users] = await Promise.all([
      query(
        `SELECT id, lead_id, name, phone, email, status FROM leads
         WHERE name LIKE ? OR phone LIKE ? OR email LIKE ? OR lead_id LIKE ? LIMIT 5`,
        [searchTerm, searchTerm, searchTerm, searchTerm]
      ),
      query(
        `SELECT id, name, location, status FROM projects WHERE name LIKE ? OR location LIKE ? LIMIT 5`,
        [searchTerm, searchTerm]
      ),
      query(
        `SELECT id, title, status FROM tasks WHERE title LIKE ? OR description LIKE ? LIMIT 5`,
        [searchTerm, searchTerm]
      ),
      user.role === "admin"
        ? query(`SELECT id, name, email, role FROM users WHERE name LIKE ? OR email LIKE ? LIMIT 5`, [searchTerm, searchTerm])
        : Promise.resolve([]),
    ])

    const results = [
      ...leads.map((l: any) => ({ type: "lead", id: l.id, title: l.name, subtitle: `${l.lead_id} - ${l.phone}`, status: l.status })),
      ...projects.map((p: any) => ({ type: "project", id: p.id, title: p.name, subtitle: p.location, status: p.status })),
      ...tasks.map((t: any) => ({ type: "task", id: t.id, title: t.title, subtitle: "", status: t.status })),
      ...users.map((u: any) => ({ type: "user", id: u.id, title: u.name, subtitle: u.email, status: u.role })),
    ]

    return NextResponse.json({ results })
  } catch {
    return NextResponse.json({ results: [] })
  }
}
