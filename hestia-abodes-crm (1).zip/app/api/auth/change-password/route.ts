import { NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const { queryOne, execute } = await import("@/lib/db")
    const bcrypt = (await import("bcryptjs")).default

    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const { currentPassword, newPassword } = await req.json()

    if (!currentPassword || !newPassword) {
      return NextResponse.json({ error: "Both current and new password required" }, { status: 400 })
    }
    if (newPassword.length < 6) {
      return NextResponse.json({ error: "New password must be at least 6 characters" }, { status: 400 })
    }

    const dbUser = await queryOne("SELECT password_hash FROM users WHERE id = ?", [user.id])
    if (!dbUser) return NextResponse.json({ error: "User not found" }, { status: 404 })

    const valid = await bcrypt.compare(currentPassword, dbUser.password_hash)
    if (!valid) return NextResponse.json({ error: "Current password is incorrect" }, { status: 403 })

    const newHash = await bcrypt.hash(newPassword, 12)
    await execute("UPDATE users SET password_hash = ? WHERE id = ?", [newHash, user.id])

    return NextResponse.json({ success: true })
  } catch (error: any) {
    if (error?.code === "ECONNREFUSED") {
      return NextResponse.json({ error: "Database not available" }, { status: 503 })
    }
    console.error("Change password error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
