import { NextResponse } from "next/server"

export async function GET() {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const user = await getCurrentUser()
    if (!user) {
      return NextResponse.json({ user: null }, { status: 401 })
    }
    return NextResponse.json({ user })
  } catch {
    // DB not available
    return NextResponse.json({ user: null, dbAvailable: false }, { status: 503 })
  }
}
