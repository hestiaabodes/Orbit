import { NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const ip = req.headers.get("x-forwarded-for") || req.headers.get("x-real-ip") || "unknown"
    const { checkRateLimit } = await import("@/lib/rate-limit")
    const { allowed, retryAfterSecs } = checkRateLimit(`login:${ip}`, 5, 15 * 60 * 1000)
    if (!allowed) {
      return NextResponse.json({ error: `Too many login attempts. Try again in ${Math.ceil(retryAfterSecs / 60)} minutes.` }, { status: 429 })
    }

    const { email, password } = await req.json()
    if (!email || !password) {
      return NextResponse.json({ error: "Email and password required" }, { status: 400 })
    }

    const { queryOne } = await import("@/lib/db")
    const { verifyPassword, createSession } = await import("@/lib/auth")

    const user = await queryOne(
      "SELECT id, password_hash, is_active FROM users WHERE email = ?",
      [email]
    )

    if (!user || !user.is_active) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    const valid = await verifyPassword(password, user.password_hash)
    if (!valid) {
      return NextResponse.json({ error: "Invalid credentials" }, { status: 401 })
    }

    // Update last_login
    await queryOne("UPDATE users SET last_login = CURDATE() WHERE id = ?", [user.id])

    await createSession(user.id)

    const { logAudit } = await import("@/lib/audit")
    await logAudit(user.id, "login", "user", user.id, { email }, ip)

    return NextResponse.json({ success: true })
  } catch (error: any) {
    // If MySQL not available, return 503 so frontend falls back
    if (error?.code === "ECONNREFUSED" || error?.code === "ER_ACCESS_DENIED_ERROR" || error?.message?.includes("mysql")) {
      return NextResponse.json({ error: "Database not available", dbAvailable: false }, { status: 503 })
    }
    console.error("Login error:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
