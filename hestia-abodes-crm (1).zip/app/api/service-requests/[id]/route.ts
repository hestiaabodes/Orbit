import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const { id } = await params
  const body = await req.json()
  const now = new Date().toISOString().replace("T", " ").substring(0, 19)
  const updates: string[] = ["updated_at = ?"]
  const values: any[] = [now]
  if (body.status !== undefined) { updates.push("status = ?"); values.push(body.status) }
  if (body.assignedTo !== undefined) { updates.push("assigned_to = ?"); values.push(body.assignedTo) }
  if (body.resolvedBy !== undefined) { updates.push("resolved_by = ?"); values.push(body.resolvedBy) }
  if (body.remarks !== undefined) { updates.push("remarks = ?"); values.push(body.remarks) }
  values.push(id)
  await execute(`UPDATE service_requests SET ${updates.join(", ")} WHERE id = ?`, values)
  return NextResponse.json({ success: true })
}
