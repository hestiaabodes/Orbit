import { NextRequest, NextResponse } from "next/server"
import { query, execute, queryOne } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapSR(row: any) {
  return {
    id: row.id, srId: row.sr_id, userId: row.user_id,
    module: row.module, subject: row.subject, description: row.description,
    status: row.status, assignedTo: row.assigned_to,
    resolvedBy: row.resolved_by, createdAt: row.created_at,
    updatedAt: row.updated_at, remarks: row.remarks,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM service_requests ORDER BY created_at DESC")
  return NextResponse.json({ serviceRequests: rows.map(mapSR) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const now = new Date().toISOString().replace("T", " ").substring(0, 19)

  await execute("UPDATE counters SET value = value + 1 WHERE name = 'sr_counter'")
  const counter = await queryOne("SELECT value FROM counters WHERE name = 'sr_counter'")
  const counterVal = (counter?.value || 3) - 1
  const srId = `SR-${String(counterVal).padStart(5, "0")}`
  const id = `sr${Date.now()}`

  await execute(
    `INSERT INTO service_requests (id, sr_id, user_id, module, subject, description, status, created_at, updated_at)
     VALUES (?, ?, ?, ?, ?, ?, 'open', ?, ?)`,
    [id, srId, body.userId || me.id, body.module || "general", body.subject, body.description || "", now, now]
  )
  return NextResponse.json({ success: true })
}
