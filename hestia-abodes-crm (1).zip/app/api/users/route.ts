import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser, hashPassword } from "@/lib/auth"

function mapUser(row: any) {
  return {
    id: row.id, name: row.name, email: row.email, role: row.role,
    phone: row.phone, department: row.department, avatar: row.avatar,
    isActive: !!row.is_active, createdAt: row.created_at,
    lastLogin: row.last_login, managerId: row.manager_id,
    weekOffs: row.week_offs ? JSON.parse(row.week_offs) : ["sunday"],
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const rows = await query(
    "SELECT id, name, email, role, phone, department, avatar, is_active, created_at, last_login, manager_id, week_offs FROM users"
  )
  return NextResponse.json({ users: rows.map(mapUser) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me || me.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const body = await req.json()
  const id = `u${Date.now()}`
  const passwordHash = await hashPassword(body.password || "password123")
  const createdAt = new Date().toISOString().split("T")[0]
  const weekOffs = JSON.stringify(body.weekOffs || ["sunday"])

  await execute(
    `INSERT INTO users (id, name, email, password_hash, role, phone, department, avatar, is_active, created_at, manager_id, week_offs)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, body.name, body.email, passwordHash, body.role || "sales_executive", body.phone || "", body.department || "Sales", body.avatar || null, body.isActive !== false ? 1 : 0, createdAt, body.managerId || null, weekOffs]
  )

  // Create leave balance for new user
  await execute(
    "INSERT INTO leave_balances (user_id) VALUES (?)",
    [id]
  )

  const user = mapUser({
    id, name: body.name, email: body.email, role: body.role || "sales_executive",
    phone: body.phone || "", department: body.department || "Sales", avatar: body.avatar,
    is_active: body.isActive !== false ? 1 : 0, created_at: createdAt, last_login: null,
    manager_id: body.managerId || null, week_offs: weekOffs,
  })

  return NextResponse.json({ user })
}
