import { NextRequest, NextResponse } from "next/server"
import { execute, queryOne } from "@/lib/db"
import { getCurrentUser, hashPassword } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const updates: string[] = []
  const values: any[] = []

  if (body.name !== undefined) { updates.push("name = ?"); values.push(body.name) }
  if (body.email !== undefined) { updates.push("email = ?"); values.push(body.email) }
  if (body.phone !== undefined) { updates.push("phone = ?"); values.push(body.phone) }
  if (body.role !== undefined) { updates.push("role = ?"); values.push(body.role) }
  if (body.department !== undefined) { updates.push("department = ?"); values.push(body.department) }
  if (body.isActive !== undefined) { updates.push("is_active = ?"); values.push(body.isActive ? 1 : 0) }
  if (body.managerId !== undefined) { updates.push("manager_id = ?"); values.push(body.managerId || null) }
  if (body.weekOffs !== undefined) { updates.push("week_offs = ?"); values.push(JSON.stringify(body.weekOffs)) }
  if (body.avatar !== undefined) { updates.push("avatar = ?"); values.push(body.avatar) }
  if (body.password) { updates.push("password_hash = ?"); values.push(await hashPassword(body.password)) }

  if (updates.length === 0) return NextResponse.json({ error: "No fields to update" }, { status: 400 })

  values.push(id)
  await execute(`UPDATE users SET ${updates.join(", ")} WHERE id = ?`, values)

  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me || me.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 })

  const { id } = await params
  await execute("DELETE FROM users WHERE id = ?", [id])
  return NextResponse.json({ success: true })
}
