import { NextRequest, NextResponse } from "next/server"
import crypto from "crypto"

export async function GET() {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const me = await getCurrentUser()
    if (!me || me.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { query } = await import("@/lib/db")
    const rows = await query("SELECT * FROM api_keys ORDER BY created_at DESC")
    const keys = rows.map((r: any) => ({
      id: r.id,
      keyValue: r.key_value,
      label: r.label,
      source: r.source,
      projectId: r.project_id,
      assignTo: r.assign_to,
      isActive: !!r.is_active,
      createdAt: r.created_at,
      lastUsedAt: r.last_used_at,
      leadCount: r.lead_count,
    }))
    return NextResponse.json({ keys })
  } catch {
    return NextResponse.json({ keys: [], dbAvailable: false }, { status: 503 })
  }
}

export async function POST(req: NextRequest) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const me = await getCurrentUser()
    if (!me || me.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { execute } = await import("@/lib/db")
    const body = await req.json()

    const id = `ak${Date.now()}`
    const keyValue = `orbit_${crypto.randomBytes(24).toString("hex")}`
    const now = new Date().toISOString().replace("T", " ").substring(0, 19)

    await execute(
      `INSERT INTO api_keys (id, key_value, label, source, project_id, assign_to, is_active, created_at)
       VALUES (?, ?, ?, ?, ?, ?, 1, ?)`,
      [id, keyValue, body.label, body.source, body.projectId || null, body.assignTo || null, now]
    )

    return NextResponse.json({ success: true, keyValue })
  } catch (error) {
    console.error("API key creation error:", error)
    return NextResponse.json({ error: "Failed to create API key" }, { status: 500 })
  }
}
