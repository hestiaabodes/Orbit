import { NextRequest, NextResponse } from "next/server"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const me = await getCurrentUser()
    if (!me || me.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { execute } = await import("@/lib/db")
    const { id } = await params
    const body = await req.json()

    const fields: string[] = []
    const values: any[] = []

    if (body.label !== undefined) { fields.push("label = ?"); values.push(body.label) }
    if (body.source !== undefined) { fields.push("source = ?"); values.push(body.source) }
    if (body.projectId !== undefined) { fields.push("project_id = ?"); values.push(body.projectId || null) }
    if (body.assignTo !== undefined) { fields.push("assign_to = ?"); values.push(body.assignTo || null) }
    if (body.isActive !== undefined) { fields.push("is_active = ?"); values.push(body.isActive ? 1 : 0) }

    if (fields.length > 0) {
      values.push(id)
      await execute(`UPDATE api_keys SET ${fields.join(", ")} WHERE id = ?`, values)
    }

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("API key update error:", error)
    return NextResponse.json({ error: "Failed to update API key" }, { status: 500 })
  }
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const me = await getCurrentUser()
    if (!me || me.role !== "admin") {
      return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    }

    const { execute } = await import("@/lib/db")
    const { id } = await params
    await execute("DELETE FROM api_keys WHERE id = ?", [id])
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("API key delete error:", error)
    return NextResponse.json({ error: "Failed to delete API key" }, { status: 500 })
  }
}
