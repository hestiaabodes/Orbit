import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapBalance(row: any) {
  return {
    userId: row.user_id,
    casual: { total: row.casual_total, used: row.casual_used },
    sick: { total: row.sick_total, used: row.sick_used },
    earned: { total: row.earned_total, used: row.earned_used },
    comp_off: { total: row.comp_off_total, used: row.comp_off_used },
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM leave_balances")
  return NextResponse.json({ leaveBalances: rows.map(mapBalance) })
}
