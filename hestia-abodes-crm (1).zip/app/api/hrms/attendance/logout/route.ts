import { NextRequest, NextResponse } from "next/server"
import { execute, queryOne } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const userId = body.userId || me.id
  const today = new Date().toISOString().split("T")[0]
  const now = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })

  const record = await queryOne(
    "SELECT id, login_time FROM attendance_records WHERE user_id = ? AND date = ? AND login_time IS NOT NULL",
    [userId, today]
  )
  if (!record) return NextResponse.json({ error: "No login found" }, { status: 400 })

  const loginParts = record.login_time.split(":")
  const logoutParts = now.split(":")
  const loginMin = parseInt(loginParts[0]) * 60 + parseInt(loginParts[1])
  const logoutMin = parseInt(logoutParts[0]) * 60 + parseInt(logoutParts[1])
  const diff = Math.max(logoutMin - loginMin, 0)
  const hours = Math.floor(diff / 60)
  const mins = diff % 60
  const totalHours = `${hours}h ${mins}m`
  const totalMinutes = hours * 60 + mins
  const status = totalMinutes >= 510 ? "present" : totalMinutes >= 270 ? "half_day" : "absent"

  await execute(
    "UPDATE attendance_records SET logout_time = ?, total_hours = ?, status = ? WHERE id = ?",
    [now, totalHours, status, record.id]
  )
  return NextResponse.json({ success: true })
}
