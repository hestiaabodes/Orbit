import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapAttendance(row: any) {
  return {
    id: row.id, userId: row.user_id, date: row.date,
    loginTime: row.login_time, logoutTime: row.logout_time,
    totalHours: row.total_hours, status: row.status,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM attendance_records ORDER BY date DESC")
  return NextResponse.json({ attendance: rows.map(mapAttendance) })
}
