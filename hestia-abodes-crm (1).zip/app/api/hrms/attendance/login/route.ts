import { NextRequest, NextResponse } from "next/server"
import { execute, queryOne } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const userId = body.userId || me.id
  const today = new Date().toISOString().split("T")[0]
  const now = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit", hour12: false })
  const existing = await queryOne(
    "SELECT id FROM attendance_records WHERE user_id = ? AND date = ?", [userId, today]
  )
  if (existing) {
    await execute("UPDATE attendance_records SET login_time = ?, status = 'present' WHERE id = ?", [now, existing.id])
  } else {
    const id = `att${Date.now()}`
    await execute(
      "INSERT INTO attendance_records (id, user_id, date, login_time, total_hours, status) VALUES (?, ?, ?, ?, '-', 'present')",
      [id, userId, today, now]
    )
  }
  return NextResponse.json({ success: true })
}
