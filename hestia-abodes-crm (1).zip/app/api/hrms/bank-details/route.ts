import { NextRequest, NextResponse } from "next/server"
import { query, execute, queryOne } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapBank(row: any) {
  return {
    userId: row.user_id, accountHolderName: row.account_holder_name,
    bankName: row.bank_name, accountNumber: row.account_number,
    ifscCode: row.ifsc_code, branch: row.branch,
    documentFileName: row.document_file_name,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM bank_details")
  return NextResponse.json({ bankDetails: rows.map(mapBank) })
}

export async function PUT(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const userId = body.userId
  const existing = await queryOne("SELECT user_id FROM bank_details WHERE user_id = ?", [userId])
  if (existing) {
    await execute(
      `UPDATE bank_details SET account_holder_name = ?, bank_name = ?, account_number = ?, ifsc_code = ?, branch = ?, document_file_name = ? WHERE user_id = ?`,
      [body.accountHolderName, body.bankName, body.accountNumber, body.ifscCode, body.branch, body.documentFileName || null, userId]
    )
  } else {
    await execute(
      `INSERT INTO bank_details (user_id, account_holder_name, bank_name, account_number, ifsc_code, branch, document_file_name) VALUES (?, ?, ?, ?, ?, ?, ?)`,
      [userId, body.accountHolderName, body.bankName, body.accountNumber, body.ifscCode, body.branch, body.documentFileName || null]
    )
  }
  return NextResponse.json({ success: true })
}
