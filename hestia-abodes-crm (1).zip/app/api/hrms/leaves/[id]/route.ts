import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const { id } = await params
  const body = await req.json()
  const updates: string[] = []
  const values: any[] = []
  if (body.status !== undefined) { updates.push("status = ?"); values.push(body.status) }
  if (body.approvedBy !== undefined) { updates.push("approved_by = ?"); values.push(body.approvedBy) }
  if (body.remark !== undefined) { updates.push("remark = ?"); values.push(body.remark) }
  if (updates.length === 0) return NextResponse.json({ error: "No fields" }, { status: 400 })
  values.push(id)
  await execute(`UPDATE leave_requests SET ${updates.join(", ")} WHERE id = ?`, values)
  return NextResponse.json({ success: true })
}
