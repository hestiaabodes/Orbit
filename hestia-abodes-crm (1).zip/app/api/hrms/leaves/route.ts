import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapLeave(row: any) {
  return {
    id: row.id, userId: row.user_id, type: row.type,
    startDate: row.start_date, endDate: row.end_date, days: row.days,
    reason: row.reason, status: row.status, approvedBy: row.approved_by,
    appliedOn: row.applied_on, remark: row.remark,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM leave_requests ORDER BY applied_on DESC")
  return NextResponse.json({ leaveRequests: rows.map(mapLeave) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const id = `lv${Date.now()}`
  const appliedOn = new Date().toISOString().split("T")[0]
  await execute(
    `INSERT INTO leave_requests (id, user_id, type, start_date, end_date, days, reason, status, applied_on)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    [id, body.userId || me.id, body.type, body.startDate, body.endDate, body.days, body.reason || "", appliedOn]
  )
  return NextResponse.json({ success: true })
}
