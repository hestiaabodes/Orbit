import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapReimbursement(row: any) {
  return {
    id: row.id, userId: row.user_id, category: row.category,
    amount: parseFloat(row.amount), description: row.description,
    date: row.date, receipt: row.receipt, status: row.status,
    approvedBy: row.approved_by, appliedOn: row.applied_on, remark: row.remark,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM reimbursements ORDER BY applied_on DESC")
  return NextResponse.json({ reimbursements: rows.map(mapReimbursement) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const id = `r${Date.now()}`
  const appliedOn = new Date().toISOString().split("T")[0]
  await execute(
    `INSERT INTO reimbursements (id, user_id, category, amount, description, date, receipt, status, applied_on)
     VALUES (?, ?, ?, ?, ?, ?, ?, 'pending', ?)`,
    [id, body.userId || me.id, body.category, body.amount, body.description || "", body.date, body.receipt || null, appliedOn]
  )
  return NextResponse.json({ success: true })
}
