import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapDoc(row: any) {
  return {
    id: row.id, userId: row.user_id, type: row.type, label: row.label,
    fileName: row.file_name, fileData: row.file_data, uploadedAt: row.uploaded_at,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM employee_documents ORDER BY uploaded_at DESC")
  return NextResponse.json({ documents: rows.map(mapDoc) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const id = `doc${Date.now()}`
  const uploadedAt = new Date().toISOString().split("T")[0]
  await execute(
    "INSERT INTO employee_documents (id, user_id, type, label, file_name, file_data, uploaded_at) VALUES (?, ?, ?, ?, ?, ?, ?)",
    [id, body.userId || me.id, body.type, body.label, body.fileName || "", body.fileData || null, uploadedAt]
  )
  return NextResponse.json({ success: true })
}
