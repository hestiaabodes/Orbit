import { NextRequest, NextResponse } from "next/server"

/**
 * Lead Capture Webhook for Property Portals
 * 
 * This endpoint accepts leads from external sources like:
 * - MagicBricks, 99acres, Housing.com, OLX, Facebook Lead Ads, Google Ads, IndiaMART, etc.
 * 
 * Authentication: API Key passed as query param ?key=YOUR_API_KEY or in header X-API-Key
 * 
 * Accepted fields (all formats supported):
 *   name / full_name / customer_name / lead_name / Name
 *   phone / mobile / contact / phone_number / Phone / Mobile
 *   email / email_id / Email
 *   project / property / project_name / Project
 *   budget / Budget
 *   notes / message / remarks / comment / description / Message
 *   source (auto-filled from API key if not provided)
 */

export async function POST(req: NextRequest) {
  try {
    const { query: dbQuery, execute, queryOne } = await import("@/lib/db")

    // --- Authenticate via API key ---
    const apiKey =
      req.nextUrl.searchParams.get("key") ||
      req.headers.get("x-api-key") ||
      req.headers.get("authorization")?.replace("Bearer ", "")

    if (!apiKey) {
      return NextResponse.json(
        { success: false, error: "Missing API key. Pass it as ?key=YOUR_KEY or X-API-Key header." },
        { status: 401 }
      )
    }

    const keyRow = await queryOne(
      "SELECT * FROM api_keys WHERE key_value = ? AND is_active = 1",
      [apiKey]
    )

    if (!keyRow) {
      return NextResponse.json(
        { success: false, error: "Invalid or inactive API key." },
        { status: 403 }
      )
    }

    // --- Parse body (support JSON, form-urlencoded, or multipart form) ---
    let body: Record<string, any> = {}
    const contentType = req.headers.get("content-type") || ""

    if (contentType.includes("application/json")) {
      body = await req.json()
    } else if (contentType.includes("application/x-www-form-urlencoded") || contentType.includes("multipart/form-data")) {
      const formData = await req.formData()
      formData.forEach((value, key) => {
        body[key] = value.toString()
      })
    } else {
      // Try JSON anyway
      try { body = await req.json() } catch {
        return NextResponse.json(
          { success: false, error: "Could not parse request body. Send JSON or form data." },
          { status: 400 }
        )
      }
    }

    // --- Normalize field names (support all portal formats) ---
    const name =
      body.name || body.full_name || body.customer_name || body.lead_name ||
      body.Name || body.FullName || body.CustomerName || body.LeadName ||
      body.FULL_NAME || body.CUSTOMER_NAME || body.LEAD_NAME || "Unknown"

    const phone =
      body.phone || body.mobile || body.contact || body.phone_number ||
      body.Phone || body.Mobile || body.Contact || body.PhoneNumber ||
      body.PHONE || body.MOBILE || body.CONTACT || body.PHONE_NUMBER || ""

    const email =
      body.email || body.email_id || body.Email || body.EmailId ||
      body.EMAIL || body.EMAIL_ID || ""

    const alternatePhone =
      body.alternate_phone || body.alt_phone || body.secondary_phone ||
      body.AlternatePhone || body.AltPhone || ""

    const projectFromBody =
      body.project || body.property || body.project_name || body.property_name ||
      body.Project || body.Property || body.ProjectName ||
      body.PROJECT || body.PROPERTY || ""

    const budget =
      body.budget || body.Budget || body.BUDGET || ""

    const notes =
      body.notes || body.message || body.remarks || body.comment || body.description ||
      body.Notes || body.Message || body.Remarks || body.Comment || body.Description ||
      body.NOTES || body.MESSAGE || body.REMARKS || ""

    const sourceFromBody =
      body.source || body.Source || body.SOURCE || body.utm_source || ""

    if (!phone && !email) {
      return NextResponse.json(
        { success: false, error: "At least phone or email is required." },
        { status: 400 }
      )
    }

    // --- Check for duplicate (same phone, within last 24 hours from same source) ---
    if (phone) {
      const duplicate = await queryOne(
        "SELECT id, lead_id FROM leads WHERE phone = ? AND source = ? AND created_at > DATE_SUB(NOW(), INTERVAL 24 HOUR)",
        [phone, sourceFromBody || keyRow.source]
      )
      if (duplicate) {
        return NextResponse.json({
          success: true,
          duplicate: true,
          message: "Lead already exists (received within last 24 hours).",
          leadId: duplicate.lead_id,
        })
      }
    }

    // --- Determine source ---
    const source = sourceFromBody || keyRow.source || "Website"

    // --- Determine project interest ---
    let projectInterest = keyRow.project_id || null
    if (projectFromBody && !projectInterest) {
      // Try to match project by name
      const proj = await queryOne(
        "SELECT id FROM projects WHERE LOWER(name) LIKE ?",
        [`%${projectFromBody.toLowerCase()}%`]
      )
      if (proj) projectInterest = proj.id
    }

    // --- Determine assignee (round-robin among active sales executives) ---
    let assignTo = keyRow.assign_to || null

    if (!assignTo) {
      // Round-robin: pick the active sales exec with fewest leads assigned today
      const salesUsers = await dbQuery(
        `SELECT u.id, COUNT(l.id) as today_leads 
         FROM users u 
         LEFT JOIN leads l ON l.assigned_to = u.id AND DATE(l.created_at) = CURDATE()
         WHERE u.is_active = 1 AND u.role IN ('sales_executive', 'presales_executive')
         GROUP BY u.id
         ORDER BY today_leads ASC, RAND()
         LIMIT 1`
      )
      if (salesUsers.length > 0) {
        assignTo = salesUsers[0].id
      } else {
        // Fallback: assign to any active admin or manager
        const fallbackUser = await queryOne(
          "SELECT id FROM users WHERE is_active = 1 AND role IN ('admin', 'manager') LIMIT 1"
        )
        assignTo = fallbackUser?.id || null
      }
    }

    // --- Generate lead ID ---
    await execute("UPDATE counters SET value = value + 1 WHERE name = 'lead_counter'")
    const counter = await queryOne("SELECT value FROM counters WHERE name = 'lead_counter'")
    const counterVal = (counter?.value || 13) - 1
    const leadId = `HA${String(counterVal).padStart(5, "0")}`
    const id = `l${Date.now()}`
    const now = new Date().toISOString().replace("T", " ").substring(0, 19)

    // --- Insert lead ---
    await execute(
      `INSERT INTO leads (id, lead_id, name, email, phone, alternate_phone, source, status, sub_status, assigned_to, project_interest, budget, notes, created_at, updated_at)
       VALUES (?, ?, ?, ?, ?, ?, ?, 'new', 'warm', ?, ?, ?, ?, ?, ?)`,
      [id, leadId, name, email, phone, alternatePhone || null, source, assignTo, projectInterest, budget, notes, now, now]
    )

    // --- Add activity ---
    const actId = `a${Date.now()}`
    await execute(
      "INSERT INTO lead_activities (id, lead_id, type, description, created_at, created_by) VALUES (?, ?, 'note', ?, ?, ?)",
      [actId, id, `Lead auto-captured from ${source} via API`, now, assignTo]
    )

    // --- Update API key stats ---
    await execute(
      "UPDATE api_keys SET lead_count = lead_count + 1, last_used_at = ? WHERE id = ?",
      [now, keyRow.id]
    )

    return NextResponse.json({
      success: true,
      message: "Lead captured successfully.",
      leadId: leadId,
      assignedTo: assignTo,
      source: source,
    })

  } catch (error: any) {
    console.error("Lead capture webhook error:", error)
    if (error?.code === "ECONNREFUSED" || error?.message?.includes("mysql")) {
      return NextResponse.json(
        { success: false, error: "CRM database is temporarily unavailable. Please retry." },
        { status: 503 }
      )
    }
    return NextResponse.json(
      { success: false, error: "Internal server error." },
      { status: 500 }
    )
  }
}

// Also support GET for simple testing / health check
export async function GET(req: NextRequest) {
  return NextResponse.json({
    status: "active",
    endpoint: "ORBIT CRM Lead Capture Webhook",
    usage: "Send a POST request with lead data (name, phone, email) and API key (?key=YOUR_KEY)",
    docs: "https://orbit.hestiaabodes.in/api/webhook/lead-capture?key=YOUR_API_KEY",
  })
}
