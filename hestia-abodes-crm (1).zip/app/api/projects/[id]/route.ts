import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id } = await params
  const body = await req.json()

  const updates: string[] = []
  const values: any[] = []

  if (body.name !== undefined) { updates.push("name = ?"); values.push(body.name) }
  if (body.location !== undefined) { updates.push("location = ?"); values.push(body.location) }
  if (body.type !== undefined) { updates.push("type = ?"); values.push(body.type) }
  if (body.status !== undefined) { updates.push("status = ?"); values.push(body.status) }
  if (body.totalUnits !== undefined) { updates.push("total_units = ?"); values.push(body.totalUnits) }
  if (body.availableUnits !== undefined) { updates.push("available_units = ?"); values.push(body.availableUnits) }
  if (body.priceRange !== undefined) { updates.push("price_range = ?"); values.push(body.priceRange) }
  if (body.description !== undefined) { updates.push("description = ?"); values.push(body.description) }
  if (body.amenities !== undefined) { updates.push("amenities = ?"); values.push(JSON.stringify(body.amenities)) }
  if (body.image !== undefined) { updates.push("image = ?"); values.push(body.image) }

  if (updates.length === 0) return NextResponse.json({ error: "No fields" }, { status: 400 })

  values.push(id)
  await execute(`UPDATE projects SET ${updates.join(", ")} WHERE id = ?`, values)
  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id } = await params
  await execute("DELETE FROM projects WHERE id = ?", [id])
  return NextResponse.json({ success: true })
}
