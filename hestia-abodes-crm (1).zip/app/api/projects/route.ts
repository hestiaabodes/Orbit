import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapProject(row: any) {
  return {
    id: row.id, name: row.name, location: row.location,
    type: row.type, status: row.status,
    totalUnits: row.total_units, availableUnits: row.available_units,
    priceRange: row.price_range, description: row.description,
    amenities: row.amenities ? JSON.parse(row.amenities) : [],
    image: row.image, createdAt: row.created_at,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const rows = await query("SELECT * FROM projects ORDER BY created_at DESC")
  return NextResponse.json({ projects: rows.map(mapProject) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()
  const id = `p${Date.now()}`
  const createdAt = new Date().toISOString().split("T")[0]

  await execute(
    `INSERT INTO projects (id, name, location, type, status, total_units, available_units, price_range, description, amenities, image, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, body.name, body.location || "", body.type || "residential", body.status || "ongoing", body.totalUnits || 0, body.availableUnits || 0, body.priceRange || "", body.description || "", JSON.stringify(body.amenities || []), body.image || null, createdAt]
  )

  return NextResponse.json({ success: true, projectId: id })
}
