import { NextRequest, NextResponse } from "next/server"

export async function GET(req: NextRequest) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const { query } = await import("@/lib/db")

    const user = await getCurrentUser()
    if (!user || user.role !== "admin") {
      return NextResponse.json({ error: "Admin access required" }, { status: 403 })
    }

    const limit = parseInt(req.nextUrl.searchParams.get("limit") || "100")
    const offset = parseInt(req.nextUrl.searchParams.get("offset") || "0")

    const rows = await query(
      `SELECT a.*, u.name as user_name FROM audit_log a
       LEFT JOIN users u ON a.user_id = u.id
       ORDER BY a.created_at DESC LIMIT ? OFFSET ?`,
      [limit, offset]
    )

    return NextResponse.json({ logs: rows })
  } catch {
    return NextResponse.json({ logs: [] }, { status: 503 })
  }
}
