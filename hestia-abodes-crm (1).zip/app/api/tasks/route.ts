import { NextRequest, NextResponse } from "next/server"
import { query, execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapTask(row: any) {
  return {
    id: row.id, title: row.title, description: row.description,
    assignedTo: row.assigned_to, assignedBy: row.assigned_by,
    priority: row.priority, status: row.status,
    dueDate: row.due_date, leadId: row.lead_id, createdAt: row.created_at,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM tasks ORDER BY created_at DESC")
  return NextResponse.json({ tasks: rows.map(mapTask) })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const body = await req.json()
  const id = `t${Date.now()}`
  const createdAt = new Date().toISOString().split("T")[0]
  await execute(
    `INSERT INTO tasks (id, title, description, assigned_to, assigned_by, priority, status, due_date, lead_id, created_at)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, body.title, body.description || "", body.assignedTo, body.assignedBy || me.id, body.priority || "medium", body.status || "pending", body.dueDate || null, body.leadId || null, createdAt]
  )
  return NextResponse.json({ success: true, taskId: id })
}
