import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const { id } = await params
  const body = await req.json()
  const updates: string[] = []
  const values: any[] = []
  if (body.title !== undefined) { updates.push("title = ?"); values.push(body.title) }
  if (body.description !== undefined) { updates.push("description = ?"); values.push(body.description) }
  if (body.assignedTo !== undefined) { updates.push("assigned_to = ?"); values.push(body.assignedTo) }
  if (body.priority !== undefined) { updates.push("priority = ?"); values.push(body.priority) }
  if (body.status !== undefined) { updates.push("status = ?"); values.push(body.status) }
  if (body.dueDate !== undefined) { updates.push("due_date = ?"); values.push(body.dueDate) }
  if (body.leadId !== undefined) { updates.push("lead_id = ?"); values.push(body.leadId || null) }
  if (updates.length === 0) return NextResponse.json({ error: "No fields" }, { status: 400 })
  values.push(id)
  await execute(`UPDATE tasks SET ${updates.join(", ")} WHERE id = ?`, values)
  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const { id } = await params
  await execute("DELETE FROM tasks WHERE id = ?", [id])
  return NextResponse.json({ success: true })
}
