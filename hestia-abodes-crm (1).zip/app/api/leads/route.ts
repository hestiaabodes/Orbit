import { NextRequest, NextResponse } from "next/server"
import { query, execute, queryOne } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapLead(row: any) {
  return {
    id: row.id, leadId: row.lead_id, name: row.name, email: row.email,
    phone: row.phone, alternatePhone: row.alternate_phone, source: row.source,
    status: row.status, subStatus: row.sub_status, assignedTo: row.assigned_to,
    projectInterest: row.project_interest, budget: row.budget, notes: row.notes,
    createdAt: row.created_at, updatedAt: row.updated_at,
    lastContactedAt: row.last_contacted_at, nextFollowUp: row.next_follow_up,
    activities: [],
  }
}

function mapActivity(row: any) {
  return {
    id: row.id, type: row.type, description: row.description,
    createdAt: row.created_at, createdBy: row.created_by,
  }
}

export async function GET(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  // Fetch all leads
  const leadRows = await query(
    "SELECT * FROM leads ORDER BY created_at DESC"
  )
  const leads = leadRows.map(mapLead)

  // Fetch all activities
  const activityRows = await query(
    "SELECT * FROM lead_activities ORDER BY created_at DESC"
  )

  // Group activities by lead
  const activityMap: Record<string, any[]> = {}
  for (const a of activityRows) {
    if (!activityMap[a.lead_id]) activityMap[a.lead_id] = []
    activityMap[a.lead_id].push(mapActivity(a))
  }
  for (const lead of leads) {
    lead.activities = activityMap[lead.id] || []
  }

  // Get lead counter
  const counter = await queryOne("SELECT value FROM counters WHERE name = 'lead_counter'")

  return NextResponse.json({ leads, leadCounter: counter?.value || 13 })
}

export async function POST(req: NextRequest) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const body = await req.json()

  // Server-side validation
  const { validateLead, sanitize } = await import("@/lib/validate")
  const errors = validateLead(body)
  if (errors.length > 0) return NextResponse.json({ error: errors[0].message, errors }, { status: 400 })
  body.name = sanitize(body.name)
  body.email = sanitize(body.email)
  body.notes = sanitize(body.notes)

  const now = new Date().toISOString().replace("T", " ").substring(0, 19)

  // Get next lead counter atomically
  await execute("UPDATE counters SET value = value + 1 WHERE name = 'lead_counter'")
  const counter = await queryOne("SELECT value FROM counters WHERE name = 'lead_counter'")
  const counterVal = (counter?.value || 13) - 1
  const leadId = `HA${String(counterVal).padStart(5, "0")}`
  const id = `l${Date.now()}`

  await execute(
    `INSERT INTO leads (id, lead_id, name, email, phone, alternate_phone, source, status, sub_status, assigned_to, project_interest, budget, notes, created_at, updated_at, next_follow_up)
     VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
    [id, leadId, body.name, body.email || "", body.phone, body.alternatePhone || null, body.source, body.status || "new", body.subStatus || "warm", body.assignedTo, body.projectInterest || null, body.budget || "", body.notes || "", now, now, body.nextFollowUp || null]
  )

  // Add creation activity
  const actId = `a${Date.now()}`
  await execute(
    "INSERT INTO lead_activities (id, lead_id, type, description, created_at, created_by) VALUES (?, ?, 'note', 'Lead created', ?, ?)",
    [actId, id, now, me.id]
  )

  return NextResponse.json({ success: true, leadId: id })
}
