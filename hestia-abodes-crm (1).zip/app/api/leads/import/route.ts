import { NextRequest, NextResponse } from "next/server"

export async function POST(req: NextRequest) {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const { execute, queryOne } = await import("@/lib/db")

    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
    if (user.role !== "admin" && user.role !== "manager") {
      return NextResponse.json({ error: "Admin or manager access required" }, { status: 403 })
    }

    const formData = await req.formData()
    const file = formData.get("file") as File
    if (!file) return NextResponse.json({ error: "No file uploaded" }, { status: 400 })

    const text = await file.text()
    const lines = text.split("\n").filter(l => l.trim())
    if (lines.length < 2) return NextResponse.json({ error: "CSV must have a header row and at least one data row" }, { status: 400 })

    // Parse header
    const headers = lines[0].split(",").map(h => h.trim().toLowerCase().replace(/['"]/g, ""))

    // Map common header names
    const colMap: Record<string, string> = {}
    for (let i = 0; i < headers.length; i++) {
      const h = headers[i]
      if (h.includes("name") && !h.includes("project")) colMap["name"] = String(i)
      if (h.includes("email")) colMap["email"] = String(i)
      if (h.includes("phone") && !h.includes("alternate")) colMap["phone"] = String(i)
      if (h.includes("alternate") || h.includes("alt")) colMap["alternatePhone"] = String(i)
      if (h.includes("source")) colMap["source"] = String(i)
      if (h.includes("budget")) colMap["budget"] = String(i)
      if (h.includes("notes") || h.includes("remark") || h.includes("comment")) colMap["notes"] = String(i)
      if (h.includes("project")) colMap["project"] = String(i)
      if (h.includes("status") && !h.includes("sub")) colMap["status"] = String(i)
    }

    if (!colMap["name"] && !colMap["phone"]) {
      return NextResponse.json({ error: "CSV must have at least a 'name' or 'phone' column" }, { status: 400 })
    }

    let imported = 0
    let skipped = 0
    const now = new Date().toISOString().replace("T", " ").substring(0, 19)

    for (let i = 1; i < lines.length; i++) {
      // Simple CSV parser handling quoted fields
      const cols: string[] = []
      let current = ""
      let inQuotes = false
      for (const ch of lines[i]) {
        if (ch === '"') { inQuotes = !inQuotes; continue }
        if (ch === "," && !inQuotes) { cols.push(current.trim()); current = ""; continue }
        current += ch
      }
      cols.push(current.trim())

      const name = cols[parseInt(colMap["name"] || "0")] || ""
      const phone = cols[parseInt(colMap["phone"] || "1")] || ""

      if (!name && !phone) { skipped++; continue }

      // Get next counter
      await execute("UPDATE counters SET value = value + 1 WHERE name = 'lead_counter'")
      const counter = await queryOne("SELECT value FROM counters WHERE name = 'lead_counter'")
      const counterVal = (counter?.value || 13) - 1
      const leadId = `HA${String(counterVal).padStart(5, "0")}`
      const id = `l${Date.now()}_${i}`

      await execute(
        `INSERT INTO leads (id, lead_id, name, email, phone, alternate_phone, source, status, sub_status, assigned_to, budget, notes, created_at, updated_at)
         VALUES (?, ?, ?, ?, ?, ?, ?, 'new', 'warm', ?, ?, ?, ?, ?)`,
        [
          id, leadId,
          name,
          cols[parseInt(colMap["email"] || "999")] || "",
          phone,
          cols[parseInt(colMap["alternatePhone"] || "999")] || null,
          cols[parseInt(colMap["source"] || "999")] || "Other",
          user.id,
          cols[parseInt(colMap["budget"] || "999")] || "",
          cols[parseInt(colMap["notes"] || "999")] || "",
          now, now,
        ]
      )

      // Add creation activity
      await execute(
        "INSERT INTO lead_activities (id, lead_id, type, description, created_at, created_by) VALUES (?, ?, 'note', 'Imported from CSV', ?, ?)",
        [`a${Date.now()}_${i}`, id, now, user.id]
      )

      imported++
    }

    const { logAudit } = await import("@/lib/audit")
    await logAudit(user.id, "import_leads", "lead", null, { imported, skipped, fileName: file.name })

    return NextResponse.json({ success: true, imported, skipped })
  } catch (error: any) {
    console.error("Import error:", error)
    return NextResponse.json({ error: "Import failed: " + (error?.message || "unknown error") }, { status: 500 })
  }
}
