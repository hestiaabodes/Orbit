import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function POST(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id: leadId } = await params
  const body = await req.json()
  const now = new Date().toISOString().replace("T", " ").substring(0, 19)
  const actId = `a${Date.now()}`

  await execute(
    "INSERT INTO lead_activities (id, lead_id, type, description, created_at, created_by) VALUES (?, ?, ?, ?, ?, ?)",
    [actId, leadId, body.type, body.description, now, body.createdBy || me.id]
  )

  // Update lead updated_at
  await execute("UPDATE leads SET updated_at = ? WHERE id = ?", [now, leadId])

  return NextResponse.json({ success: true })
}
