import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id } = await params
  const body = await req.json()
  const now = new Date().toISOString().replace("T", " ").substring(0, 19)

  const updates: string[] = ["updated_at = ?"]
  const values: any[] = [now]

  if (body.name !== undefined) { updates.push("name = ?"); values.push(body.name) }
  if (body.email !== undefined) { updates.push("email = ?"); values.push(body.email) }
  if (body.phone !== undefined) { updates.push("phone = ?"); values.push(body.phone) }
  if (body.alternatePhone !== undefined) { updates.push("alternate_phone = ?"); values.push(body.alternatePhone || null) }
  if (body.source !== undefined) { updates.push("source = ?"); values.push(body.source) }
  if (body.status !== undefined) { updates.push("status = ?"); values.push(body.status) }
  if (body.subStatus !== undefined) { updates.push("sub_status = ?"); values.push(body.subStatus) }
  if (body.assignedTo !== undefined) { updates.push("assigned_to = ?"); values.push(body.assignedTo) }
  if (body.projectInterest !== undefined) { updates.push("project_interest = ?"); values.push(body.projectInterest) }
  if (body.budget !== undefined) { updates.push("budget = ?"); values.push(body.budget) }
  if (body.notes !== undefined) { updates.push("notes = ?"); values.push(body.notes) }
  if (body.nextFollowUp !== undefined) { updates.push("next_follow_up = ?"); values.push(body.nextFollowUp || null) }
  if (body.lastContactedAt !== undefined) { updates.push("last_contacted_at = ?"); values.push(body.lastContactedAt) }

  values.push(id)
  await execute(`UPDATE leads SET ${updates.join(", ")} WHERE id = ?`, values)

  return NextResponse.json({ success: true })
}

export async function DELETE(req: NextRequest, { params }: { params: Promise<{ id: string }> }) {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

  const { id } = await params
  await execute("DELETE FROM leads WHERE id = ?", [id])
  return NextResponse.json({ success: true })
}
