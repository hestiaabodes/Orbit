import { NextResponse } from "next/server"

export async function GET() {
  try {
    const { getCurrentUser } = await import("@/lib/auth")
    const { query } = await import("@/lib/db")

    const user = await getCurrentUser()
    if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })

    const rows = await query(
      `SELECT l.lead_id, l.name, l.email, l.phone, l.alternate_phone, l.source, l.status, l.sub_status,
              u.name as assigned_to_name, p.name as project_name, l.budget, l.notes,
              l.created_at, l.updated_at, l.last_contacted_at, l.next_follow_up
       FROM leads l
       LEFT JOIN users u ON l.assigned_to = u.id
       LEFT JOIN projects p ON l.project_interest = p.id
       ORDER BY l.created_at DESC`
    )

    // Build CSV
    const headers = ["Lead ID", "Name", "Email", "Phone", "Alternate Phone", "Source", "Status", "Sub-Status", "Assigned To", "Project", "Budget", "Notes", "Created At", "Updated At", "Last Contacted", "Next Follow-up"]
    const csvRows = [headers.join(",")]

    for (const r of rows) {
      const row = [
        r.lead_id, r.name, r.email || "", r.phone, r.alternate_phone || "", r.source || "",
        r.status, r.sub_status, r.assigned_to_name || "", r.project_name || "", r.budget || "",
        `"${(r.notes || "").replace(/"/g, '""')}"`,
        r.created_at || "", r.updated_at || "", r.last_contacted_at || "", r.next_follow_up || "",
      ]
      csvRows.push(row.map(v => typeof v === "string" && v.includes(",") ? `"${v}"` : String(v ?? "")).join(","))
    }

    const csv = csvRows.join("\n")

    const { logAudit } = await import("@/lib/audit")
    await logAudit(user.id, "export_leads", "lead", null, { count: rows.length })

    return new NextResponse(csv, {
      headers: {
        "Content-Type": "text/csv",
        "Content-Disposition": `attachment; filename="leads-export-${new Date().toISOString().split("T")[0]}.csv"`,
      },
    })
  } catch {
    return NextResponse.json({ error: "Export failed" }, { status: 500 })
  }
}
