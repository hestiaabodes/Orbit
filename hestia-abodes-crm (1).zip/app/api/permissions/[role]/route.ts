import { NextRequest, NextResponse } from "next/server"
import { execute } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

export async function PATCH(req: NextRequest, { params }: { params: Promise<{ role: string }> }) {
  const me = await getCurrentUser()
  if (!me || me.role !== "admin") return NextResponse.json({ error: "Forbidden" }, { status: 403 })
  const { role } = await params
  const body = await req.json()
  await execute(
    "UPDATE role_permissions SET permissions = ? WHERE role = ?",
    [JSON.stringify(body.permissions), role]
  )
  return NextResponse.json({ success: true })
}
