import { NextResponse } from "next/server"
import { query } from "@/lib/db"
import { getCurrentUser } from "@/lib/auth"

function mapPermission(row: any) {
  return {
    role: row.role,
    permissions: typeof row.permissions === "string" ? JSON.parse(row.permissions) : row.permissions,
  }
}

export async function GET() {
  const me = await getCurrentUser()
  if (!me) return NextResponse.json({ error: "Unauthorized" }, { status: 401 })
  const rows = await query("SELECT * FROM role_permissions")
  return NextResponse.json({ permissions: rows.map(mapPermission) })
}
